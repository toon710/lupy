/*
    계층형 질의 명령
    ==> emp 테이블의 경우 KING부터 시작해서 사원들이 계층형 구조를 이루게 된다.
        오라클에서는 이런 계층형 질의 명령을 쉽게 작성할 수 있도록 
        문법을 만들어 놓았다.
        
        형식 ]
            
            SELECT
                컬럼이름1, 컬럼이름2, ... , LEVEL
            FROM
                테이블이름
            WHERE
                조건
            START WITH
                계층 추적 시작점...
            CONNECT BY
                각 행들의 계층이 연결관계를 표현
            ORDER SIBLINGS BY
                계층형 질의명령의 결과를 정렬
            ;
            
            *
            LEVEL : 계층의 DEPTH 를 알려주는 의사컬럼
            ***
            PRIOR : "이전의" 라는 의미로 직전 계층을 의미
            *
            CONNECT_BY_ROOT : 최상위 계층을 의미하고
                ==> CONNECT_BY_ROOT(ename) ==> 사장의 이름
                    CONNECT_BY_ROOT EMPNO ==> 사장의 사원번호
                    
            CONNECT_BY_ISLEAF : 최하위 계층을 의미
*/

-- 사원들의 정보를 제일 상사부터 계층형으로 조회하세요.
SELECT
    empno 사원번호, ename 사원이름, 
    mgr 상사번호, level 레벨
FROM
    emp
START WITH
    mgr IS NULL
CONNECT BY
    PRIOR empno = mgr
ORDER SIBLINGS BY
    hiredate
;

-- emp3 테이블에 문자데이터 100을 기억할 수 있는
-- depth 컬럼을 추가하세요

-- 이미 만들어진 테이블의 구조를 변경하는 작업이므로 ALTER 명령을사용한다.
ALTER TABLE emp3
ADD (
    depth VARCHAR2(100 CHAR)
);

INSERT INTO
    emp3
    SELECT
        e.*, 'A'
    FROM
        emp e
    WHERE
        ename = 'KING'
;
INSERT INTO
    emp3
    SELECT
        e.*, 'B'
    FROM
        emp e
    WHERE
        mgr = 7839
;

/*
    #100#203
    #100#301 올림차순하면 된다.
*/
--------------------------------------------------------------------------------
/*
	ROWNUM
	==> 오라클이 제공하는 의사컬럼
		조회된 데이터에 자동으로 숫자를 1씩 증가시켜서 붙여준다.
*/
SELECT
	rownum, empno, ename
FROM
	emp
;
-- rownum 이 1 ~ 5 사이인 사원 조회 < rownum은 1이 안 만들어지면 다 안 만들어진다. >
SELECT
	rownum, empno, ename
FROM
	emp
WHERE
    rownum BETWEEN 1 AND 5
;
-- 급여가 많은 사원부터 정렬한 후 1 ~ 5 번째 사원을 조회하세요.
SELECT
	rownum, empno, ename
FROM
	emp
WHERE
    rownum BETWEEN 1 AND 5
ORDER BY
    sal DESC
;—> rownum 이 섞이게 된다.

— 해결방법
— 1. 먼저 정렬한다.
— 2. 정렬된 인라인뷰에 ROWNUM 을 붙여주고
— 3. ROWNUM 이 붙여진 인라인뷰에서 조건으로 걸러서 조회한다.
— 인라인뷰에 rownum 에 별칭을 주는 이유는 그 값을 고정시켜서 꺼내오려고 하기 때문이다.
— 본문에서 써보면 그 데이터가 서로 다르다는걸 알 수 있다.
SELECT
   ROWNUM, rno, empno, ename, sal
FROM
    (
    SELECT
        ROWNUM rno, empno, ename, sal
    FROM
        (
            SELECT
                empno, ename, sal
            FROM
                emp
            ORDER BY
                sal DESC
        )
    )
WHERE
    rno BETWEEN 6 AND 10
;

/*
    문제 ]
        사원들을 KING 사원부터 시작해서 계층형으로 (입사일 기준 오름차순)
            사원번호, 사원이름, 직급, 입사일, 레벨
        을 조회하고
        한페이지당 5명씩 보여줄 예정이다.
        
        2페이지에 해당하는 사원들의 정보를 조회하세요.
*/



