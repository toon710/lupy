-- test01.sql 무명 프로시저 실행
set serveroutput on;
@D:\class\db\src\proc02\test01.sql;

run D:\class\db\src\proc02\test01.sql;

-- test02.sql 실행
@D:\class\db\src\proc02\test02.sql;

run D:\class\db\src\proc02\test02.sql;

@D:\class\db\src\proc02\test03.sql;
@D:\class\db\src\proc02\test0301.sql;

CREATE TABLE TMP1(
    NO NUMBER(1, -2)
);

INSERT INTO TMP1 VALUES(11);
SELECT * FROM TMP1;

INSERT INTO TMP1 VALUES(99);
SELECT * FROM TMP1;

INSERT INTO TMP1 VALUES(548);
SELECT * FROM TMP1;

INSERT INTO TMP1 VALUES(777);
SELECT * FROM TMP1;

COMMIT;

ALTER TABLE TMP1
ADD (
    NUM NUMBER(3)
);

INSERT INTO TMP1 VALUES(333, 3.54);

SELECT * FROM TMP1;
/*
    1. sqlplus 명령
    2. 연산자
    3. 날짜함수, 문자함수
    4. 널 처리함수
    5. group by , 그룹함수
    6. 서브질의, 조인
    7. 인덱스 생성
    8. 시퀀스 생성
    
*/

----------------------------------------------------------------------------------------
-- 저장 프로시저

-- 테이블 준비
CREATE TABLE test00
AS
    SELECT * FROM emp;


-- test01 테이블에서 원하는 급여 미만을 지급받는 사원들의 급여를 10% 인상해주는 
--  upSal 프로시저를 만들어서 실행하세요.

CREATE OR REPLACE PROCEDURE upSal
    (v_sal IN NUMBER) -- 파라미터 변수 선언
IS
    -- 프로시저 내부에서 사용할 변수 선언부...
    -- 필요하지 않으면 기술하지 않아도 된다.
BEGIN
    -- 입력된 금액 미만 받는 사원들의 급여를 10% 인상
    UPDATE
        test00
    SET
        sal = sal * 1.1
    WHERE
        sal < v_sal
    ;
    
    -- DML 명령은 트랜젝션 처리가 되지 않으므로 반드시 COMMIT 명령이 필요하다.
    commit;
END;
/

execute upSal(1200);

exec upSal(1200);

-- 사원번호를 입력해서 실행하면
-- 사원의 이름, 직급, 급여를 조회하는 프로시저를 작성하세요.
CREATE OR REPLACE PROCEDURE sel_eno
    (eno IN NUMBER)
IS
    no CONSTANT NUMBER := 3.14;
    name VARCHAR2(50 CHAR);
    duty VARCHAR2(50 CHAR);
    money NUMBER;
BEGIN
    DBMS_OUTPUT.ENABLE; -- 출력가능 상태로 만들고
    
    -- 질의명령
    SELECT
        ename, job, sal
    INTO
        name, duty, money
    FROM
        emp
    WHERE
        empno = eno
    ;
    
    -- 변수에 기억된 내용을 출력
    DBMS_OUTPUT.PUT_LINE('사원번호 : ' || eno);
    DBMS_OUTPUT.PUT_LINE('사원이름 : ' || name);
    DBMS_OUTPUT.PUT_LINE('사원직급 : ' || duty);
    DBMS_OUTPUT.PUT_LINE('사원급여 : ' || money);
END;
/

exec sel_eno(7369);

--------------------------------------------------------------------------------
-- %TYPE 에 의한 변수 선언

-- 사원번호를 입력해서 실행하면
-- 해당 사원의 이름, 직급, 상사이름을 출력해주는 프로시저를 작성하세요.
-- 단, 상사가 없는 사원은 '상사없음'으로 출력되게 하세요.

CREATE OR REPLACE PROCEDURE sel_eno_out
    (eno IN emp.empno%TYPE)
IS
    -- 내부변수 선언
    name emp.ename%TYPE;
    duty emp.job%TYPE;
    sname emp.ename%TYPE;
BEGIN
    DBMS_OUTPUT.ENABLE;
    
    -- 질의명령
    SELECT
        e.ename, e.job, NVL(s.ename, '사 장')
    INTO
        name, duty, sname
    FROM
        emp e, emp s
    WHERE
        e.mgr = s.empno(+)
        AND e.empno = eno
    ;
    
    -- 출력
    DBMS_OUTPUT.PUT_LINE(LPAD('=', 46, '='));
    DBMS_OUTPUT.PUT_LINE('| 사원번호 | 사원이름 | 사원 직급 | 상사이름 |');
    DBMS_OUTPUT.PUT_LINE(LPAD('-', 46, '-'));
    DBMS_OUTPUT.PUT_LINE('| ' || LPAD(RPAD(to_char(eno), 6, ' '), 8, ' ') ||
                        ' | ' || RPAD(name, 8, ' ') || ' | ' || 
                        RPAD(duty, 9, ' ') || ' | ' || 
                        RPAD(sname, 8, ' ') || ' |');
    DBMS_OUTPUT.PUT_LINE(LPAD('=', 46, '='));
END;
/

EXEC sel_eno_out(7369);
exec sel_eno_out(7839);





