/*
    날짜 함수
        
        참고 ]
            sysdate : 오라클의 에약어로 현재 시스템의 날짜/시간을 알려준다.
            
            예 ]
                SELECT TO_CHAR(sysdate, 'YYYY-MM-DD HH24:MI:SS') 현재시각 FROM dual;
                
        참고 ]
            날짜 데이터는 마이너스 연산(-) 을 허락한다.
            날짜 연번끼리는 - 을 한다.
            
            예 ]
                사원들의 근무일수를 조회하세요.
                
                SELECT
                    ename 사원이름, hiredate 입사일, FLOOR(sysdate - hiredate) 근무일수
                FROM
                    emp
                ;
                
        날짜 연번 ]
            1970년 1월 1일 0시 0분 0초를 기준으로 
            지정한 날짜까지의 날짜연번을 이용해서 날짜데이터를 기억한다.
            
            형식 ]
                날수.시간 
                의 형태로 내부적으로 숫자의 형태로 기억한다.
                
        참고 ]
            날짜데이터끼리의 연산은 - 는 가능하지만
            +, *, / 는 불가능하다.
            
        참고 ]
            날짜 + 또는 - 숫자는 가능하다.
            ==> 날짜 연번은 숫자이고
                결국 날짜에서 원하는 숫자만큼 이동된 날짜를 표시한다.
                
        1. ADD_MONTHS()
        ==> 현재 날짜에 지정한 달수를 더하거나 뺀 날짜를 알려준다.
            
            형식 ]
                ADD_MONTHS(날짜, 더할개월수)
            
            예 ]
                지금부터 두달 후의 날짜를 조회하세요.
                
                SELECT
                    ADD_MONTHS(sysdate, 2) 두달후
                FROM
                    dual
                ;
                
        2. MONTHS_BETWEEN
            ==> 두 날짜 사이의 개월수를 알려주는 함수
            
                형식 ]
                    MONTHS_BETWEEN(날짜, 날짜)
                    
                예 ]
                    사원들의 근무개월수를 조회하세요.
                    
                    SELECT 
                        TRUNC(ABS(MONTHS_BETWEEN(hiredate, sysdate))) 근무개월수
                    FROM
                        emp
                    ;
                    
        3. LAST_DAY()
            ==> 지정한 날짜가 포함된 월의 가장 마지막 날짜를 알려주는 함수
                
                형식 ]
                    LAST_DAY(날짜)
                    
                예 ]
                    이번달 마지막 날짜를 조회하세요.
                    SELECT LAST_DAY(sysdate) 말일 FROM dual;
                    
                문제 ]
                    사원들의 첫월급일을 조회하세요. 급여일은 매월 1일로 한다.
                    
                    SELECT
                        ename 사원이름, hiredate 입사일, 
                        LAST_DAY(hiredate) + 1 첫급여일
                    FROM
                        emp
                    ;
                    
        4. NEXT_DAY
            ==> 지정한 날짜 이후 가장 처음 만나는 지정한 요일이 몇일인지를 알려주는 함수
                
                형식 ]
                    NEXT_DAY(날짜, 원하는 요일형식)
                    
                    요일형식 ]
                        1. 우리나라는 
                            '월요일', '화요일', ...
                            '월', '화',...
                        2. 영문권에서는
                            'MON', 'TUE',...
                            'MONDAY', 'TUESDAY',...
                            
                예 ]
                    이번주 일요일이 몇일인지 조회하세요.
                    
                    SELECT
                        sysdate 오늘, NEXT_DAY(sysdate, '일요일') 이번주일요일
                    FROM
                        dual
                    ;
                    
        5. ROUND
        ==> 날짜를 지정한 부분에서 반올림하는 함수
            
            지정한 부분이란    년, 월, 일, 시간, ....
            
            형식 ]
                ROUND(날짜, '반올림기준')
                
            예 ]
                SELECT 
                    ROUND(sysdate, 'YEAR') 년도반올림
                FROM
                    dual
                ;
                
                SELECT 
                    ROUND(TO_DATE('2022/06/28'), 'YEAR') 년도반올림
                FROM
                    dual
                ;
                
                SELECT 
                    ROUND(TO_DATE('2022/02/15'), 'MONTH') 년도반올림
                FROM
                    dual
                ;
            
----------------------------------------------------------------------------------------------
형번환함수
==> 함수는 데이터 형태에 따라서 사용하는 함수가 달라진다.
    그런데 만약 사용하려는 함수가 필요한 데이터가 아닌 경우에는
    필요한 데이터로 변환해주는 함수가 필요하다.
    이런 함수를 변환함수라 한다.
    ==> 데이터의 형태를 바꿔서 특정함수에 사용가능하도록 만들어주는 함수
    
    1. TO_CHAR()
        ==> 날짜 또는 숫자 데이터를 문자데이터로 변환해주는 함수
        
        형식 1 ]
            TO_CHAR(날짜 또는 숫자)
            
            예 ]
                SELECT TO_CHAR(sysdate) 오늘 FROM dual;
                
             문제 ]
                급여가 세자리수인 사원들의 사원이름, 급여 를 조회하세요.
                
                SELECT
                    ename 사원이름, sal 급여
                FROM
                    emp
                WHERE
                    LENGTH(TO_CHAR(sal)) = 3
                --    sal BETWEEN 100 AND 999
                ;
                
        형식 2 ]
            TO_CHAR(날짜 또는 숫자, '변환형식')
            
            변환형식 ]
                날짜
                    YYYY
                    YY
                    MM
                    DD
                    DAY
                    HH
                    HH24
                    MI
                    SS
                    
                숫자
                    0   : 무효숫자도 표현
                    9   : 무효숫자는 표현하지 않는다.
                    $   : 통화기호
                    -   : 음수부호
                    ,   : 세자리 자리수
                    .   : 소수점
                
                예 ]
                    사원들의 사원이름, 급여를 조회하는데
                    급여를 7자리에 맞춰서 표현하고 세자리마다 , 구분해서 처리하세요.
                    
                    SELECT
                        ename 사원이름, TO_CHAR(sal, '0,000,000') 급여
                    FROM
                        emp
                    ;
             문제 ]
                사원들의 입사요일을 조회하세요.
                
                SELECT ename 사원이름, TO_CHAR(hiredate, 'DAY') 입사요일 FROM emp;
                
    2. TO_DATE
    ==> 날짜형식의 문자열을 날짜데이터로 변환하는 함수
        
        형식 1 ]
            TO_DATE(날짜문자열)
            
            참고 ]
                날짜문자열의 구분자가 /, -, . , _  등은 이 형식으로 처리된다.
                
        형식 2 ]
            TO_DATE(날짜문자열, '형식')
            
    3. TO_NUMBER()
    ==> 숫자형태의 문자열을 숫자로 변환해주는 함수
        
        형식 1 ]
            TO_NUMBER(숫자형식문자열)
        형식 2 ]
            TO_NUMBER(숫자형식문자열, 형식)
            
            예 ]
                '1,234' + '5,678' 의 계산결과를 조회하세요.
                
                SELECT
                    TO_NUMBER('1,234', '99,999,999') + TO_NUMBER('5,678', '99,999,999') 계산결과
                FROM
                    dual
                ;
        
        
        

*/
SELECT (sysdate + 100) 백일후 FROM dual;

/*
    문제 ]
        사원들의 사원이름, 직급, 상사번호, 부서번호 를 조회하는데
        상사번호가 없으면 '상사없음' 으로 출력하세요.
*/
SELECT
    ename 사원이름, job 직급, NVL(TO_CHAR(mgr), '상사없음') 상사번호, deptno 부서번호
FROM
    emp
;
