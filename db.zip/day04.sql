/*
    함수
    ==> 데이터를 가공하기 위해 오라클에서 제공하는 명령의 일종...
        
        참고 ]
            DBMS는 데이터베이스밴더마다 다르다.
            특히 함수는 밴드들마다 매우 다르다.
            따라서 다른 데이터베이스를 사용하면 함수들이 달라질 것이므로 
            함수들 부터 파악해 놓는 것이 좋다.
            
        종류 ]
            1. 단일행 함수
            ==> 한행 한행마다 매번 명령이 실행되는 함수
                ==> 데이터 하나로 처리되는 함수
                따라서 단일행 함수의 결과는 출력되는 데이터의 갯수와 동일하다.
                
            2. 그룹 함수
            ==> 여러행을 모아서 한번만 실행되는 함수
                따라서 그룹 함수는 출력의 갯수가 오직 한개이다.
                
            ***
            주의 ]
                단일행함수와 그룹함수는 절대로 같이 호출할 수 없다.
                
------------------------------------------------------------------------------------------------
단일행 함수
    1. 숫자 함수
    ==> 데이터가 숫자인 경우에만 사용할 수 있는 함수
    
        1) ABS()
        ==> 절대값 구해주는 함수
            
            형식 ]
                ABS(데이터 또는 컬럼이름 또는 숫자연산식)
                
        2) FLOOR()
        ==> 소수점 이하를 버리는 함수(정수를 만들어 주는 함수)
            
            형식 ]
                FLOOR(데이터 또는 컬럼이름 또는 숫자연산식)
                
        3) ROUND()
        ==> 지정한 자리수에서 반올림하는 함수
            
            형식 ]
                ROUND(데이터 또는 컬럼이름[, 자릿수])
                
            참고 ]
                자릿수는 양수를 쓰면 반올림해서 보여줄 자릿수가 되고
                음수를 쓰면 소숫점이상 반올림할 자릿수가 된다.
                
                예 ]
                    ROUND(숫자, 3)    : 소수점 이하 네째자리에서 반올림
                    ROUND(숫자, -2)   : 십의 자리에서 반올림
                    
        4) TRUNC()
        ==> FLOOR() 함수와 마찬가지로 버림하는 함수
            차이점은 자리수를 지정할 수 있다.
            
            형식 ]
                TRUNC(데이터 [, 자리수 ])
                
            참고 ]
                자리수는 ROUND() 와 같이 처리된다.
                
        5) MOD()
        ==> 나머지를 구하는 함수
            
            형식 ]
                MOD(데이터1, 데이터2)
                ==> 데이터1을 데이터2로 나눈 나머지
                
        참고 ]
            모든 함수는 SELECT절에서도 사용할 수 있고
            WHERE 조건절에서도 사용할 수 있다.
*/

-- 계층형 질의명령 : 댓글게시판
SELECT
    empno, ename, job, mgr, level-1 step
FROM
    emp
START WITH
    mgr IS NULL
CONNECT BY
    PRIOR empno = mgr
;

-- 1 - 1
SELECT ABS(-100 - 3.14) FROM dual;

-- 1-2 : 사원들의 급여를 15% 인상한 금액을 조회하세요. 단, 소수이하는 버림하세요.
SELECT
    empno 사원번호, ename 사원이름, 
    sal 현급여, sal * 1.15 "버림 전", FLOOR(sal * 1.15) 인상급여
FROM
    emp
;

-- 1-2 : 사원들의 급여를 15% 인상해서 조회하세요. 단, 십의 자리에서 반올림하세요.
SELECT
    empno 사원번호, ename 사원이름, 
    sal 현급여, sal * 1.15 "버림 전", FLOOR(sal * 1.15) 인상급여,
    ROUND(sal * 1.15, -2) "반올림 급여"
FROM
    emp
;

SELECT ROUND(3.1415192, 2) 숫자 FROM dual; -- 소수점이하 세째자리에서 반올림 : ==> 3.14

-- 1-4 : 사원들의 급여를 15% 인상한 금액을 조회하세요. 단, 100 단위 미만은 버리세요.
SELECT
    ename 사원이름, sal 현급여, sal * 1.15 "버림 전", TRUNC(sal * 1.15, -2) 인상급여
FROM
    emp
;

SELECT TRUNC(3.141592, 3) no FROM DUAL;

-- 1-5 : 사원들 중 급여가 짝수인 사원 만 조회하세요.
SELECT
    ename 이름, job 직급, sal 급여, MOD(sal, 2) 나머지
FROM
    emp
WHERE
    MOD(sal, 2) = 0
;

/*
                TO_CHAR()                   TO_CHAR()
    숫자    --------------->      문자      <---------------    날짜   
            <--------------                 --------------->
                TO_NUMBER()                     TO_DATE()
    
    
    
    2. 문자 함수
    ==> 문자 데이터를 가공해주는 함수
        
        1) LOWER
        ==> 알파벳을 소문자로 변환해서 반환해주는 함수
        2) UPPER
        ==> 알파벳을 대문자로 변환해서 반환해주는 함수
        3) INITCAP
        ==> 단어의 첫문자는 대문자로 
            두번째 이후문자는 소문자로 변환해서 반환해주는 함수
            
        4) LENGTH() / LENGTHB()
        ==> 문자열의 길이 / 바이트 를 반환해주는 함수
        
        5) CONCAT()
        ==> 두개의 문자열을 하나로 결합해주는 함수
            
            형식 ]
                CONCAT(데이터1, 데이터2)
        6) SUBSTR() / SUBSTRB()
        ==> 문자열 중에서 특정위치의 문자열만 추출해주는 함수
            
            형식 ]
                SUBSTR(문자열, 시작위치, 꺼낼갯수)
                
            참고 ]
                위치값은 데이터베이스의 경우 1부터 시작한다.
                
            참고 ]
                꺼낼갯수는 생략가능 하다.
                이 경우 맨 뒤까지 꺼내게 된다.
                
        7) INSTR() / INSTRB()
        ==> 문자열 중에서 특정 문자열이 시작되는 위치값(바이트)을 알려주는 함수
            
             형식 ]
                INSTR(문자열, 찾을문자열[, 시작위치, 출현 횟수])
            
            참고 ]
                시작위치는 음수로 사용할 수 있다.
                음수로 쓰는 경우는 뒤에서 부터 위치값을 계산하게 된다.
                주의사항은 검색 방향도 뒤에서 부터 앞으로 진행해서 찾게된다.
                
                찾을 문자가 없는 경우는 0 을 반환해준다.
            
        8) LPAD() / RPAD()
        ==> 문자열의 길이를 지정한 후
            남는 공간은 지정한 문자로 채워서 문자열을 길이수로 완성해주는 함수
            
            차이점 ]
                남는 부분이 생겼을때 왼쪽 또는 오른쪽에 특정문자를 채우게 된다.
                
            형식 ]
                LPAD(문자열, 길이, 채울문자)
                
            참고 ]
                만약 만들 문자열의 길이가 데이터보다 작으면 길이만큼만 문자열을 만든다.
        
        9) REPLACE()
        ==> 문자열의 특정 부분을 다른 문자열로 대치하는 함수
            
            형식 ]
                REPLACE(문자열, 찾을문자열, 교체문자열)
                
        10) TRIM()
        ==> 문자열 중에서 앞 또는 뒤에 있는 지정한 문자를 삭제하는 함수
            
            참고 ]
                중간에 있는 문자는 삭제하지 못한다.
                
            형식 ]
                TRIM(삭제할 문자 from 문자열)
                
            참고 ]
                같은 글자가 앞뒤에 있으면 모두 삭제한다.
                
            참고 ]
                간혹 데이터 앞 뒤에 공백문자가 들어간 경우가 있다.
                이런경우를 대비해서 앞 뒤에 들어간 공백 문자를 제거할 목적으로 많이 사용한다.
                
            1) LTRIM
            2) RTRIM
                
                예 ]
                    SELECT RTRIM(LTRIM('OOOOOOOOOOOOOOOOOracleOOOOOOOOOOOOOOOO', 'O'), 'O') FROM dual;
                    ==> racleOOOOOOOOOOOOOOOO ---> racle
                
        11) ASCII()
        ==> 문자에 해당하는 아스키 코드값을 알려주는 함수
            
            형식 ]
                ASCII(문자열)
                
            예 ]
                SELECT ASCII('dooly'),
                    ASCII('d')
                FROM dual;
                ==> 100, 100
            
            참고 ]
                데이터가 두글자이상이면 첫번째 문자의 아스키 코드값을 알려준다.
                
        12) CHR()
        ==> 아스키 코드값에 해당하는 문자를 알려준다.
        
            SELECT CHR(100) FROM dual;
            
        13) TRANSLATE()
        ==> REPLACE와 마찬가지로 문자열 중 지정한 부분을 다른 문자로 교체해주는 함수
            
            차이점은 REPLACE는 바꿀 문자를 전체를 바꾸는데
            이 함수는 문자단위로 바꾼다.
            문자단위로 매핑해서 교체한다.
            
            형식 ]
                TRANSLATE(문자열, 교체할문자셋, 매핑문자셋)
            
            예 ]
                SELECT
                    TRANSLATE('ABCDAADCB', 'ABCD', '1234')
                FROM
                    dual
                ;
                ==> 123411432
*/

-- 사원들의 이름을 조회하세요. 모두 소문자로 조회하세요.
SELECT
    ename 사원이름,
    LOWER(ename) "소문자 이름",
    UPPER(LOWER(ename)) "대문자 이름",
    INITCAP(LOWER(ename)) "첫문자만 대문자 이름"
FROM
    emp
;

SELECT 
    LENGTH(ename) "이름 글자 수", LENGTHB(ename) "이름 바이트 수"
FROM
    emp
;

SELECT
    LENGTH(name) "이름 글자 수", 
    LENGTHB(name) "이름 바이트 수",
    LENGTHB(SUBSTR(name, 1, 1)) 홍,
    LENGTHB(SUBSTR(name, 2, 1)) 길,
    LENGTHB(SUBSTR(name, 3, 1)) 동
FROM
    (
        SELECT '홍길동' name FROM dual
    )
;

-- 2-4 : 이름의 글자수가 4글자 또는 5글자인 사원들의 사원이름, 직급을 조회하세요.
--         이름 글자수가 적은 사람이 먼저 출력되게 하고 같으면 이름 순으로 출력하세요.
SELECT
    ename 사원이름, LENGTH(ename) 이름글자수, job 직급 
FROM
    emp
WHERE
    LENGTH(ename) IN (4, 5)
ORDER BY
    LENGTH(ename) ASC, ename
;

-- 2-5 : 사원들의 이름을 조회하는데 이름 앞에 'Mr.' 를 붙여서 조회하세요.
SELECT
    'Mr.' || ename 사원이름, CONCAT('Mr.', ename) 이름
FROM
    emp
;

SELECT
    CONCAT(sal, ename) 급여이름, sal
FROM
    emp
;

SELECT
    CONCAT(sal, deptno) 급여부서번호
FROM
    emp
;

-- 2-6 : 사원들의 이름중 3번째 글자를 꺼내서 사원이름, 꺼낸문자를 조회하세요.
SELECT
    ename 사원이름, SUBSTR(ename, 3, 1) 꺼낸문자
FROM
    emp
;

-- 사원들의 이름이 세번째 문자가 'A' 인 사원들의 사원이름, 직급을 조회하세요.
SELECT
    ename 사원이름, job 직급
FROM
    emp
WHERE
--    SUBSTR(ename, 3, 1) = UPPER('a')
    ename LIKE '__A%'
;

SELECT
    ename 사원이름, SUBSTR(ename, -2) 자른이름 
FROM
    emp
;

-- '홍길동' 에서 5바이트에서부터 맨 뒤까지 추출해서 출력하세요.
SELECT
    '홍길동' 이름, SUBSTRB('홍길동', 5) "자른 이름"
FROM
    dual
;

-- 2-7 
SELECT
    INSTR('Hong Gil Dong', 'Gil') gil
FROM
    dual
;

SELECT
    INSTR('Hong Gil Dong', 'on', 1, 2) o
FROM
    dual
;

--  음수
SELECT
    INSTR('Hong Gil Dong', 'on', -1, 2) o -- 위치값이 음수면 진행방향이 앞으로 진행
FROM
    dual
;

SELECT
    INSTR('Hong Gil Dong', 'O') o -- 없는 경우 0 반환
FROM
    dual
;

-- 사원의 이름에 'M' 이 포함된 사원들의 사원이름, 직급, 입사일을 조회하세요;
SELECT
    ename 사원이름, job 직급, hiredate 입사일
FROM
    emp
WHERE
    INSTR(ename, 'M', 1) <> 0 -- 이름에 M 이 포함되면 0 아닌 위치값을 반환해준다.
--    ename LIKE '%M%'
/*
    비교연산자
        
        =       : 같다
        
        !=      : 다르다.
        <>      : 다르다.
        ^=      : 다르다.
        
        >       : 크다
        <       : 작다
        >=      : 크거나 같다
        <=      : 작거나 같다.
        
        NOT     : 부정연산자. 논리값을 반대로 만들어주는 연산자. 
                    true, false 의 데이터에서만 사용가능
        
*/
;

-- 2-8
SELECT
    LPAD('Boa Hankok', 5, '$') 보아핸콕
FROM
    dual
;

-- 사원들의 이름 첫 두글자를 보이게하고 나머지 글자는 '#' 으로 표현해서
-- 사원이름, 변환이름, 직급, 입사일을 조회하세요.
SELECT
    ename 이름, LENGTH(ename) 이름글자수,
    SUBSTR(ename, 1, 2) 첫두글자,
    RPAD(SUBSTR(ename, 1, 2), LENGTH(ename), '#') 변환이름,
    job 직급, hiredate 입사일
FROM
    emp
;

-- 사원들의 이름을 끝 두글자만 표현하고 나머지 자리는 '*' 로 표현해서
-- 사원이름, 직급을 조회하세요.

-- 이름 세번째 문자 가공
/*
    작업순서
        1. 세번째문자 꺼낸다.       ---------------------- X
        2. 왼쪽에 '*' 두개 붙여준다.---------------------- **X
        3. 오른쪽에 이름길이만큼 '*' 붙여준다. ----------- **X***
*/
SELECT
    CONCAT('**', SUBSTR(ename, 3, 1)) "세번째 문자"
FROM
    emp
;

/*
    **X****
        1. ****     : '*'를 LENGTH(ename) - 3 만큼 문자열로 만드는데 남는 부분은 '*' 붙여준다.
        2. X****    : 1번 결과에 LENGTH(ename) - 2 의 길이로 만드는데 남는 부분에 세번째문자를 붙여준다.
        3. **X****  : 2번결과에 LENGTH(ename) 길이만큼 만들어주는데 왼쪽에 남는 부분에  '*' 분여준다.
*/

SELECT
    LPAD(
        LPAD(
            RPAD('*', LENGTH(ename) - 3, '*'), 
            LENGTH(ename) - 2, 
            SUBSTR(ename, 3, 1)
        ), 
        LENGTH(ename) , 
        '*'
    ) 가공이름,
    RPAD(
        LPAD(
            LPAD(
                RPAD('*', LENGTH(ename) - 3, '*'), 
                LENGTH(ename) - 2, 
                SUBSTR(ename, 3, 1)
            ), 
            LENGTH(ename) , 
            '*'
        ), LENGTH(ename) + LENGTH('@githrd.com'), '@githrd.com'
    ) 이메일,
    SUBSTR(ename, 3, 1) "세번째 문자"
FROM
    emp
;

SELECT
    RPAD('chopa', 100, 'chopa') chopa,
    LENGTH(RPAD('chopa', 100, 'chopa')) 길이,
    INSTR(RPAD('chopa', 100, 'chopa'),'chopa', -1) 마지막위치
FROM
    dual
;

-- 2-9
SELECT
    REPLACE('Hong Gil Dong', 'Hong', 'Gho') 고길동
FROM
    dual
;

SELECT
    REPLACE('Hong Gil Dong', 'o', 'ho') 고길동
FROM
    dual
;

-- 2 - 10
SELECT
    TRIM('H' FROM 'HHHHHHHHHHHHHHHHong Gil DongHHHHHHHHHHHHHHH') 길동
FROM
    dual
;