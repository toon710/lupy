-- scheduler
-- 1분에 한번씩 자동적으로 내용이 입력되도록 하고싶다.

-- 테이블 준비
CREATE TABLE test02(
    t_no NUMBER(6),
    t_date  DATE
);

-- 1. 프로시저 제작
CREATE OR REPLACE PROCEDURE addData1
IS
BEGIN
    INSERT INTO
        test02
    VALUES(
        (SELECT NVL(MAX(t_no) + 1, 1001) FROM test02), sysdate
    );
    commit;
END;
/

-- 프로그램 등록
BEGIN
    DBMS_SCHEDULER.CREATE_PROGRAM(
        program_name => 'BATCH_PROGRAM',
        program_action => 'addData1',
        program_type => 'STORED_PROCEDURE',
        comments => '날짜 입력',
        enabled => TRUE
    );
END;
/

-- 스케줄 등록
BEGIN
    DBMS_SCHEDULER.CREATE_SCHEDULE(
        schedule_name => 'oneMinute',
        repeat_interval => 'FREQ=SECONDLY;INTERVAL=10',
        comments => 'every one minute'
    );
END;
/

-- 잡 등록
BEGIN
    DBMS_SCHEDULER.CREATE_JOB(
        job_name => 'auto_addData',
        program_name => 'BATCH_PROGRAM',
        schedule_name => 'oneMinute',
        comments => 'every one minute add Data',
        enabled => TRUE
    );
END;
/

select t_no, to_char(t_date, 'yyyy/mm/dd HH24:mi:ss') 입력일 from test02;


exec DBMS_SCHEDULER.DROP_JOB('auto_addData');
exec DBMS_SCHEDULER.DROP_PROGRAM('BATCH_PROGRAM');
exec DBMS_SCHEDULER.DROP_SCHEDULE('oneMinute', FALSE);

--- TEMP 테이블의 SMITH 사원의 급여를 30 초마다 50 인상하세요.

