/*
    PL/SQL
*/

-- 이원종씨 정보를 회원 테이블에 추가해보자.
INSERT INTO
    member(mno, name, id, pw, mail, tel, gen, birth, ano)
VALUES(
    mno_seq.NEXTVAL,
    '이원종', 'leewj', '12345', 'leewj@githrd.com', 
    '010-2222-2222', 'M', '1990/11/09', 2
)
;

INSERT INTO
    member(mno, name, id, pw, mail, tel, gen, birth, ano)
VALUES(
    mno_seq.NEXTVAL,
    '유지은', 'yooje', '12345', 'yooje@githrd.com', 
    '010-3333-3333', 'F', '1994/05/03', 5
)
;

commit;

-- SMITH 사원의 급여를 100 이상하는 질의명령을 작성하세요.
UPDATE
    emp
SET
    sal = sal + 100
WHERE
    ename = 'SMITH'
;
-- KING 사원의 급여를 100 인하하는 질의명령을 작성하세요.
UPDATE
    emp
SET
    sal = sal + ( -100 )
WHERE
    ename = 'KING'
;

-----------------------------------------------------------------------
set serveroutput on;

DECLARE
    x NUMBER; -- 변수 선언
BEGIN
    x := 1000; -- 대입
    DBMS_OUTPUT.PUT_LINE('결과 = ');
    DBMS_OUTPUT.PUT_LINE(x);
END;
/

------------------------------------------------------------------------
-- 함수 만들기
CREATE OR REPLACE FUNCTION test_func
RETURN NUMBER AS
    x NUMBER;
BEGIN
    x := 999;
    RETURN x;
END;
/

SELECT empno, ename, test_func() FROM emp;

------------------------------------------------------------------
-- 저장 프로시저
CREATE TABLE buddy(
    name VARCHAR2(10 CHAR),
    age NUMBER(3)
);

INSERT INTO
    buddy
VALUES(
    '쵸파', 25
);

INSERT INTO
    buddy
VALUES(
    '제니', 28
);

commit;

-- 나이를 입력해서 실행하면 해당 나이를 가진 친구의 나이를 한살 빼주는 프로시저를 제작해보자.
CREATE OR REPLACE PROCEDURE change_age
    (in_age IN INTEGER)
IS
BEGIN
    UPDATE
        buddy
    SET
        age = age - 1
    WHERE
        age = in_age
    ;
    
    commit;
END;
/

exec change_age(28);















