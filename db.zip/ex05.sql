/*
    문제 1 ]
        각 부서별로 이번달 보너스가 달라진다.
        10번 부서는 급여의 10%
        20번 부서는 급여의 15%
        30번 부서는 급여의 20%
        그리고 각사원의 커미션을 더해서 지급할 예정이다.
        커미션이 없는 사원은 0으로 해서 계산해서
        사원들의
            사원이름, 직급, 부서번호, 급여, 커미션, 보너스
        를 조회하세요.
*/
SELECT
    ename 사원이름, job 직급, deptno 부서번호, sal 급여, comm 커미션, 
    DECODE(deptno, 10, sal * 0.1,
                    20, sal * 0.15,
                    30, sal * 0.2
    ) + NVL(comm, 0) 보너스1,
    CASE deptno WHEN 10 THEN sal * 0.1
                WHEN 20 THEN sal * 0.15
                WHEN 30 THEN sal * 0.2
    END + NVL(comm, 0) 보너스2,
    CASE WHEN deptno = 10 THEN sal * 0.1
         WHEN deptno = 20 THEN sal * 0.15
         WHEN deptno = 30 THEN sal * 0.2
    END + NVL(comm, 0) 보너스3
FROM
    emp
;
/*
    문제 2 ]
        입사년도를 기준으로 해서
        80년에 입사한 사람은 'A등급'
        81년에 입사한 사원은 'B등급'
        82년에 입사한 사원은 'C등급'
        그 이외의 해에 입사한 사원은 'D등급' 으로 등급을 분류해서
        사원들의
            사원이름, 직급, 입사일, 등급
        을 조회하세요.
*/
SELECT
    ename 사원이름, job 직급, hiredate 입사일, 
    DECODE(TO_CHAR(hiredate, 'yy'),
        '80', 'A등급',
        '81', 'B등급',
        '82', 'C등급',
        'D등급'
    ) 등급1,
    CASE WHEN TO_CHAR(hiredate, 'yy') = '80' THEN 'A등급'
         WHEN TO_CHAR(hiredate, 'yy') = '81' THEN 'B등급'
         WHEN TO_CHAR(hiredate, 'yy') = '82' THEN 'C등급'
         ELSE 'D등급'
    END 등급2,
    CASE TO_CHAR(hiredate, 'yy') WHEN '80' THEN 'A등급'
                                 WHEN '81' THEN 'B등급'
                                 WHEN '82' THEN 'C등급'
                                 ELSE 'D등급'
    END 등급3
FROM
    emp
;
/*
    문제 3 ]
        사원들의 이름 글자수가 4글자면 'Mr.'을 이름앞에 붙이고
                                4글자가 아니면 ' 사원'을 이름 뒤에 붙여서
        사원들의
            사원이름, 이름글자수, 조회이름
        을 조회하세요.
*/
-- 사원 이름 글자수가 4글자인 사원들의 수 조회
SELECT
    COUNT(*) 네글자이름사원수
FROM
    emp
WHERE
    LENGTH(ename) = 4
;

SELECT
    ename 사원이름, LENGTH(ename) 이름글자수, 
    DECODE(LENGTH(ename), 4, CONCAT('Mr.', ename),
                        CONCAT(ename, ' 사원')
    ) 조회이름1,
    CASE LENGTH(ename) WHEN 4 THEN CONCAT('Mr.', ename)
                       ELSE CONCAT(ename, ' 사원')
    END 조회이름2,
    CASE WHEN LENGTH(ename) = 4 THEN CONCAT('Mr.', ename)
         ELSE CONCAT(ename, ' 사원')
    END 조회이름3
FROM
    emp
;
/*
    문제 4 ]
        부서번호가 10 또는 20번이면 급여 + 커미션의 으로 지급하고
        단, 커미션이 없는 사원은 커미션을 0으로 계산한다.
        그 이외의 부서는 급여만 지급할 예정이다.
        사원들의
            사원번호, 사원이름, 부서번호, 급여, 커미션, 지급액
        을 조회하세요.
*/
SELECT
    empno 사원번호, ename 사원이름, deptno 부서번호, sal 급여, comm 커미션, 
    CASE WHEN deptno IN (10, 20) THEN sal + NVL(comm, 0)
        ELSE sal
    END 지급액1,
    CASE deptno WHEN 10 THEN sal + NVL(comm, 0)
                WHEN 20 THEN sal + NVL(comm, 0)
                ELSE sal
    END 지급액2,
    DECODE(deptno, 10, sal + NVL(comm, 0),
                   20, sal + NVL(comm, 0),
                    sal
    ) 지급액3
FROM
    emp
;
/*
    문제 5 ]
        입사요일이 '토요일', '일요일' 인 사원은 급여를 20% 인상하고
        그 이외의 요일에 입사한 사원은 급여의 10%를 인상해서
        사원들의
            사원이름, 입사일, 입사요일, 급여, 지급급여
        를 조회하세요.
*/
SELECT
    ename 사원이름, hiredate 입사일, TO_CHAR(hiredate, 'day') 입사요일, sal 급여, 
    CASE WHEN TO_CHAR(hiredate, 'DAY') IN ('토요일', '일요일') THEN sal * 1.2
        ELSE sal * 1.1
    END 지급급여1,
    CASE TO_CHAR(hiredate, 'DAY') WHEN '토요일' THEN sal * 1.2
                                  WHEN '일요일' THEN sal * 1.2
                                  ELSE sal * 1.1
    END 지급급여2,
    DECODE(TO_CHAR(hiredate, 'DAY'), '토요일', sal * 1.2,
                                     '일요일', sal * 1.2,
                                     sal * 1.1
    ) 지급급여3
FROM
    emp
;
/*
    문제 6 ]
        근무 개월수가 500개월 이상이면 커미션을 500 추가하고
        500개월 미만이면 커미선을 현재 커미션으로 지급할 예정이다.
        사원들의
            사원이름, 입사일, 커미션, 근무개월수, 지급커미션
        을 조회하세요.
        
        단, 커미션이 없으면 0으로 계산하세요.
        
*/
SELECT
    ename 사원이름, hiredate 입사일, comm 커미션, FLOOR(MONTHS_BETWEEN(sysdate, hiredate)) 근무개월수,
    CASE WHEN MONTHS_BETWEEN(sysdate, hiredate) >= 500 THEN NVL(comm, 0) + 500
        ELSE NVL(comm, 0)
    END 지급커미션1,
    CASE FLOOR(MONTHS_BETWEEN(sysdate, hiredate) / 500) WHEN 0 THEN NVL(comm, 0) 
        ELSE NVL(comm, 0) + 500
    END 지급커미션2,
    DECODE(FLOOR(MONTHS_BETWEEN(sysdate, hiredate) / 500), 0, NVL(comm, 0),
                                                           NVL(comm, 0) + 500
    ) 지급커미션3
FROM
    emp
;

SELECT
    ename 사원이름, hiredate 입사일, comm 커미션, FLOOR(MONTHS_BETWEEN(sysdate, hiredate)) 근무개월수,
    CASE FLOOR(MONTHS_BETWEEN(sysdate, hiredate) / 500) WHEN 0 THEN NVL(comm, 0) 
        ELSE NVL(comm, 0) + 500
    END 지급커미션
FROM
    emp
;

SELECT
    ename 사원이름, hiredate 입사일, comm 커미션, FLOOR(MONTHS_BETWEEN(sysdate, hiredate)) 근무개월수,
    CASE WHEN MONTHS_BETWEEN(sysdate, hiredate) >= 500 THEN NVL(comm, 0) + 500
        ELSE NVL(comm, 0)
    END 지급커미션
FROM
    emp
;
/*
    문제 7 ]
        이름 글자수가 5글자 이상인 사원은 
        앞 3글자를 이름 길이만큼으로 만들고 
        '*' 를 3글자 이외의 부분에 붙여서 조회하고
        4글자 이하인 사원은 이름을 그대로 조회하도록
        사원들의
            사원이름, 이름글자수, 조회이름
        을 조회하세요.
*/
SELECT
    ename 사원이름, LENGTH(ename) 이름글자수, 
    CASE WHEN LENGTH(ename) >= 5 THEN RPAD(SUBSTR(ename, 1, 3), LENGTH(ename), '*')
        ELSE ename
    END 조회이름
FROM
    emp
;

SELECT
    ename 사원이름, LENGTH(ename) 이름글자수, 
    DECODE(FLOOR(LENGTH(ename) / 5), 0, ename,
                                    RPAD(SUBSTR(ename, 1, 3), LENGTH(ename), '*')
    ) 조회이름
FROM
    emp
;
--------------------------------------------------------------------------------
-- 그룹 함수
/*
    문제 1 ]
        사원들의 직급의 갯수를 조회하세요.
*/
SELECT
    COUNT(DISTINCT job) 직급갯수
FROM
    emp
;
/*
    문제 2 ]
        커미션을 받는 사원들의 수를 조회하세요.
*/
SELECT
    COUNT(comm) 커미션받는사원수
FROM
    emp
;

-- COUNT(*) 로 처리
SELECT
    COUNT(*) 커미션받는사람
FROM
    emp
WHERE
    comm IS NOT NULL
;


-- GROUP BY
/*
    문제 3 ]
        부서별 최소 급여를 조회하세요.
*/
SELECT
    job 직급, MIN(sal) 최소급여
FROM
    emp
GROUP BY
    job
;
/*
    문제 4 ]
        직급별 급여의 합계와 평균급여를 조회하세요.
*/
SELECT
    job 직급, SUM(sal) 직급급여합계, TRUNC(AVG(sal), 2) 직급급여평균
FROM
    emp
GROUP BY
    job
;
/*
    문제 5 ]
        입사년도별 평균급여와 급여합계를 조회하세요.
*/
SELECT
    TO_CHAR(hiredate, 'YYYY') 입사년도, TRUNC(AVG(sal), 2) 급여평균, SUM(sal) 급여합계
FROM
    emp
GROUP BY
    TO_CHAR(hiredate, 'YYYY')
;
/*
    문제 6 ]
        입사년도별 입사원 수를 조회하세요.
*/
SELECT
    TO_CHAR(hiredate, 'YYYY') 입사년도, COUNT(*) 입사원수
FROM
    emp
GROUP BY
    TO_CHAR(hiredate, 'YYYY')
;
/*
    문제 7 ]
        사원 이름의 글자수가 4, 5글자인 사원들의 수를 조회하세요.
        단, 이름 글자수별로 그룹화해서 처리하세요.
*/
SELECT
    LENGTH(ename) 이름글자수, COUNT(*) 사원수
FROM
    emp
WHERE
    LENGTH(ename) IN (4, 5)
GROUP BY
    LENGTH(ename)
;

SELECT
    LENGTH(ename) 이름글자수, COUNT(*) 사원수
FROM
    emp
GROUP BY
    LENGTH(ename)
HAVING
    LENGTH(ename) IN (4, 5)
;
/*
    문제 8 ]
        81년 입사한 사원들의 수를 직급별로 조회하세요.
*/
SELECT
    job 직급, COUNT(*) 사원수
FROM
    emp
WHERE
    TO_CHAR(hiredate, 'yy') = '81'
GROUP BY
    job
ORDER BY
    job
;

SELECT
    job 직급, COUNT(*) 사원수
FROM
    emp
GROUP BY
    TO_CHAR(hiredate, 'yy'), job
HAVING
    TO_CHAR(hiredate, 'yy') = '81'
ORDER BY
    job
;
/*
    문제 9 ]
        사원 이름 글자수가 4, 5글자인 사원의 수를 부서별로 조회하세요.
        단, 사원수가 한사람 미만인 부서는 제외하세요.
*/
SELECT
    deptno 부서번호, COUNT(*) 부서원수
FROM
    emp
WHERE
    LENGTH(ename) IN (4, 5)
GROUP BY
    deptno
HAVING
    COUNT(*) > 0
;

SELECT
    deptno 부서번호, COUNT(*) 부서원수
FROM
    emp
GROUP BY
    LENGTH(ename), deptno
HAVING
    LENGTH(ename) IN (4, 5)
    AND COUNT(*) > 0
;
/*
    문제 10 ]
        81년 입사한 사원의 전체 급여를 직급별로 조회하세요.
        단, 직급별 평균 급여가 1000 미만인 직급은 제외하세요.
*/
SELECT
    job 직급, SUM(sal) 급여합계
FROM
    emp
WHERE
    TO_CHAR(hiredate, 'YY') = '81'
GROUP BY
    job
HAVING
    AVG(sal) >= 1000
;
/*
    문제 11 ]
        81년도 입사한 사원들의 급여합계를 사원 이름 글자수별로 그룹화하세요.
        단, 총급여가 2000 미만인 경우는 제외하고
        총급여가 높은 순서으로 조회하세요.
*/
SELECT
    LENGTH(ename), SUM(sal)
FROM
    emp
WHERE
    TO_CHAR(hiredate, 'yy') = '81'
GROUP BY
    LENGTH(ename)
HAVING
    SUM(sal) >= 2000
;
/*
    문제 12 ]
        사원 이름 글자수가 4, 5글자인 사원들의 부서별 사원수를 조회하세요.
        단, 사원수가 0인 경우는 제외하세요.
        부서번호 순서대로 정렬해서 조회하세요.
*/

SELECT
    deptno 부서번호, COUNT(*) 사원수
FROM
    emp
WHERE
    LENGTH(ename) IN (4, 5)
GROUP BY
    deptno
HAVING
    COUNT(*) > 0
ORDER BY
    deptno
;


--------------------------------------------------------------








