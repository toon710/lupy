/*

***
1. 결과물이 오직 한개의 데이터인 경우(단일행 단일컬럼으로 조회되는 경우)
    1) SELECT 절에 사용할 수 있다.
    2) WHERE 조건절에 사용할 수 있다.
    3) UPDATE 입력 명령에도 사용
        예 ]
            -- SMITH 사원의 소속 부서의 최고급여
            
            SELECT
                MAX(sal)
            FROM
                emp
            WHERE
                deptno =    (
                                SELECT 
                                    deptno 
                                FROM 
                                    emp 
                                WHERE 
                                    ename = 'SMITH'
                            )
            ;
            
            조회된 데이터로 SMITH 사원의 급여를 수정
            UPDATE
                temp1
            SET
                sal =   (
                            SELECT
                                MAX(sal)
                            FROM
                                temp1
                            WHERE
                                deptno =    (
                                                SELECT 
                                                    deptno 
                                                FROM 
                                                    temp1
                                                WHERE 
                                                    ename = 'SMITH'
                                            )
                        )
            WHERE
                ename = 'SMITH'
            ;
            
            commit;
    4) UPDATE 조건절에도 사용
    5) INSERT 입력 명령에도 사용
        TEMP3에 TEMP1의 SMITH 사원의 데이터를 조회해서 추가하자.
        
        INSERT INTO
            temp3
        SELECT
            *
        FROM
            temp1
        WHERE
            ename = 'SMITH'
        ;
        
        -- TEST01에 SMITH의 사원번호와 직급이름을 추가하세요.
        INSERT INTO
            test01
        VALUES(
            (SELECT empno FROM temp1 WHERE ename = 'SMITH'),
            (SELECT job FROM temp1 WHERE ename = 'SMITH')
        );
    6) DELETE 명령 조건식에도 사용할 수 있다.
        
        DELETE FROM 
            test01 
        WHERE 
            no =    (
                        SELECT
                            empno
                        FROM
                            temp1
                        WHERE
                            ename = 'SMITH'
                    )
        ;
        
-------------------------------------------------------------------------------
2. 서브질의의 결과가 여러행 단일 컬럼으로 조회되는 경우
==> 조건절에 사용가능
    IN, ANY, ALL, 
    
    EXISTS 연산자를 사용한다.
    
    참고 ]
        IN
        ==> 여러개의 데이터중 하나마 맞으면 되는 경우
            오직 동등비교만 사용하는 처리
            
        ANY
        ==> 여러개의 데이터중 하나만 맞으면 되는 경우
        SELECT
            empno, ename, job, sal
        FROM
            temp1
        WHERE
            sal > ANY (
                        SELECT
                            TRUNC(AVG(sal), 2)
                        FROM
                            temp1
                        GROUP BY
                            deptno
                        )
        ;
        
        SELECT
            empno, ename, job, sal
        FROM
            temp1
        WHERE
            sal > (
                        SELECT
                            MIN(TRUNC(AVG(sal), 2))
                        FROM
                            temp1
                        GROUP BY
                            deptno
                        )
        ;
        
        ALL
        ==> 여러개의 데이터 모두 맞으면 되는 경우
        
        -- temp1의 사원들의 부서별 평균급여 조회
            SELECT
                TRUNC(AVG(sal), 2)
            FROM
                temp1
            GROUP BY
                deptno
            ;
        -- 모든 부서의 평균급여보다 급여가 높은 사람을 조회하세요.
        SELECT
            empno, ename, job, sal
        FROM
            temp1
        WHERE
            sal > ALL (
                        SELECT
                            TRUNC(AVG(sal), 2)
                        FROM
                            temp1
                        GROUP BY
                            deptno
                        )
            -- sal > (1566.66, 2615, 2916.66)
        ;
            
        EXISTS
        ==> 서브질의의 결과가 존재하면 TRUE로 처리된다. 존재하지 않으면 FALSE로 처리
        
        -- temp1 테이블에서 30번 부서 소속 사원이 존재하면 
        --  모든 사원들의 사원이름, 직급, 부서번호를 조회하세요.
        
            SELECT
                ename, job, deptno
            FROM
                temp1
            WHERE
                EXISTS (
                            SELECT
                                ename
                            FROM
                                temp1
                            WHERE
                                deptno = 40
                        )
            ;
*/

-- 예제 ] 직급이 MANAGER인 사원과 같은 부서에 소속된 사원들의 
--          사원이름, 직급, 부서번호 를 조회하세요.

-- 1. 직급이 MANAGER인 사원들의 부서번호
SELECT
    deptno
FROM
    temp1
WHERE
    job = 'MANAGER'
;

-- 2. 소속된 사원들 조회
SELECT
    ename 사원이름, job 직급, deptno 부서번호
FROM
    temp1
WHERE
    deptno = ANY (
                    SELECT
                        deptno
                    FROM
                        temp1
                    WHERE
                        job = 'MANAGER'
                 )
;
SELECT
    ename 사원이름, job 직급, deptno 부서번호
FROM
    temp1
WHERE
    deptno IN (
                    SELECT
                        deptno
                    FROM
                        temp1
                    WHERE
                        job = 'MANAGER'
                 )
;

/*
    부서별 평균급여를 이용해서
    하나라도 부서의 평균급여보다 급여가 높은 사원의
    사원이름, 급여, 부서번호 를 조회하세요.
*/

SELECT
    ename 사원이름, sal 급여, deptno 부서번호
FROM
    temp1
WHERE
    sal > any   (
                    SELECT
                        AVG(sal)
                    FROM
                        emp
                    GROUP BY
                        deptno
                )
;

SELECT
    ename 사원이름, sal 급여, deptno 부서번호
FROM
    temp1
WHERE
    sal > (
                    SELECT
                        MIN(AVG(sal))
                    FROM
                        emp
                    GROUP BY
                        deptno
                )
;

/*
--------------------------------------------------------------------------------
3. 단일행 다중컬럼으로 조회되는 서브질의
    ==> UPDATE 명령에서 데이터를 여러 컬럼에 동시에 수정할 때 사용할 수 있다.
    
    형식 ]
        UPDATE
            테이블이름
        SET
            (필드이름1, 필드이름2, ...) = ( 서브질의 )
        WHERE
            조건식
        ;
        
    의미 ]
        서브질의의 첫번째 컬럼이 필드이름1에 입력되고
                    두번째 컬럼이 필드이름2에 입력되고
                    ...

        예 ] temp3의 SMITH 사원의 직급과 부서를 
             temp1의 BLAKE 사원의 직급과 부서와 동일하게 수정하세요.
             
             UPDATE
                temp3
             SET
                (job, deptno) = (
                                    SELECT
                                        job, deptno
                                    FROM
                                        temp1
                                    WHERE
                                        ename = 'BLAKE'
                                )
             WHERE
                ename = 'SMITH'
             ;

--------------------------------------------------------------------------------
4. 다중행 다중컬럼으로 조회되는 서브질의
==> INSERT 명령에서 여러개의 데이터를 한번에 입력할 때 사용한다.

    10번 부서 사원들의정보를 temp3에 복사하세요.
    INSERT INTO
        temp3
    SELECT
        *
    FROM    
        temp1
    WHERE
        deptno = 10
    ;
    
*/

/*
    문제 1 ]
        사원이름이 'MILLER'인 사원과 직급이 같은 사원들의
            사원이름, 직급, 입사일 을 조회하세요.
*/
SELECT
    ename 사원이름, job 직급, hiredate 입사일
FROM
    emp
WHERE
    job = (
                SELECT
                    job
                FROM
                    emp
                WHERE
                    ename = 'MILLER'
            )
;
/*
    문제 2 ]
        회사 평균급여보다 급여를 적게 받는 사원들의
        사원이름, 직급, 급여, 입사일을 조회하세요.
*/

/*
    문제 3 ]
        사원중 최고급여 사원의 
            사원번호, 사원이름, 직급, 상사번호, 입사일을 조회하세요.
*/
SELECT
    empno 사원번호, ename 사원이름, job 직급, 
    mgr 상사번호, hiredate 입사일
FROM
    emp
WHERE
    sal = (
                SELECT
                    MAX(sal)
                FROM
                    emp
            )
;
/*
    문제 4 ]
        KING 사원보다 이후에 입사한 사원들의
        사원번호, 사원이름, 직급, 입사일을 조회하세요.
*/
SELECT
    empno 사원번호, ename 사원이름, job 직급, hiredate 입사일
FROM
    emp
WHERE
    hiredate > (
                    SELECT
                        hiredate
                    FROM
                        emp
                    WHERE
                        ename = 'KING'
                )
ORDER BY
    hiredate
;
/*
    문제 5 ]
        각 사원들의 회사평균급여와 급여의 차를 조회하세요.
            
            사원이름, 회사평균급여, 급여, 급여차
        로 조회하세요.
*/

SELECT
    ename 사원이름, 
    (
        SELECT
            AVG(sal)
        FROM
            emp
    ) 회사평균급여, 
    sal 급여, 
    TRUNC(sal - (
                    SELECT
                        AVG(sal)
                    FROM
                        emp
                ), 2) 급여차
FROM
    emp
;




SELECT
    ename, sal - (SELECT sal FROM temp1 WHERE ename = 'SMITH') "스미스봉급과 차"
FROM
    temp1
;



/*
    문제 6 ]
        최고 급여 사원이 소속된 부서에 속한 사원들의 
            사원이름, 직급, 부서번호, 급여
        를 조회하세요.
*/

-- 최고 급여
SELECT
    MAX(sal)
FROM
    emp
;
-- 최고 급여 수급자의 부서번호
SELECT
    deptno
FROM
    emp
WHERE
    sal = (
                SELECT
                    MAX(sal)
                FROM
                    emp
            )
;

-- 해당 부서 소속의 정보 검색
SELECT
    empno 사원이름, job 직급, deptno 부서번호, sal 급여
FROM
    emp
WHERE
    deptno IN   (
                    SELECT
                        deptno
                    FROM
                        emp
                    WHERE
                        sal = (
                                    SELECT
                                        MAX(sal)
                                    FROM
                                        emp
                                )
                )
;

/*
    문제 7 ]
        커미션을 받는 사원이 한명이라도 있는 부서에 소속된 사원들의
            사원이름, 직급, 커미션, 부서번호
        를 조회하세요.
*/
SELECT
    deptno
FROM
    emp
GROUP BY
    deptno
HAVING
    COUNT(comm) > 0
;
SELECT
    ename 사원이름, job 직급, comm 커미션, deptno 부서번호
FROM
    emp
WHERE
    deptno IN (
                    SELECT
                        deptno
                    FROM
                        emp
                    GROUP BY
                        deptno
                    HAVING
                        COUNT(comm) > 0
                )
;
/*
    문제 8 ]
        회사 평균 급여보다 급여가 높고 이름이 4자 또는 5글자인 사원들의
        사원이름, 급여, 부서번호를 조회하세요.
*/
-- 회사 평균 급여
SELECT
    AVG(sal)
FROM
    emp
;

SELECT
    ename 사원이름, sal 급여, deptno 부서번호,
    (
        SELECT
            TRUNC(AVG(sal), 2)
        FROM
            emp
    ) 회사평균급여
FROM
    emp
WHERE
    sal > ( 
            SELECT
                AVG(sal)
            FROM
                emp
           )
    AND LENGTH(ename) IN (4, 5)
;
/*
    문제 9 ]
        이름길이가 4글자인 사원과 같은 직급을 가진 사원들의
        사원이름, 직급, 부서번호
        를 조회하세요.
*/
-- 이름길이가 4글자인 사원들의 직급 조회
SELECT
    job
FROM
    emp
WHERE
    LENGTH(ename) = 4
;

SELECT
    ename 사원이름, job 직급, deptno 부서번호
FROM
    emp
WHERE
    job IN (
            SELECT
                job
            FROM
                emp
            WHERE
                LENGTH(ename) = 4
            )
;
/*
    문제 10 ]
        입사 년도가 81년이 아닌 사원들과 같은 부서에 소속된 사원들의
            사원번호, 사원이름, 직급, 입사년도, 부서번호
        를 조회하세요.
*/

/*
    문제 11 ]
        직급별 평균 급여보다 하나라도 많이 받는 사원의
        사원번호, 사원이름, 급여[, 직급평균급여 ]
        를 조회하세요.
*/
-- 직급별 평균 급여 조회
SELECT
    AVG(sal)
FROM
    emp
GROUP BY
    job
;

-- 하나라도 급여가 높은 사원
SELECT
    empno 사원번호, ename 사원이름, sal 급여, 
    (
        SELECT
            TRUNC(AVG(sal), 2)
        FROM
            emp
        WHERE
            job = e.job
    ) 직급평균급여
FROM
    emp e
WHERE
    sal > ANY   (
                SELECT
                    AVG(sal)
                FROM
                    emp
                GROUP BY
                    job
                )
;

/*
     질의 명령을 작성할 때
     테이블이름, 컬럼이름은 소속을 밝혀주는 것이 원칙이다.
     
     그런데 접속계정이 소유한 테이블의 경우는 
     소속을 안밝혀도 상관없다.
     
     scott.emp.empno 이렇게 하는 것이 원칙이나
     우리는 scott 계정으로 접속해서 질의명령을 실행할 것이므로
     그 계정이 소유한 테이블만 사용할 수 있게된다.
     
     따라서 다른 계정이 소유한 테이블의 경우
        계정이름.테이블이름
    의 형식으로 사용해야 한다.
*/


/*
    문제 12 ]
        모든 년도별 입사자의 평균 급여보다 급여가 많은 사원의
        사원이름, 입사년도, 급여, 년도별최고평균급여
        를 조회하세요.
*/
SELECT
    TO_CHAR(hiredate, 'YY') year, AVG(sal) avg, 
    MAX(AVG(sal)) max
FROM
    emp
GROUP BY
    TO_CHAR(hiredate, 'YY')
; -- 그룹기준이 다르기때문에 오류발생

-- 년도별 평균급여
SELECT
    AVG(sal)
FROM
    emp
GROUP BY
    TO_CHAR(hiredate, 'YY')
;

--  사원정보조회
SELECT
    ename 사원이름, TO_CHAR(hiredate, 'YY') 입사년도, sal 급여, 
    (
        SELECT
            MAX(AVG(sal))
        FROM
            emp
        GROUP BY
            TO_CHAR(hiredate, 'YY')
    ) 년도별최고평균급여
FROM
    emp
WHERE
    sal > ALL (
                    SELECT
                        AVG(sal)
                    FROM
                        emp
                    GROUP BY
                        TO_CHAR(hiredate, 'YY')
                )
;


/*
    문제 13 ]
        최고 급여자의 이름 글자수와 같은 글자수의 이름을 가지는 사원이 존재하면
        모든 사원들의
            사원이름, 직급, 부서번호
        를 조회하고
        그렇지않으면 조회되는 것이 없도록하세요.
*/

/*
    문제 14 ]
        소속 부서의 평균 급여보다 급여가 적은 사원들의
        사원이름, 급여, 부서번호, 부서평균급여
        를 조회하세요.
*/

/*
    문제 15 ]
        부서원수가 제일 많은 부서의 사원들중 
        최고 급여 수급자의
            사원이름, 부서번호, 급여, 부서최고급여, 부서원수
        를 조회하세요.
*/

/*
    bonus ]
        사원들의
            사원번호, 사원이름, 직급, 상사번호, 상사이름, 부서번호
        를 조회하세요.
*/

SELECT
    empno 사원번호, ename 사원이름, job 직급, mgr 상사번호, 
    (SELECT ename FROM emp WHERE empno = e.mgr) 상사이름,
    deptno 부서번호
FROM
    emp e
;


SELECT
    COUNT(comm) cnt
FROM
    emp
WHERE
    comm IS NOT NULL
    AND deptno = 10
;

SELECT
    MAX(COUNT(*))
FROM
    emp
GROUP BY
    deptno
;

--------------------------------------------------------------------------------
/*
    JOIN
    ==> 두개 이상의 테이블에 있는 데이터를 동시에 조회하는 방법
    
        참고 ]
            오라클은 ER 형태의 데이터베이스라고 한다.
            ER 형태란?
                앤티티 끼리의 관계를 이용해서 데이터를 보관하고 관리한다.
                
            예 ]
                쇼핑몰의 판매관리의 경우
                
                누가       :  이름, 주소, 전화번호,...
                무엇을     :   상품이름, 가격, 브랜드, ...
                몇개       :
                언제       :
                
                쵸파  고잉메리호   010-1111-1111   솜사탕     1500    2       22/12/20
                루피  고잉메리호   010-2222-2222   고기      15000    30      22/12/20
                쵸파  고잉메리호   010-1111-1111   주사기     1000    10      22/12/20
                ....
                
                이런형태로 보관해야하지만
                중복데이터는 다른 테이블(앤티티)로 보관하도록 한다.
                
                구매테이블
                쵸파  솜사탕   2       22/12/20
                루피  고기     30      22/12/20
                쵸파  주사기   10      22/12/20
                
                구매자테이블
                쵸파  고잉메리호   010-1111-1111
                루피  고잉메리호   010-2222-2222
                
                상품테이블
                솜사탕     1500    리어카
                고기      15000    정육점
                주사기     1000    주사기공장
                
        참고 ]
            오라클은 처음부터 여러개의 테이블을 동시에 검색하는 기능은 
            이미 가지고 있다.
            ==> 이처럼 두개 이상의 테이블을 동시에 검색하면
                Cartesian Product 가 만들어진다.
                
        조인이란?
            생성된 Cartesian Product 중에서
            원하는 결과물만 뽑아내는 기술
            
--------------------------------------------------------------------------------
종류 ]
    
    1. Inner Join   <= Cartesian Product 내에서 데이터를 추출해내는 조인
    2. Outer Join   <= Cartesian Product에 없는 데이터를 추출해내는 조인
        ==> 데이터가 없어서  null 로 표현되어야 할 테이블 컬럼뒤에 (+) 를 붙여준다.
        
    3. Self Join
    ==> 조인 사용할 테이블을 하나의 테이블로 사용하는 경우 이것을 Self Join 이라 한다.
    
    4. EQUI JOIN    ==> 동등비교연산자(=) 를 이용해서 조인하는 조인
    
    5. NON EQUI JOIN    ==> 동등비교연산자(=)를 사용하지 않고 조인하는 조인
   
참고 ]
    조인에서도 다른 조건식을 얼마든지 적용시킬 수 있다.
    
참고 ]
    여러개의 테이블을 조인할 경우 동일한 컬럼이름이 존재하면
    반드시 컬럼의 소속테이블을 밝혀줘야 한다.
    
    형식 ]
        테이블이름.컬럼이름
    테이블이름에 별칭이 부여된 경우는
        별칭이름.컬럼이름
    의 형식으로 사용할 수 있다.
    
*****
참고 ]
    서브질의의 결과도 테이블처럼 사용할 수 있다.
    이처럼 FROM 절에 사용되는 서브질의를 INLINE VIEW 라 부른다.

*/

CREATE TABLE color(
    cno NUMBER(2)
        CONSTRAINT COLOR_NO_PK PRIMARY KEY,
    cname VARCHAR2(20 CHAR)
        CONSTRAINT COLOR_NAME_NN NOT NULL,
    ccode VARCHAR2(7 CHAR)
        CONSTRAINT COLOR_CODE_UK UNIQUE
        CONSTRAINT COLOR_CODE_NN NOT NULL
);

INSERT INTO
    color
VALUES(
    11, 'red', '#FF0000'
);
INSERT INTO
    color
VALUES(
    12, 'green', '#00FF00'
);
INSERT INTO
    color
VALUES(
    13, 'blue', '#0000FF'
);

CREATE TABLE kcolor(
    kcno NUMBER(2)
        CONSTRAINT KCOLOR_NO_PK PRIMARY KEY,
    kcname VARCHAR2(20 CHAR)
        CONSTRAINT KCOLOR_NAME_NN NOT NULL,
    kccode VARCHAR2(7 CHAR)
        CONSTRAINT KCOLOR_CODE_UK UNIQUE
        CONSTRAINT KCOLOR_CODE_NN NOT NULL
);

INSERT INTO
    kcolor
VALUES(
    11, '빨강', '#FF0000'
);
INSERT INTO
    kcolor
VALUES(
    12, '초록', '#00FF00'
);
INSERT INTO
    kcolor
VALUES(
    13, '파랑', '#0000FF'
);

commit;

SELECT * FROM kcolor;

SELECT
    kcname
FROM
    color, kcolor
WHERE
    cno = kcno  -- 조인에 사용되는 조건 : 조인조건
    and cname = 'red'   -- 일반 조건
;

-- 사원들의 사원이름, 상사이름, 부서번호를 조회하세요.
SELECT
    e.ename 사원이름, NVL(s.ename, '상사없음') 상사이름, e.deptno 부서번호
FROM
    emp e, emp s -- self join
WHERE
    e.mgr = s.empno(+)
;

SELECT
    e.ename 사원이름, NVL(s.ename, '상사없음') 상사이름, e.deptno 부서번호
FROM
    emp e, emp s -- self join
WHERE
    e.mgr(+) = s.empno
;

SELECT
    e.empno, e.ename, e.mgr, s.empno, s.ename
FROM
    emp e, emp s
;


/*
7844	TURNER
7521	WARD
7654	MARTIN
7499	ALLEN
7934	MILLER
7369	SMITH
7876	ADAMS
7900	JAMES

*/

SELECT
    empno, ename
FROM
    emp
WHERE
    empno NOT IN    (
                    SELECT
                        DISTINCT mgr
                    FROM
                        emp
                    WHERE
                        mgr IS NOT NULL
                )
;


-- 사원들의 사원이름, 직급, 부서이름 을 조회하세요. : INNER JOIN. EQUI JOIN
SELECT
    ename, job, e.deptno, d.deptno, dname
FROM
    emp e, dept d
WHERE
    e.deptno = d.deptno
;

-- 81년 입사한 사원들의 사원이름, 직급, 입사일, 부서이름, 부서위치를 조회하세요.

SELECT
    ename 사원이름, job 직급, hiredate 입사일, dname 부서이름, loc 부서위치
FROM
    emp, dept
WHERE
    -- 조인조건
    emp.deptno = dept.deptno
    -- 일반조건 추가
    AND TO_CHAR(hiredate, 'YY') = '81'
;

-- NON EQUI JOIN
-- 사원들의 사원이름, 직급, 급여, 급여등급을 조회하세요.

SELECT
    ename 사원이름, job 직급, sal 급여, grade 급여등급, losal, hisal
FROM
    emp, salgrade
WHERE
--    sal >= losal AND sal <= hisal
    sal BETWEEN losal AND hisal
;

-- 참고 ] 여러 테이블을 동시에 조인 할 수 있다.
-- 사원들의 사원이름, 직급, 급여, 부서이름, 급여등급을 조회하세요.
SELECT
    ename 사원이름, job 직급, sal 급여, dname 부서이름, grade 급여등급
FROM
    emp e, dept d, salgrade
WHERE
    sal BETWEEN losal AND hisal
    AND e.deptno = d.deptno
;

-- 서브질의의 결과를 조인해보자.
-- 사원들의 사원이름, 직급, 급여, 소속부서평균급여, 소속부서최소급여, 소속부서최대급여

-- 부서별 그룹화
SELECT
    ename 사원이름, job 직급, sal 급여, 
    avg 소속부서평균급여, min 소속부서최소급여, max 소속부서최대급여
FROM
    emp, (
                SELECT
                    deptno dno, AVG(sal) avg, MIN(sal) min, MAX(sal) max
                FROM
                    emp
                GROUP BY
                    deptno
            )
WHERE
    deptno = dno
;


--------------------------------------------------------------------------------------

-- join 문제
/*
    문제 1 ]
        직급이 MANAGER인 사원의
            사원이름, 직급, 입사일, 급여, 부서이름
        을 조회하세요.
*/

/*
    문제 2 ]
        급여가 가장 낮은 사원의
            사원이름, 직급, 입사일, 급여, 부서이름, 부서위치를 조회하세요.
*/

/*
    문제 3 ]
        이름 글자수가 5글자인 사원의
            사원이름, 직급, 입사일, 급여, 급여등급을 조회하세요.
*/

/*
    문제 4 ]
        입사년도가 81년이고 직급이 MANAGER인 사원들의
        사원이름, 직급, 입사일, 급여, 급여등급, 부서이름, 부서위치 를 조회하세요.
*/

/*
    문제 5 ]
        사원들의
            사원이름, 직급, 급여, 상사이름, 급여등급을 조회하세요.
        상사가 없는 사원은 '상사없음' 으로 표현되게 하세요.
*/

/*
    문제 6 ]
        사원들의
            사원이름, 직급, 급여, 상사이름, 부서이름, 부서위치, 급여등급을 조회하세요.
*/

/*
    문제 7 ]
        사원들의 
                사원이름, 직급, 급여, 상사이름, 부서이름, 부서위치, 급여등급을 조회하세요.
        단, 급여가 회사평균급여보다 많은 사원만 조회하세요.
*/

/*
    
    
    문제 8 ]
        부서급여합계가 가장 높은 부서에 근무하는 사원중
        부서 평균 급여보다 적게 받는 사원들의
            사원번호, 사원이름, 직급, 부서이름, 급여등급, 
            부서급여합계, 부서평균급여, 부서원수
        를 조회하세요.
*/








