set serveroutput on;

-- 사원이름을 입력해서 실행하면
--  사원이름, 직급, 급여, 입사일
-- 을 출력해주는 프로시저를 작성하세요.

CREATE OR REPLACE PROCEDURE enameInfo
    (name   IN emp.ename%TYPE)
IS
    cop     emp%ROWTYPE;
BEGIN
    DBMS_OUTPUT.ENABLE;
    
    SELECT
        ename, job, sal, hiredate
    INTO
        cop.ename, cop.job, cop.sal, cop.hiredate
    FROM
        emp
    WHERE
        ename = name
    ;
    
    -- print
    DBMS_OUTPUT.PUT_LINE('사원이름 : ' || cop.ename);
    DBMS_OUTPUT.PUT_LINE('사원직급 : ' || cop.job);
    DBMS_OUTPUT.PUT_LINE('사원급여 : ' || cop.sal);
    DBMS_OUTPUT.PUT_LINE('입 사 일 : ' || TO_CHAR(cop.hiredate, 'YYYY/MM/DD'));
END;
/

execute enameInfo('SMITH');

CREATE OR REPLACE PROCEDURE upsal_nameLen
    (len IN NUMBER)
IS
    temp test00%ROWTYPE;
BEGIN
    DBMS_OUTPUT.ENABLE;

/*  
    SELECT
        ename, sal
    INTO
        temp.ename, temp.sal
    FROM
        test00
    WHERE
        LENGTH(ename) = len
    ;
    
    DBMS_OUTPUT.PUT_LINE(temp.ename || ' - ' || temp.sal);
*/

    UPDATE
        test00
    SET
        sal = sal * 1.1
    WHERE
        LENGTH(ename) = len
    ;
    
    DBMS_OUTPUT.PUT_LINE('이름 글자수가 ' || len || ' 인 사원들 급여 10% 인상 완료!');
EXCEPTION WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('*** 이름 글자수가 ' || len || ' 인 사원들 급여 인상 실패! ***');
END;
/

exec upsal_nameLen(5);


----------------------------------------------------------------------------------------------------
-- 부서번호를 알려주면 그 부서에 소속된 사원의 이름, 직책, 급여를 출력하도록 프로시저를 만드세요.

CREATE OR REPLACE PROCEDURE dnoInfo
    (dno    IN test00.deptno%TYPE)
IS
    TYPE name IS TABLE OF test00.ename%TYPE
    INDEX BY BINARY_INTEGER;
    
    TYPE duty IS TABLE OF test00.job%TYPE
    INDEX BY BINARY_INTEGER;
    
    TYPE money IS TABLE OF test00.sal%TYPE
    INDEX BY BINARY_INTEGER;
    
    dno_name name;
    dno_job duty;
    dno_sal money;
    
    i BINARY_INTEGER := 0;
BEGIN
    DBMS_OUTPUT.ENABLE;
    
    FOR temp IN (
        SELECT
            ename, job, sal
        FROM
            test00
        WHERE
            deptno = dno
    ) LOOP
        i := i + 1;
        
        dno_name(i) := temp.ename;
        dno_job(i) := temp.job;
        dno_sal(i) := temp.sal;
    END LOOP;
    
    DBMS_OUTPUT.PUT_LINE(RPAD('-', 35, '-'));
    DBMS_OUTPUT.PUT_LINE('| 사원이름 | 사원 직급 | 사원급여 |');
    DBMS_OUTPUT.PUT_LINE(RPAD('=', 35, '='));
    FOR cnt IN 1 .. i LOOP
        DBMS_OUTPUT.PUT_LINE('| ' || RPAD(dno_name(cnt), 8, ' ') || ' | ' ||
                                RPAD(dno_job(cnt), 9, ' ') || ' | ' ||
                                LPAD(TO_CHAR(dno_sal(cnt)), 8, ' ') || ' |');
    END LOOP;
    DBMS_OUTPUT.PUT_LINE(RPAD('-', 35, '-'));
END;
/

exec dnoInfo(20);

---------------------------------------------------------------------------------
-- 이름을 알려주면 그 사원의 이름, 직책, 급여, 급여 등급을 
-- 출력하는 프로시저를 만들어보자.

CREATE OR REPLACE PROCEDURE nameInfo
    (name IN test00.ename%TYPE)
IS
    TYPE sawon IS RECORD
    (
        sname   test00.ename%TYPE,
        sjob    test00.job%TYPE,
        ssal    test00.sal%TYPE,
        sgrade  salgrade.grade%TYPE
    );
    
    temp sawon;
BEGIN
    DBMS_OUTPUT.ENABLE;
    
    SELECT
        ename, job, sal, grade
    INTO
        temp--.sname, temp.sjob, temp.ssal, temp.sgrade
    FROM
        test00, salgrade
    WHERE
        sal BETWEEN losal AND hisal
        AND ename = name
    ;
    
    DBMS_OUTPUT.PUT_LINE(temp.sname || ' | ' || temp.sjob || ' | ' || temp.ssal || ' | ' || temp.sgrade || ' |');
END;
/

execute nameInfo('KING');
------------------------------------------------------------------------------------
-- RECORD TYPE 배열

-- 직책을 입력하면
-- 그 직책을 가진 사원의 이름, 급여, 입사일을 출력하는 프로시저를 만드세요.

CREATE OR REPLACE PROCEDURE jobMember
    (tjob IN test00.job%TYPE)
IS
    TYPE member IS TABLE OF test00%ROWTYPE
    INDEX BY BINARY_INTEGER;
    
    temp member;
    
    i BINARY_INTEGER := 0;
BEGIN
    DBMS_OUTPUT.ENABLE;
    
    FOR m IN (
        SELECT
            ename, sal, hiredate
        FROM
            test00
        WHERE
            job = tjob
    ) LOOP
        i := i + 1;
        
        temp(i).ename := m.ename;
        temp(i).sal := m.sal;
        temp(i).hiredate := m.hiredate;
    END LOOP;
    
    -- print
    FOR idx IN 1 .. i LOOP
        DBMS_OUTPUT.PUT_LINE('| ' || temp(idx).ename || ' | ' || temp(idx).sal ||
                            ' | ' || TO_CHAR(temp(idx).hiredate, 'YYYY/MM/DD') || ' |');
    END LOOP;
END;
/

exec jobMember('CLERK');

-- 부서번호를 입력하면 해당부서 직원의 이름, 직책, 부서이름, 위치를 
-- 출력하는 프로시저를 만드세요.

CREATE OR REPLACE PROCEDURE dnoMember
    (dno    IN test00.deptno%TYPE)
IS
    -- RECORD TYPE (SINGLE ROW...)
    TYPE membInfo IS RECORD
    (
        name    test00.ename%TYPE,
        duty    test00.job%TYPE,
        dnoName dept.dname%TYPE,
        addr    dept.loc%TYPE
    );
    
    -- TABLE TYPE 
    TYPE dnoMemb IS TABLE OF membInfo
    INDEX BY BINARY_INTEGER;
    
    temp dnoMemb;
    
    i BINARY_INTEGER := 0;
BEGIN
    DBMS_OUTPUT.ENABLE;
    
    FOR m IN (
        SELECT
            ename, job, dname, loc
        FROM
            test00 e, dept d
        WHERE
            e.deptno = d.deptno
            AND e.deptno = dno
    ) LOOP
        i := i + 1;
        
        temp(i).name := m.ename;
        temp(i).duty := m.job;
        temp(i).dnoName := m.dname;
        temp(i).addr := m.loc;
    END LOOP;
    
    FOR j IN 1 .. i LOOP
        DBMS_OUTPUT.PUT_LINE('| ' || temp(j).name || ' | ' || temp(j).duty || 
                            ' | ' || temp(j).dnoName || ' | ' || temp(j).addr || ' |');
    END LOOP;
END;
/

exec dnoMember(20);
exec dnoMember(30);


CREATE OR REPLACE PROCEDURE dnoMember2
    (dno    IN test00.deptno%TYPE)
IS
BEGIN
    DBMS_OUTPUT.ENABLE;
    
    FOR m IN (
        SELECT
            ename, job, dname, loc
        FROM
            test00 e, dept d
        WHERE
            e.deptno = d.deptno
            AND e.deptno = dno
    ) LOOP
        DBMS_OUTPUT.PUT_LINE('| ' || m.ename || ' | ' || m.job || 
                            ' | ' || m.dname || ' | ' || m.loc || ' |');
        
    END LOOP;
    
END;
/

exec dnoMember2(30);

-------------------------------------------------------------------------------------------

-- 사원번호를 입력하면
-- 그 사원의 이름을 알려주는 프로시저를 만드세요
-- 단, 사원번호가 잘못 입력되면 사원이 없음을 알리는 메시지를 출력하라.

CREATE OR REPLACE PROCEDURE enoToName
    (eno IN OUT test00.empno%TYPE)
IS
    name test00.ename%TYPE;
BEGIN
    DBMS_OUTPUT.ENABLE;
    
    SELECT
        ename
    INTO
        name
    FROM
        test00
    WHERE
        empno = eno
    ;
    
    IF SQL%FOUND THEN
        DBMS_OUTPUT.PUT_LINE( '*** ' || eno || ' 번 사원이 존재 합니다. ***');
        DBMS_OUTPUT.PUT_LINE(  '          ' || name || ' 사원');
    END IF;
EXCEPTION WHEN NO_DATA_FOUND THEN
    DBMS_OUTPUT.PUT_LINE('##### ' || eno || ' 번 사원은 존재하지 않습니다. #####');
END;
/



exec enoToName(7369);
exec enoToName(8000);

---------------------------------------------------------------------------------------


-- 부서중 급여 합계가 제일 높은 부서 사원들 중
-- 부서평균 급여보다 낮은 사원들의
-- 사원이름, 직급, 급여, 부서평균급여, 부서급여합계 를 조회하세요.
SELECT
    deptno dno, AVG(sal) avg, SUM(sal) sum
FROM
    emp
GROUP BY
    deptno
HAVING
    SUM(sal) = (
                    SELECT
                        MAX(SUM(sal))
                    FROM
                        emp
                    GROUP BY
                        deptno
                )
;


SELECT
    MAX(SUM(sal))
FROM
    emp
GROUP BY
    deptno
;

SELECT
    deptno, AVG(sal)
FROM
    emp
GROUP BY
    deptno
HAVING
    SUM(sal) = 10875
;

SELECT
    ename 사원이름, job 직급, sal 급여, 2175 부서평균급여, 10875 부서급여합계
FROM
    emp
WHERE
    deptno = 20
    AND sal < 2175
;

SELECT
    ename 사원이름, job 직급, sal 급여, avg 부서평균급여, sum 부서급여합계
FROM
    emp, (
            SELECT
                deptno dno, AVG(sal) avg, SUM(sal) sum
            FROM
                emp
            GROUP BY
                deptno
            HAVING
                SUM(sal) = (
                                SELECT
                                    MAX(SUM(sal))
                                FROM
                                    emp
                                GROUP BY
                                    deptno
                            )
            )
WHERE
    deptno = dno
    AND sal < avg
;