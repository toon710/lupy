-- ex04

/*
    문제 1 ]
        커미션을 27% 인상해서 사원이름, 현커미션, 인상커미션을 조회하세요.
        단, 커미션이 없는 사원은 100 을 지급하는 것으로 하고
            여기서 27%를 인상하는 것으로 한다.
        소수이상 2째 자리에서 반올림해서 조회한다.
*/
SELECT
    ename 사원이름, comm 현커미션, ROUND(NVL(comm * 1.27, 100 * 1.27), 2) 인상커미션
FROM
    emp
;
/*
    문제 2 ]
        사원들의 급여를 15% 인상한 금액과 커미션을 합쳐서
            사원이름, 급여, 커미션, 지급액
        을 조회하세요.
        단, 소수이상 첫째자리에서 버림해서 조회하세요.
        커미션이 없는 사원은 0으로 대체해서 계산하도록 한다.
*/
SELECT
    ename, sal, comm, ROUND(NVL(sal * 1.15 + comm, sal * 1.15), -1) 지급액
FROM
    emp
;
/*
    문제 3 ]
        사원들의 급여가 100으로 나누어 떨어지는 사원들만
            사원이름, 직급, 급여
        를 조회하세요.
*/
SELECT
    ename, job, sal
FROM
    emp
WHERE
    MOD(sal, 100) = 0
;

--------------------------------------------------------------------------------

/*
    문제 1 ]
        사원들중 이름이 4글자 이하인 사원들만
            사원이름, 직급, 입사일
        을 조회하세요.
*/
SELECT
    ename 사원이름, job 직급, hiredate 입사일
FROM
    emp
WHERE
    LENGTH(ename) <= 4
;
/*
    문제 2 ]
        사원들의 
            사원이름, 상사번호, 부서번호
        를 조회하세요.
        사원이름은 
            SMITH 사원
        의 형식으로 뒤에 ' 사원' 이 붙도록 조회하세요.
*/
SELECT
    CONCAT(ename, ' 사원') 사원이름, mgr 상사번호,  deptno 부서번호
FROM
    emp
;
/*
    문제 3 ]
        이름의 마지막 문자가 'N'인 사원의
            사원이름, 직급, 부서번호
        를 조회하세요.
*/
SELECT
    ename 사원이름, job 직급, deptno 부서번호
FROM
    emp
WHERE
    SUBSTR(ename, -1) = 'N'
;
/*
    문제 4 ]
        이름에 'A'가 포함되지 않은 사원들의
            사원이름, 직급, 입사일
        을 조회하세요.
*/
SELECT
    ename 사원이름, job 직급, hiredate 입사일
FROM
    emp
WHERE
    INSTR(ename, 'A') = 0
;
/*
    BONUS ]
        사원이름에 '@githrd.com'을 붙여서 메일주소를 조회하는데
        메일 주소는 아이디는 세번째 문자만 보여주고 나머지는 '*' 로 표현하고
            0) @ 보여주고
            1) 도메인의 경우 첫문자는 보여주고
            2) 도메인의 경우 두번째 세번째 문자는 보여주고
        '.com'도 보여주고 나머지는 '*' 로 출력하세요.
*/

SELECT
    INSTR('@githrd.com', '.', -1) ".위치",
    SUBSTR('@githrd.com', INSTR('@githrd.com', '.', -1)) ".com",
    SUBSTR('@githrd.com', 3, 2) 두글자,
    LPAD(
        RPAD(
            RPAD(
                LPAD(
                    SUBSTR('@githrd.com', 3, 2), 3, '*'
                ),
                INSTR('@githrd.com', '.', -1) - 2,
                '*'
            ),
            LENGTH('@githrd.com') - 1,
            SUBSTR('@githrd.com', INSTR('@githrd.com', '.', -1))
        ),
        LENGTH('@githrd.com'),
        '@'
    ) 도메인,
    RPAD(
        RPAD(
            LPAD(
                SUBSTR(ename, 3, 1),
                3,
                '*'
            ),
            LENGTH(ename),
            '*'
        ),
        LENGTH(CONCAT(ename, '@githrd.com')),
        LPAD(
            RPAD(
                RPAD(
                    LPAD(
                        SUBSTR('@githrd.com', 3, 2), 3, '*'
                    ),
                    INSTR('@githrd.com', '.', -1) - 2,
                    '*'
                ),
                LENGTH('@githrd.com') - 1,
                SUBSTR('@githrd.com', INSTR('@githrd.com', '.', -1))
            ),
            LENGTH('@githrd.com'),
            '@'
        )
    ) email
FROM
    emp
;

------------------------------------------------------------------------------------------

-- 날짜함수
/*
    문제 1 ]
        1년은 365이라고 하고
        사원들의 근무일수를 년으로만 표시하고
        대신 소수이하는 버리세요.
*/
SELECT
    FLOOR((sysdate - hiredate) / 365) 근무년수
FROM
    emp
;
/*
    문제 2 ]
        사원들의 근무년수를 년, 월로 표시하세요.
        
        단, 개월수로 처리하세요.
*/
SELECT
    FLOOR(MONTHS_BETWEEN(sysdate, hiredate) / 12) 근무년수,
    FLOOR(MOD(MONTHS_BETWEEN(sysdate, hiredate), 12)) 나머지개월수
FROM
    emp
;
/*
    문제 3 ]
        사원들이 첫급여를 받을 때까지 근무한 일수를 
            사원이름, 입사일, 근무일수 로
        조회하세요.
*/
SELECT
    ename 사원이름, hiredate 입사일,
    (LAST_DAY(hiredate) + 1) - hiredate 근무일수
FROM
    emp
;
/*
    문제 4 ]
        사원들이 입사한 후 첫번째 토요일의 날짜를 조회하세요.
*/
SELECT
    ename 사원이름, hiredate 입사일, TO_CHAR(hiredate, 'DAY') 입사요일, NEXT_DAY(hiredate, '토요일') "첫번째 토요일"
FROM
    emp
;
/*
    문제 5 ]
        사원들의 근무년수 기준일을 조회하세요.
        단, 기준일은 입사한달 1일을 기준으로 하는데
        15일 이전 입사자는 그달을 기준으로 하고
        15일 이후 입사자는 다음달 1일을 기준으로 한다.
*/
SELECT
    ename 사원이름, hiredate 입사일, ROUND(hiredate, 'MONTH') 입사기준일
FROM
    emp
;
/*
    문제 6 ]
        사원들의 급여를 조회하는데
        모두 10자리로 표현하고
        급여이외에 남는 자리에는 * 로 표현하세요.
*/
SELECT
    ename 사원이름, sal 급여, LPAD(TO_CHAR(sal), 10, '*') 표시급여
FROM
    emp
;
/*
    문제 7 ]
        사원중 월요일에 입사한 사원의 
            사원번호, 사원이름, 직급, 입사일, 입사요일
        을 조회하세요.
*/
SELECT
    empno 사원번호, ename 사원이름, job 직급, hiredate 입사일, TO_CHAR(hiredate, 'DAY') 입사요일
FROM
    emp
WHERE
    TO_CHAR(hiredate, 'DAY') = '월요일'
;
/*
    문제 8 ]
        사원 급여 중에서 백단위가 0인 사원의
            사원이름, 직급, 급여를 조회하세요.
*/
SELECT
    ename 사원이름, job 직급, sal 급여
FROM
    emp
WHERE
    SUBSTR(TO_CHAR(sal), -3, 1) = '0'
;
/*
    문제 9 ]
        당신의 생년월일을 이용해서
        지금까지 몇년 몇개월 살고 있는지를 조회하세요.
*/
SELECT
    CONCAT(
        CONCAT(
            CONCAT(FLOOR(MONTHS_BETWEEN(sysdate, TO_DATE('1994/12/26', 'YYYY/MM/DD')) / 12), '년 '),
            FLOOR(MOD(MONTHS_BETWEEN(sysdate, TO_DATE('1994/12/26', 'YYYY/MM/DD')), 12)) 
        ), ' 개월째 밥먹고 있음!'
    ) "밥 먹 고 있 는 날 수"
FROM
    DUAL
;
/*
    문제 10 ]
        사원들의
            사원이름, 직급, 급여, 커미션
        을 조회하는데
        커미션이 없는 사원은 'NONE' 으로 출력되게 하세요.
*/
SELECT
    ename 사원이름, job 직급, sal 급여, NVL(TO_CHAR(comm), 'NONE') 커미션
FROM
    emp
;