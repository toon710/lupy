/*
    NULL 데이터 처리함수
    
    1. NVL()
        
        형식 ]
            NVL(컬럼이름, NULL일때 대체값)
        의미 ]
            입력한 컬럼이름의 내용이 NULL 인경우 데체값으로 대신하세요.
            NULL 이 아닌 경우는 컬럼의 내용 그대로 사용하세요.
            
    2. NVL2()
        형식 ]
            NVL2(컬럼이름, 연산식, NULL일때 대체값)
        의미 ]
            컬럼이름이 NULL이면 대체값으로 표현하고
            NULL 이 아니면 연산식으로 표현하세요.
            
    3. NULLIF()
        형식 ]
            NULLIF(데이터1, 데이터2)
            
        의미 ]
            데이터1과 데이터2가 같으면 "NULL"로 처리하고
            다르면 "데이터1"로 처리하세요.
    
    4. COALESCE()
        형식 ]
            COALESCE(데이타1, 데이터2, 데이터3, .....)
        의미 ]
            여러개의 데이터중 가장 첫번째 NULL 이 아닌 데이터를 반환해준다.
*/

-- 문제 3 ] 
SELECT
    NULLIF('A', 'A') 결과1,   -- 두 데이터가 같으면 NULL 반환
    NULLIF('A', 'B') 결과2    -- 두 데이터가 다르면 첫번째 데이터를 반환
FROM 
    dual
;

-- 커미션을 조회하는데 커미션이 null 이면 상사번호를 대신 조회하세요.
-- 상사번호도 null 이면 부서번호를 조회하세요.

SELECT
    ename 사원이름, COALESCE(comm, mgr, deptno) 계산값
FROM
    emp
;

/*
    
조건 처리 함수
==> 조건을 주고 데이터를 선택해서 반환해주는 함수

1. DECODE()
    형식 ]
        DECODE(컬럼이름, '값1', '처리내용1',
                         '값2', '처리내용2',
                         ...
                         '처리내용n')
    의미 ]
        컬럼의 데이터가 '값1' 이면 '처리내용1'로 처리하고
                        '값2' 이면 '처리내용2'로 처리하고
                        ...
                        그 이외의 데이터면 '처리내용n'으로 처리하세요.
        

2. CASE : if 명령에 해당하는 명령

    형식 1 ]
        CASE    WHEN    조건식1    THEN    처리내용1
                WHEN    조건식2    THEN    처리내용2
                ...
                ELSE    처리내용n
        END
        
    의미 ]
        조건식1 이 참이면 처리내용1
        조건식2가 참이면 처리내용2
        ....
        그 이외의 경우는 처리내용n 으로 처리하세요.
        
        
    형식 2 ]
        CASE    컬럼이름    WHEN    데이터1     THEN   처리내용1
                            WHEN    데이터2     THEN   처리내용2
                            ...
                            ELSE 처리내용n
        END
        
    의미 ]
        DECODE 함수와 동일한 의미
        묵시적으로 '=' 라는 조건만 사용하는 명령
    
*/

/*
    부서번호가 10번이면 '회계부'
                20번이면 '개발부'
                30번이면 '영업부'
                40번이면 '총무부'
                그 이외의 부서번호는 '부서없음' 으로 조회하세요.
*/
SELECT
    empno 사원번호, ename 사원이름, deptno 부서번호, 
    DECODE(deptno,  10, '회계부',
                    20, '개발부',
                    30, '영업부',
                    40, '총무부',
                    '부서업음'
    ) 부서이름
FROM
    emp
;

/*
    각 부서별로 이번달 커미션 지급액이 다르게 지급된다.
    10번 부서는 급여의 10%
    20번 부서는 급여의 15%
    30번 부서는 급여의 20%
    그이외의 부서는 0
    을 지급할 예정이다.
    
    사원들의 
        사원이름, 직급, 급여, 커미션, 지급커미션을 조회하세요.
*/

-- DECODE()
SELECT
    ename 사원이름, job 직급, sal 급여, comm 커미션, 
    DECODE(
        deptno, 10, sal * 0.1,
                20, sal * 0.15,
                30, sal * 0.2,
                0
    ) 지급커미션
FROM
    emp
;

-- CASE 명령
SELECT
    ename 사원이름, job 직급, sal 급여, comm 커미션, 
    CASE deptno WHEN    10  THEN sal * 0.1
                WHEN    20  THEN sal * 0.15
                WHEN    30  THEN sal * 0.2
                ELSE 0
    END 지급커미션
FROM
    emp
;

/*
    급여가 1000 이하면 급여를 20% 인상하고
            1001 ~ 3000 이면 급여를 15% 인상하고
            3001 이상이면 10% 인상해서 
    사원들의
        사원이름, 직급, 급여, 인상급여
    를 조회하세요.
*/

-- 범위 비교이기때문에 CASE 명령으로 처리
SELECT
    ename 사원이름, job 직급, sal 급여,
    CASE WHEN sal <= 1000 THEN sal * 1.2
         WHEN sal BETWEEN 1001 AND 3000 THEN sal * 1.15
         WHEN sal >= 3001   THEN sal * 1.1
    END 인상급여
FROM
    emp
;


--------------------------------------------------------------------------------
/*
    그룹함수
    ==> 여러행의 데이터를 하나로 만들어서 연산해주는 함수
    
    ***
    참고 ]
        그룹 함수는 결과가 오직 한개만 나오게 된다.
        따라서 그룹함수는 결과가 여러개 나오는 경우와 같이 사용할 수 없다.(SELECT 절에서...)
        오직 결과가 한행으로만 나오는 것과만 같이 꺼내올 수 있다.
        
        예 ]
            SELECT
                ename
            FROM
                emp
            ;
            
            SELECT
                COUNT(*) 사원수
            FROM
                emp
            ;
            
            둘의 결과를 같이 조회하는 것은 안된다.
            SELECT
                ename, COUNT(*)
            FROM
                emp
            ;
            
            SELECT
                ename, COUNT(*)
            FROM
                emp
            WHERE
                ename = 'KING'
            ; <== 사원이름이 중복되서 추가될 수 있으므로 안된다.
            
            SELECT
                ename, COUNT(*)
            FROM
                emp
            GROUP BY
                ename
            ;
            
    ----------------------------------------------------------------------------
    
    1. SUM
    ==> 그룹의 합계를 구해주는 함수
        형식 ]
            SUM(컬럼이름)
            
        예 ]
            사원들의 급여의 합계를 조회하세요.
            SELECT
                SUM(sal) 급여합계
            FROM
                emp
            ;
            
    2. AVG
    ==> 그룹의 평균을 구해주는 함수
        
        형식 ]
            AVG(컬럼이름)
            
        예 ]
            회사 평균급여를 조회하세요.
            
            SELECT
                TRUNC(AVG(sal), 2) 회사평균급여
            FROM
                emp
            ;
        
    3 MIN / MAX
    ==> 그룹에서의 최대/ 최소 값을 구해주는 함수
        형식 ]
            MAX(컬럼이름) / MIN(컬럼이름)
            
        예 ] 회사 최고급여와 최소급여를 조회하세요.
            SELECT
                MAX(sal) 최대급여, MIN(sal) 최소급여, SUM(sal) 총급여합계
            FROM
                emp
            ;
        
    4. COUNT
    ==> 데이터가 존재하는 카운트를 알려주는 함수
        형식 ]
            COUNT(컬럼이름)
            ;;
        예 ]
            10번 부서 사원들의 수를 조회하세요.
            SELECT
                COUNT(*) "10번부서원수"
            FROM
                emp
            WHERE
                deptno = 10
            ;
            
            상사가 있는 사원들의 수를 조회하세요.
            SELECT
                COUNT(mgr) 부하직원수
            FROM
                emp
            ;
            
            SELECT SUM(comm) FROM emp;
--------------------------------------------------------------------------------
    5. STDDEV
    ==> 표준편차를 알려주는 함수
    6. VARIANCE
    ==> 분산을 알려주는 함수
    
================================================================================

GROUP BY
==> 그룹 함수에 적용되는 그룹을 지정하는 절
    
    예 ]
        부서별로 급여의 합계를 구하고 싶은 경우...
        직급별로 급여 평균을 구하고 싶은 경우...

    형식 ]
        SELECT
            컬럼이름1, 컬럼이름2, ....
        FROM
            테이블이름
        [WHERE
            조건식    ]
        GROUP BY
            컬럼이름1, 컬럼이름2, ...
        [HAVING
            조건절..]
        ORDER BY
            컬럼이름, ...
            
        ==> 직급별로 처리하고 싶다.
        SELECT
        ....
        GROUP BY
            job;
            
        ==> 부서별로 처리하고 싶다.
        SELECTY
        ...
        GROUP BY
            deptno;
            
    참고 ]
        그룹 함수와 일반 컬럼은 동시에 조회할 수 없지만
        GROUP BY 절에 기술된 그룹화 조건이 되는 컬럼은 
        동시에 조회 할 수 있다.
        
    참고 ]
        GROUP BY절은 필드 전체가 하나로 묶일 필요는 없다.
        ==> 필드의 일부분을 이용해서도 그룹화 할 수 있다.
        
        예 ]
            사원이름의 앞글자를 이용해서
            'A' 사람들의 총급여, 
            'B' 인 사람들의 총급여,.....
            
            SELECT
                SUBSTR(ename, 1, 1) 이름첫문자, SUM(sal) 급여합계
            FROM
                emp
            GROUP BY
                SUBSTR(ename, 1, 1)
            ORDER BY
                SUBSTR(ename, 1, 1)
            ;
            
    참고 ]
        조건절을 이용해서 계산에 적용시킬 데이터를 고를 수 있다.
        
        예 ]
            급여가 1000 이상인 사원들의 총급여액을 조회하세요.
            
            SELECT
                SUM(sal) 총급여액
            FROM
                emp
            WHERE
                sal >= 1000
            ;
            
            이름이 4글자 5글자인 사원들의 급여평균을 조회하세요.
            
            SELECT
                TRUNC(AVG(sal), 2) 평균급여
            FROM
                emp
            WHERE
                LENGTH(ename) IN (4, 5)
            ;
            
            81년 입사한 사원들의 부서별 평균급여를 조회하세요.
            
            SELECT
                deptno 부서번호, TRUNC(AVG(sal), 2) 평균급여
            FROM
                emp
            WHERE
                TO_CHAR(hiredate, 'yy') = '81'
            GROUP BY
                deptno
            ;
            
    ----------------------------------------------------------------------------
    HAVING
    ==> 그룹화한 결과를 조건을 주고 걸러서 조회하는 방법
    
        ***
        참고 ]
            WHERE 조건은 계산에 포함될 데이터를 선택하는 조건
            HAVING 조건은 계산이 종료된 후 조회 결과에 포함시킬지 여부를 결정하는 조건
            
            예 ]
                부서별 평균급여를 조회하는데 부서원수가 4명 이상인 부서만 조회하세요.
                
                SELECT
                    deptno, TRUNC(AVG(sal), 2) 부서평균급여
                FROM
                    emp
                GROUP BY
                    deptno
                HAVING
                    COUNT(*) >= 4
                ;
                
                직급별 사원수를 조회하세요.
                단, 사원수가 1명인 직급은 제외하세요.
                
                SELECT
                    job 직급, COUNT(*) 사원수
                FROM
                    emp
                GROUP BY
                    job
                HAVING
--                    TO_CHAR(hiredate, 'yy') = '81'
--                    job = 'MANAGER'
                    COUNT(*) <> 1
                ;
                
                SELECT job FROM emp WHERE job= 'MANAGER';
                
    ----------------------------------------------------------------------------
    참고 ]
        DECODE() 함수와 그룹함수의 조합
        
        예 ]
            부서별로 급여를 조회하는데
            10번 부서는 급여평균을
            20번 부서는 최대급여를
            30번 부서는 급여합계를 조회하세요.
            
            SELECT
                deptno 부서번호, 
                DECODE(deptno, 10, TRUNC(AVG(sal), 2),
                                20, MAX(sal),
                                30, SUM(sal)
                ) 부서급여
            FROM
                emp
            GROUP BY
                deptno
            ;
            
            예 ]
                각 부서별로 급여의 합계를 를 조회하세요.
                단, 모든 부서의 합계가 같이 조회되게 하세요.
                    계산 안된 데이터는 0으로 표현하세요.
                    
                SELECT
                    deptno, 
                    NVL(SUM(DECODE(deptno, 10, sal)), 0) AS D10,
                    NVL(SUM(DECODE(deptno, 20, sal)), 0) AS D20,
                    NVL(SUM(DECODE(deptno, 30, sal)), 0) AS D30
                FROM
                    emp
                GROUP BY
                    deptno
                ;
    
*/

-- 부서별 부서 평균 급여를 조회하세요.
SELECT
    deptno 부서번호, TRUNC(AVG(sal), 2) 부서평균급여
FROM   
    emp
GROUP BY
    deptno
;

-- 각 직급별 사원수를 조회하세요.
SELECT
    job 직급, COUNT(job) 사원수
FROM
    emp
GROUP BY
    job
;

-- 사원들의 직급의 수를 조회하세요.
SELECT
    COUNT(DISTINCT job) 사원직급수
FROM
    emp
;


CREATE TABLE test01(
    no number,
    name varchar2(10 char)
);
INSERT INTO 
    test01
VALUES(
    NULL, NULL
);

commit;

TRUNCATE TABLE test01;

select count(*) from test01;

--------------------------------------------------------------------------------
/*
    서브질의(부질의, SUB QUERY)
    ==> 질의명령안에 다시 질의 명령이 포함될 수 있는데
        이 때 포함된 이 질의 명령을 서브질의라 한다.
        
        예 ]
            'SMITH' 사원과 같은 부서 소속의 사원들의
            사원이름, 직급, 부서번호를 조회하세요.
            
            처리순서 ]
                1. 'SMITH' 사원의 부서번호를 조회한다.
                ==> 조회질의 명령이 하나 필요하다.
                2. 조회한 부서번호를 이용해서 조회한다.
                ==> 1번의 결과를 이용해서 질의명령을 작성해야 한다.
            
            1. 
            SELECT
                deptno
            FROM
                EMP
            WHERE
                ename = 'SMITH'
            ;
            
            2.
            SELECT
                ename, job, deptno
            FROM
                emp
            WHERE
                deptno = (
                                SELECT
                                    deptno
                                FROM
                                    emp
                                WHERE
                                    ename = 'SMITH'
                            )
            ;
            
1. CREATE TABLE 질의명령에서 사용하는 서브질의
==> 기존 테이블의 내용을 복사해서 새로운 테이블을 생성할 때 사용
    
    형식 ]
        CREATE TABLE 테이블이름
        AS
            서브질의;
    의미 ]
        서브질의의 결과를 이용해서(만들어진 결과집합 데이터를 이용해서)
        복사해서 새로운 테이블을 만드세요.
        
    예 ]
        테이블 백업시 많이 사용하는 형식
            -- 테이블 전체 복사
            CREATE TABLE temp1
            AS
                SELECT * FROM emp;
            
            -- 컬럼 일부만 복사
            CREATE TABLE TEMP2
            AS
                SELECT 
                    empno eno, ename name, deptno dno 
                FROM 
                    emp 
                WHERE 
                    deptno = 10; 
                    
            -- 테이블 구조만 복사        
            CREATE TABLE temp3
            AS
                SELECT
                    *
                FROM
                    emp
                WHERE
                    1 = 2
                ;
--------------------------------------------------------------------------------
SELECT 질의 명령에서 사용하는 서브질의
    
    *****
    1. 결과가 오직 한개의 데이터인 경우
    ==> 서브질의의 결과를 하나의 데이터로 보고 
        이 데이터를 사용할 수 있는 곳에는 모두 사용할 수 있다.
        
        1) SELECT 절에서 사용
        
            예 ]
                사원들의 이름, 급여, 회사평균급여 를 조회하세요.
                
                SELECT
                    ename, sal,
                    (
                        SELECT
                            TRUNC(AVG(sal), 2)
                        FROM
                            emp
                    ) 회사평균급여
                FROM
                    emp
                ;
        
        2) 조건절에서 사용
            
            예 ]
                사원들의 사원이름, 직급, 급여 를 조회하세요.
                단, 회사평균급여보다 적게 받는 사원들만 조회하세요.
                
                 SELECT
                    ename 사원이름, job 직급, sal 급여
                 FROM
                    emp
                 WHERE
                    sal < (
                                SELECT
                                    AVG(sal)
                                FROM
                                    emp
                            )   
                 ;



*/














