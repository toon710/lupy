DECLARE
    x NUMBER;
BEGIN
    x := 1000;
    DBMS_OUTPUT.PUT_LINE('��� = ');
    DBMS_OUTPUT.PUT_LINE(x);
END;
/