/*
    트랜젝션 처리
    
    트랜젝션
    ==> DBMS가 처리하는 명령 단위
    
        예를 들어서 CREATE TABLE XXXX(...) 라는 명령을 실행하면
        앤터키를 누르면 질의명령이 실행되는데(테이블이 생성이 되는데..)
        이것을 '트랜젝션이 실행되었다.' 라고 표현한다.
        
        위와 같이 대부분의 명령은 앤터키를 누르는 순간 명령이 실행되고
        이때 트랜젝션이 실행된 것이므로
        결국 DBMS는 명령 한줄이 곧 하나의 트랜젝션이 된다.
        
        그런데 DML 명령 만큼은 트랜젝션 단위가 달라진다.
        
        예 ]
            -- SMITH 사원의 급여를 10000으로 수정하세요.
                
                UPDATE
                    temp1
                SET
                    sal = 10000
                WHERE
                    ename = 'SMITH'
                ;
            참고 ]   DML 명령 - INSERT, UPDATE, DELETE
            ==> DML 명령은 명령을 실행하면 바로 데이터베이스에 적용시키는 것이 아니고
                버퍼장소(임시 메모리) 에 그 명령을 모아만 놓는다.
                ==> 결국 트랜젝션이 발생하지 않게 된다.
                
                따라서 DML 명령은 강제로 트랜젝션 실행 명령을 실행해야 한다.
                이때 트랜젝션은 한번만 발생하게 된다.
                
                왜?
                    DML 명령은 데이터를 변경하는 명령이다.
                    데이터베이스의 가장 중요한 개념은 무결성 데이터이다.
                    이런곳에 DML 명령이 한순간에 트랜젝션 처리되면
                    (DML 명령을 하나하나 실행시킬때마다 데이터베이스에 적용이 되면)
                    데이터의 무결성이 깨질 수 있다.
                    이런 문제점을 해결하기 위한 목적으로
                    트랜젝션 방식을 변경해 놓았다.
            
            ***
            버퍼메모리에 모아놓은 명령을 트랜젝션 처리하는 방법
                자동 트랜젝션 처리(자동 COMMIT 되는 경우)
                    1. SQLPLUS를 정상적으로 종료하는 순간 트랜젝션 처리가 일어난다.
                        
                        SQL> exit ===> 명령을 실행시키는 순간
                        
                    2. DDL 명령이나 DCL 명령이 실행되는 순간
                
                수동 트랜젝션 처리
                    3. commit; 이라고 강제로 명령을 실행하는 순간
                    
            
            버퍼에 모아놓은 명령이 실행되지 않는 경우
            ==> 트랜젝션 처리가 되지 않고 버려지는 경우
                
                자동
                    1. 정전 등에 의해서 시스템이 셧다운 되는 경우
                    2. sqlplus 를 비정상 종료하는 경우
                    
                수동
                    3. ROLLBACK; 이라고 명령을 실행하는 순간
                    
            즉, DML 명령들을 실행한 후 다시 검토해서 완벽한 명령이라고 판단도면
            COMMIT; 이라고 명령해서 트랜젝션을 발생시키고
            만약 검토 후 완벽한 명령이 아니면..
            ROLLBACK; 이라고 명령해서 잘못됨 명령을 취소하도록 해야 한다.
            
    참고 ]
        ROLLBACK 시점 만들기
        ==> DML 명령을 실행할 때 특정 위치에서 책갈피를 만들어 놓을 수 있다.
            나중에 이 책갈피를 이용해서 ROLLBACK 할 부분을 지정할 수 있다.
            
            책갈피 만드는 방법
                
                SAVEPOINT 책갈피이름;
                
            지정한 위치까지 ROLLBACK 시키기
                
                ROLLBACK TO 책갈피이름;
                
            예 ]
                
                SAVEPOINT A;
                
                DML - INSERT    - 1
                DML - INSERT    - 2
                DML - UPDATE    - 3
                
                SAVEPOINT B;
                
                DML - DELETE    - 4
                DML - INSERT    - 5
                DML - UPDATE    - 6
                
                SAVEPOIN C;
                
                DML - UPDATE    - 7
                DML - UPDATE    - 8
                DML - DELETE    - 9
                
                ROLLBACK TO C; ==> 7, 8, 9 작업이 취소된다.
                ROLLBACK TO C; ==> x
                
                ROLLBACK TO B; ==> 4, 5, 6, 7, 8, 9 작업이 취소된다.
                
                ROLLBACK TO A; ==> 1 ~ 9 작업이 취소된다.
                ROLLBACK TO B; ==> X
                    
*/

-- SMITH 사원의 급여를 10000으로 수정하세요.
UPDATE
    temp1
SET
    sal = 10000
WHERE
    ename = 'SMITH'
;

rollback;

SAVEPOINT A;

UPDATE
    temp1
SET
    sal = 10000
WHERE
    ename = 'SMITH'
;

INSERT INTO 
    temp1(empno, ename, job, hiredate, sal, comm, deptno)
VALUES(
    8000, 'CHOPA', 'DOCTOR', TO_DATE(TO_CHAR(sysdate, 'YYYY/MM/DD')),
    15000, 1500, 40
);

UPDATE
    temp1
SET
    mgr =   (
                SELECT
                    empno
                FROM
                    temp1
                WHERE
                    ename = 'KING'
                    AND mgr IS NULL
            )
WHERE
    empno = (
                SELECT
                    empno
                FROM
                    temp1
                WHERE
                    ename = 'CHOPA'
                    AND deptno = 40
            )
;

INSERT INTO
    temp1
VALUES(
    (
        SELECT NVL(MAX(empno) + 1, 1001) FROM temp1
    ),
    'LUFFY', 'PIRATE', 
    (
        SELECT
            empno
        FROM
            temp1
        WHERE
            ename = 'CHOPA'
            AND job = 'DOCTOR'
    ),
    TO_DATE('1995/12/22', 'YYYY/MM/DD'),
    (
        SELECT
            sal * 0.1
        FROM
            temp1
        WHERE
            ename = 'CHOPA'
            AND job = 'DOCTOR'
    ),
    null,
    (
        SELECT
            deptno
        FROM
            temp1
        WHERE
            ename = 'CHOPA'
            AND job = 'DOCTOR'
    )
);

SAVEPOINT B;

UPDATE
    temp1
SET
    sal = sal - 250
WHERE
    ename = 'LUFFY'
    AND job = 'PIRATE'
;


UPDATE
    temp1
SET
    comm = -250
WHERE
    ename = 'LUFFY'
    AND job = 'PIRATE'
;

SAVEPOINT C;

INSERT INTO 
    temp1
VALUES(
    (
        SELECT NVL(MAX(empno) + 1, 1001) FROM temp1
    ),
    'ZORO', UPPER('lumberjak'), 8000, TO_DATE('1995/12/22', 'YYYY/MM/DD'),
    800, NULL, 40
);

INSERT INTO 
    temp1
VALUES(
    (
        SELECT NVL(MAX(empno) + 1, 1001) FROM temp1
    ),
    'SANJI', 'COOKER', 8000, TO_DATE('1995/12/22', 'YYYY/MM/DD'),
    1200, 50, 40
);



ROLLBACK TO B;

ROLLBACK TO C;

ROLLBACK TO A;

ROLLBACK TO B;

-- COMMIT; SAVEPOINT B 까지의 모든 작업이 트랜젝션 처리가되고 SAVEPOINT 는 모두 삭제된다.

ROLLBACK;

---------------------------------------------------------------------------------------------
/*
    무결성 제약 조건
    ==> 데이터베이스는 프로그램등 전산에서 작업할 때 필요한 데이터를
        제공해주는 보조 프로그램이다.
        따라서 데이터베이스가 가진 데이터는 완벽한 데이터여야 한다.
        하지만 데이터를 입력하는 주체는 사람이고
        그러다보니 완벽한 데이터를 보장할 수 없게 된다.
        
        각가의 테이블에 들어가서는 안될 데이터나 누락되면 안되는 데이터등을
        미리 결정해 놓음 으로써
        데이터를 입력하는 사람이 잘못입력하면
        그 데이터는 아예 데이터베이스에 기록되지 않도록 방지하는 역할을 하는 것.
        
        따라서 이 기능은 반드시 필요한 기능은 아니다.
        ( 입력하는 사람이 정신차리고 똑바로 입력하면 된다. )
        실수를 미연에 방지할 수 있도록 하는 기능이다.
        
    종류 ]
        
        NOT NULL : NOT NULL 제약조건
        ==> 이 제약조건이 부여된 컬럼은 데이터가 필수적으로 존재해야 하는
            (NULL 로 채워지면 안된다.) 
            컬럼임을 밝히는 제약조건.
            즉, 이 무결성 제약조건이 있는 컬럼에 데이터가 입력되지 않으면 
            아예 그 한행을 입력하지 못하도록하는 제약조건이다.
            
        UNIQUE : 유일키 제약조건
        ==> 해당 필드의 데이터는 다른 데이터와 반드시 구분되어야 하는 제약조건
            ( 속성값이 다른 행의 속성값들 중에 유일해야 한다.)
            즉, 같은 데이터가 다른행에서 다시 입력되는 것을 방지하는 제약조건
            대신 NULL 허용한다.
            
        PRIMARY KEY : 기본키 제약조건
        ==> 테이블에서 데이터 한행을 구분해주는 것으로 기본키라고 부른다.
            NOT NULL + UNIQUE
        
        FOREIGN KEY : FOREIGN KEY 제약조건, 참조키 제약조건, 외래키 제약조건
        ==> 데이터를 다른테이블의 기본키나 유일키(UNIQUE)를 참조하게 되는경우
            참조하는 테이블에 없는 데이터가 입력되는 것을 방지하는 제약조건
            
        CHECK   : CHECK 제약조건
        ==> 속성의 속성값의 갯수가 정해져있는 도메인의 경우
            도메인 이외의 데이터가 입력되는 것을 방지하는 제약조건
            
    참고 ]
        DEFAULT :   데이터를 입력하는 INSERT 명령의 경우
                    테이블의 입력될 데이터의 컬럼을 지정해서 입력을 하게되는 방법이 있다.
                    이때 컬럼을 지정하지 않으면 별도의 처리가 없는 경우
                    NULL 로 채워지게 된다.
                    이런 경우 기본값을 설정해두고 컬럼이름을 지정하지 않고 입력하는 경우
                    설정해 놓은 기본값으로 채워주도록 하는 속성
        
---------------------------------------------------------------------------------------------
무결성 제약조건 부여 방법
    1. 테이블 생성시 부여하는 방법
        1) 무명 무결성 제약조건으로 등록하는 방법
            형식 ]
                CREATE TABLE 테이블이름(
                    컬럼이름    데이터타입(길이)   [ DEFAULT 데이터 ] NOT NULL,
                    컬럼이름    데이터타입(길이)   [ DEFAULT 데이터 ] PRIMARY KEY,
                    컬럼이름    데이터타입(길이)   [ DEFAULT 데이터 ] REFERENCES 참조받아올테이블이름(참조컬럼이름),
                    컬럼이름    데이터타입(길이)   [ DEFAULT 데이터 ] UNIQUE,
                    컬럼이름    데이터타입(길이)   [ DEFAULT 데이터 ] CHECK(컬럼이름  IN(데이터1, 데이터2,...))
                )
        2) 명시적 무결성 제약조건으로 등록하는 방법
        
*/

DROP TABLE test01;

CREATE TABLE test01(
    no NUMBER(4) PRIMARY KEY,
    id VARCHAR2(10 CHAR) UNIQUE,
    name VARCHAR2(15 CHAR) NOT NULL,
    pw  VARCHAR2(8 CHAR) NOT NULL,
    gen CHAR(1) CHECK(gen IN('M', 'F')),
    dno NUMBER(2) REFERENCES dept(deptno)
);

INSERT INTO
    test01
VALUES(
    1001, 'chopa', 'CHOPA', '12345', 'M', null
);


