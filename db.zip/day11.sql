/*
    INDEX
    ==> 검색 속도를 빠르게 하기 위해서 B-Tree 기법으로
        색인을 만들어 SELECT 질의명령을 빠른속도로 처리할 수 있도록 해주는 것.
        
        인덱스를 만들면 안되는 경우
            1. 데이터양이 적은 경우 오히려 속도가 떨어질 수 있다.
                시스템에 따라서 달라지지만
                최소한 몇십만개 이상의 데이터가 있는 경우에만 속도가 향상된다. 
            2. 데이터의 입출력이 빈번한 경우는 오히려 속도가 떨어진다.
                <== 데이터가 입력될 때 마다
                    매번 인덱스를 수정하는 작업이 필요하다.
                    따라서 오히려 속도가 떨어진다.
        
        인덱스를 만들면 효과가 좋아지는 경우
            1. JOIN등에 많이 사용되는 필드가 존재하는 경우
            2. NULL 데이터가 많이 존재하는 경우
            3. WHERE 조건절에 많이 사용되는 컬럼이 존재하는 경우
        
        참고 ]
            기본키 제약조건을 등록하게 되면 자동적으로 인덱스가 만들어진다.
            유일키도 마찬가지이다.
            
    인덱스(Index) 만들기
        
        형식 1 ] : 일반 인덱스 만드는 형식(NON UNIQUE INDEX)
        
            CREATE INDEX 인덱스이름
            ON
                테이블이름(인덱스에 사용할 컬럼이름);
                
            예 ]
                CREATE INDEX name_index
                ON
                    emp(ename);
                ==> 사원들의 이름을 이용해서 색인을 만들어주세요.
                    이름으로 검색을 할 때 처리속도가 빨라진다.
                    
            참고 ]
                일반 인덱스는 데이터가 중복되어도 상관이 없다.
                
        형식 2 ] UNIQUE INDEX 만들기
        ==> 인덱스에 사용될 데이터가 반드시 유일하다는(UNIQUE) 보장이 
            있는 경우 만드는 방법
            
            CREATE UNIQUE INDEX 인덱스이름
            ON
                테이블이름(컬럼이름);
                
            참고 ]
                지정한 컬럼의 내용은 반드시 유일(UNIQUE)하다는 보방이 있어야 한다.
                
            장점 ]
                일반 인덱스보다 처리속도가 빠르다.
                왜냐하면 이진검색을 사용하기 때문에...
--------------------------------------------------------------------------------

복합키 - 기본키의 한 유형
==> 기본키가 아닌 컬럼들 2개 이상을 이용해서 기본키를 지정할 수 있다.
    형식 ]
        CREATE TABLE 테이블이름(
            컬럼이름1 데이터타입(길이)
                CONSTRAINT  제약조건이름 NOT NULL,
            컬럼이름2 데이터타입(길이)
                CONSTRAINT  제약조건이름 UNIQUE,
            .... ,
            CONSTRAINT 제약조건이름 PRIMARY KEY(컬럼이름1, 컬럼이름2, ...)
        );
        
--------------------------------------------------------------------------------
        형식 3 ] 결합 인덱스
        ==> 여러개의 컬럼을 결합해서 하나의 인덱스를 만드는 방법
            이때도 전제조건이 있는데
            여러개의 컬럼의 조합은 반드시 유일(UNIQUE)해야 한다.
            
            즉, 하나의 컬럼만 가지고 UNIQUE INDEX를 만들지 못하는 경우
            여러개의 컬러을 합쳐서 UNIQUE INDEX를 만들어서 사용하는 방법
            
            CREATE UNIQUE INDEX 인덱스이름
            ON
                테이블이름(컬럼1, 컬럼2, ..)
            ;
            
        형식 4 ] 비트 인덱스
        ==> 주로 컬럼의 속성값이 도메인이 결정된 경우( 몇 가지중 하나인 경우 )
            많이 사용하는 방법
            
            예 ]
                gender 컬럼에는 'M', 'F' 만 입력될 것이다.
                deptno 컬럼에는 10, 20, 30, 40 만 입력될 것이다.
                
            이것은 내부적으로 데이터를 이용해서 인덱스를 만들어서 사용하는 기법
            
            CREATE BITMAP INDEX 인덱스이름
            ON
                테이블이름(컬럼이름)
            ;
            
----------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------

사용자 관리
==> 관리자 모드에서 사용자에게 권한을 설정하는 방법
    
    계정이란?
    ==> 은행의 통장과 같은 개념이다.
        하나의 통장은 한사람이 사용할 수 있듯이
        계정은 한사람이 사용할 수 있는 가장 작은 단위의 데이터베이스이다.
        
    1. 사용자 만들기(계정 만들기)
        
        1) 관리자 모드로 접속한다.
            
            SQLPLUS 로 접속
            ==> sqlplus / as sysdba
            
        2) 사용자 만들기
            
            CREATE USER 사용자이름 IDENTIFIED BY 비밀번호;
            
            우리는 luffy 계정을 비밀번호 12345 로 만들어보자.
            ==>
                CREATE USER luffy IDENTIFIED BY 12345;
                
    참고 ]
        현재 접속이 어떤 계정인지를 알아보는 명령
            
            SHOW USER;
            
    참고 ]
        현재 계정은 만들었지만 아무런 권한이 부여되어있지 않은 상태이다.
        따라서 접속도 할 수 없는 상태이다.
        
    2. 사용자에게 권한 부여하기
        
        형식 ]
            GRANT 권한1, 권한2, ... TO 계정이름;
            
        1) 접속 권한 부여하기
        ==> CREATE SESSION
            
            GRANT CREATE SESSION TO luffy;
            
            ALTER USER luffy DEFAULT TABLESPACE USERS;
            ALTER USER luffy TEMPORARY TABLESPACE TEMP;
            
            
            참고 ]
                SESSION
                ==> 오라클에 접속하면 오라클이 제공하는 권리를 말하며
                    오라클이 가격이 달라지는 이유는
                    이 세션의 갯수에 따라서 오라클 가격이 달라진다.
                    
        2) 기타 권한은 권한 부여 형식에 맞춰서 부여하면 된다.
        
            예 ]
                테이블을 만들 수 있는 권한을 주고자 하면
                
                GRANT create table TO luffy;
                
--------------------------------------------------------------------------------
권한을 부여할 때 사용되는 옵션
    
    WITH ADMIN OPTION
    ==> 부여받은 권한에 한해서 관리자 권한을 일임받을 수 있도록 하는 옵션

다른 계정의 테이블 사용하기
==> 원칙적으로 하나의 계정은 그 계정이 소유한 테이블만 사용할 수 있다.
    
    하지만 여러계정들이 다른 계정의 테이블을 공동으로 사용할 수 있다.
    이때는 권한이 필요하다.
    
        GRANT SELECT ON 계정A.테이블이름 TO 계정B이름;

관리자에게 부여받은 권한을 다른 계정에게 전파하기
    GRANT 권한 TO 계정
    WITH GRANT OPTION;
    
    순서 ]
        1. 관리자가 특정권한을 WITH ADMIN OPTION으로 계정1에게 부여해준다.
        2. 계정1이 부여받은 특정권한을 WITH GRANT OPTION으로 계정2에게 부여해준다.
        3. 계정2는 계정3에게 특정권한을 부여한다.

--------------------------------------------------------------------------------------
권한 수정하기
==> 별도의 명령이 존재하는 것이 아니고
    GRANT 명령을 이용해서 다시 권한을 부여하면 된다.
    
권한 회수하기
    
    형식 ]
        REVOKE 회수할 권한 FROM 계정이름;

사용자 제거
    
    형식 ]
        DROP USER 계정이름 CASCADE;


*/

-- SANJI 계정을 만들고 세션을 만들 수 있는 권한을 부여하세요.
CREATE USER sanji IDENTIFIED BY 12345;
GRANT create session TO sanji;

-- 기본 테이블 공간 변경
ALTER USER sanji DEFAULT TABLESPACE USERS;

/*
    관리자 모드에서 luffy 계정에게 
        테이블을 만들 수 있는 권한을 부여하고
        이 권한을 sanji 에게도 부여할 수 있도록 
    권한을 부여하세요.
*/

GRANT create table TO luffy WITH ADMIN OPTION;

-- LUFFY 계정에서....
GRANT CREATE TABLE TO sanji;

-- system 계정에서 ...
select * from scott.emp;

-- sanji 계정에게 scott 이 소유한 emp 테이블을 조회할 수 있는 권한을 부여하자.
GRANT SELECT ON scott.emp TO sanji;

-- SELECT ANY TABLE 권한을 CHOPA에게 WITH ADMIN OPTION 까지 부여하자.
GRANT SELECT ANY TABLE TO chopa WITH ADMIN OPTION;
GRANT SELECT ON scott.dept TO chopa WITH GRANT OPTION;

-- CHOPA 계정에서 ....
GRANT SELECT ANY TABLE TO sanji WITH ADMIN OPTION;
GRANT SELECT ON scott.dept TO sanji;

-- SELECT ANY TABLE 권한을 CHOPA, SANJI 에게서 회수
REVOKE SELECT ANY TABLE FROM chopa;
REVOKE SELECT ANY TABLE FROM sanji;

DROP USER luffy;
DROP USER sanji;

-- CHOPA  계정에서...
CREATE TABLE test01(
    no NUMBER(4),
    name VARCHAR2(30 CHAR),
    qt NUMBER(6)
);

-- SYSTEM 에서 ...
CREATE USER luffy IDENTIFIED BY 12345;
ALTER USER luffy DEFAULT TABLESPACE USERS;

GRANT CREATE SESSION TO luffy;
GRANT SELECT ON chopa.test01 TO luffy;
GRANT CREATE VIEW TO lUFFY;

drop user chopa;

--------------------------------------------------------------------------------
/*
    롤을 이용한 권한 부여
    ==> 
        ROLE
        ==> 관련된 권한을 묶어놓은 객체(권한의 묶음)을 의미하는 용어
        
        롤을 사용한 권한 부여란
        여러개의 권한을 동시에 부여하는 방법
        
        1. 이미 만들어진 롤을 이용하는 방법
            1) CONNECT
                주로 CREATE 와 관련된 권한들의 묶음
                
            2) RESOURCE
                사용자 객체 생성에 관련된 권한들의 묶음
                
            3) DBA
                관리자 계정에서 처리할 수 있는 관리자 권한을 묶어놓은 롤
                
        롤을 이용해서 권한 부여하는 방법
            
            GRANT 롤이름 TO 계정이름;
                
        LUFFY 계정에게 CONNECT와 RESOURCE 롤을 부여해보자.
            
            GRANT CONNECT, RESOURCE TO luffy;
                
            
        2. 사용자가 롤을 만들어서 이용하는 방법(*** 순서가 중요 ***)
            ==> 롤안에 그 롤에 필요한 권한을 사용자가 지정한 후 사용하는 방법
            
                작업순서 ]
                    
                    1. CREATE ROLE 롤이름; ===> 롤을 만든다.
                    2. GRANT 권한1, 권한2, ... TO 롤이름; ==> 만든 롤에 권한을 부여한다.
                    3. GRANT 롤이름 TO 계정이름;   ===> 계정에게 롤로 권한을 부여한다.
                    
-------------------------------------------------------------------------------------------
롤 회수하기
==> 권한 회수와 동일한 방법으로 회수하면 된다.

롤 삭제하기
==> 
    형식 ]
        DROP ROLE 롤이름;


==============================================================================================
동의어(Synonym)
==> 테이블 자체에 별칭을 부여해서 여러 사용자가 
    각각의 이름으로 하나의 테이블을 사용하도록 하는 것.
    
    즉, 실제 객체(테이블, 뷰, 시퀀스, 프로시저) 이름은 감추고
    사용자에게는 별칭을 부여해서
    객체를 보호할 수 있도록 하는 방법
    
    주로 다른 계정을 사용하는 사용자가
    테이블이름을 알면 곤란하기 때문에
    이들에게는 거짓 테이블 이름을 알려주어서
    실제 테이블이름을 감추기 위한 목적으로 사용
    
    형식 ]
        CREATE [PUBLIC] SYNONYM 별칭이름
        FOR 실제이름;
        
    참고 ]
        PUBLIC 
        ==> 생략되면 이 동의어는 같은 계정에서만 사용하는 동의어가 된다.
            (물론 권한을 부여하면 다른 계정도 사용할 수 있기는 하지만...)
            PUBLIC 이 붙은 별칭을 사용하면 자동적으로 다른 계정도
            이 동의어를 이용해서 테이블을 사용할 수 있게 된다.
            
            
    PUBLIC 동의어 만들기
    ==> 모든 계정에서 특정 객체(테이블, 뷰, 시퀀스, ... )를 사용할 수 있도록 하는것.
        
        참고 ]
            PUBLIC 동의어를 사용하기 위해서는
            해당 객체가 PUBLIC 사용권한을 부여 받아야 한다.
            
    -- CHOPA 계정이 소유한 EMP 테이블에 PUBLIC 동의어를 지정하고 모든 계정에서 사용할 수 있도록 하자.
    
        GRANT SELECT ON emp TO public;
        ==> emp 테이블을 public 이 사용할 수 있도록 권한 부여
        
        ==> public 동의어를 만들어준다.
        -- *** system 계정에서 작업
        CREATE PUBLIC SYNONYM PUMP
        FOR chopa.emp;

        -- scott 계정에서 pump 조회
        SELECT
            *
        FROM
            pump
        ;









                    
*/

-- chopa 에게 scott이 소유한 emp, dept,salgrade, bonus 테이블을 조회할 수 있는 권한을 부여하세요.

-- emp
GRANT SELECT ON scott.emp TO chopa;
-- dept
GRANT SELECT ON scott.dept TO chopa;
-- salgrade
GRANT SELECT ON scott.salgrade TO chopa;
-- bonus
GRANT SELECT ON scott.bonus TO chopa;

-- chopa계정에서
-- 돌발
-- scott.dept 를 복사해서 dept 테이블 만들고
-- emp, salgrade, bonus 테이블을 복사하세요.

-- dept
CREATE TABLE dept
AS
    SELECT
        *
    FROM
        scott.dept
;
-- emp
CREATE TABLE emp
AS
    SELECT
        *
    FROM
        scott.emp
;

-- salgrade
CREATE TABLE salgrade
AS
    SELECT
        *
    FROM
        scott.salgrade
;

-- bonus
CREATE TABLE bonus
AS
    SELECT
        *
    FROM
        scott.bonus
;

--  부서별 직계를 할 뷰 dnoAgr 를 만드세요
CREATE OR REPLACE VIEW dnoAgr
AS
    SELECT
        deptno dno, SUM(sal) sum, AVG(sal) avg, MIN(sal) min, MAX(sal) max, COUNT(*) cnt
    FROM
        emp
    GROUP BY
        deptno
;


-- system 계정에서...
GRANT CREATE ROLE TO chopa;
GRANT create view, create table, create session TO chopa WITH ADMIN OPTION;

-- chopa 계정에게 create view, create index, create table, create session 권한을 
--  묶어놓은 cpRole 을 만들어서 부여해보자.

-- 1. role 을 만들고
CREATE ROLE cpRole;
-- 2. 롤에 권한 부여
GRANT create view, create table, create session TO cpRole;
-- 3. chopa 계정에게 cpRole 부여
GRANT cpRole TO chopa;

CREATE OR REPLACE VIEW V01
AS
    SELECT
        *
    FROM
        scott.emp
;


--  부서별 직계를 할 뷰 dnoAgr 를 만드세요
CREATE OR REPLACE VIEW dnoAgr
AS
    SELECT
        deptno dno, SUM(sal) sum, AVG(sal) avg, MIN(sal) min, MAX(sal) max, COUNT(*) cnt
    FROM
        emp
    GROUP BY
        deptno
;








