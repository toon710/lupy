
-- @D:\class\db\src\studentmanagement.sql -- SQL 스크립트 문서 실행방법

/*
무결성 제약조건
==> 입력되서는 안되는 데이터가 입력되는 것을 방지하는 무결성 확보 수단.

    종류 ]
        1. PRIMARY KEY(기본키)
        2. FORENGN KEY(참조키, 외래키, FOREIGN 키)
        3. NOT NULL(낫널)
        4. UNIQUE(유일키)
        5. CHECK(체크)
        
        참고 ]
            DEFAULT : 입력시 지정하지 않은 컬럼에 채워줄 기본 값을 정의하는 속성.
            
1. PRIMARY KEY : NOT NULL + UNIQUE 포함하고 있는 제약조건
                 데이터 한행을 구분해줄 수 있는 키. 
                 되도록이면 추가해줘야할 제약조건.
                 
2. 참조키 | FROEIGN KEY : 참조하는 테이블(FROM)의 참조 컬럼에 입력되어있지 않은 데이터가 
            참조받는(TO) 테이블의 컬럼 데이터로 입력되는 것을 방지하는 제약조건.
            
            형식 ]
                REFERENCES 테이블이름(컬럼이름)
            예 ]
                부서정보테이블(DEPT) 테이블의 DEPTNO 컬럼에 입력되어있지 않는 데이터는
                사원정보테이블(EMP) 테이블의 DEPTNO 컬럼에 입력할 수 없다.
        
3. NOT NULL : 입력될 데이터가 준비가 안되어서 NULL 로 채워질 경우
                입력할 수 없도록 방지하는 제약조건
                반드시 데이터 입력이 필요하다.
                
                예를 들어 INSERT 질의명령에서 컬럼을 기술하지 않는 경우
                그 컬럼의 데이터는 DEFAULT 속성으로 지정해 놓은 값이 채워질 것이고
                만약 이때 DEFAULT 속성이 정의되어있지 않은 경우는 NULL 데이터로 채워지게 된다.
                이런 경우 NOT NULL 제약조건이 등록되어있으면 
                무결성 제약조건 위배가 발생한다.
                
4. UNIQUE   : 컬럼의 속성값이 다른행의 속성값과 구분되는 값으로 입력되어야 하는 제약조건
                이때 null 데이터는 허용한다.
                즉 속성값이 유일해야 한다는 의미이다.
                
5. CHECK    : 속성의 속성값의 종류가 결정되어있는 경우
                결정된 값 이외의 데이터가 입력되는 것을 방지하는 제약조건
                도메인 이외의 데이터가 입력되는 것을 방지하는 제약조건.
                
                형식 ]
                    CHECK (컬럼이름     IN (데이터1, 데이터2, ...))

*/


-- PRIMARY KEY 제약조건 위배 예
INSERT INTO
    test01
VALUES(
    1002, 'luffy', 'LUFFY', '12345', 'M', 40
);

commit;

INSERT INTO
    test01(no, name, pw, gen, dno)
VALUES(
    1003, 'SANJI', '12345', 'M', 40
);


INSERT INTO
    test01(no, name, pw, gen, dno)
VALUES(
    1004, 'ZORO', '12345', 'M', 40
);

--------------------------------------------------------------------------------

/*
    2) 명시적 무결성 제약조건 등록하는 방법( 권장 방법 )
        형식 ]
            
            CREATE TABLE 테이블이름(
                컬럼이름    타입(길이) [ DEFAULT 데이터 ]
                    CONSTRAINT  제약조건이름  제약조건형식
                    CONSTRAINT  제약조건이름  제약조건형식
                    ...                                     ,
                컬럼이름    타입(길이)  [ DEFAULT 데이터 ]
                    CONSTRAINT  제약조건이름  제약조건형식
                    ...                                     ,
                    
            );
            
            ==>
            CREATE TABLE 테이블이름(
                컬럼이름1    데이터타입(길이)   [ DEFAULT 데이터 ]
                    CONSTRAINT 제약조건이름   PRIMARY KEY,
                컬럼이름2    데이터타입(길이)   [ DEFAULT 데이터 ]
                    CONSTRAINT 제약조건이름   REFERENCES  테이블이름(컬럼이름),
                컬럼이름3    데이터타입(길이)   [ DEFAULT 데이터 ]
                    CONSTRAINT 제약조건이름   UNIQUE,
                컬럼이름4    데이터타입(길이)   [ DEFAULT 데이터 ]
                    CONSTRAINT 제약조건이름   NOT NULL,
                컬럼이름5    데이터타입(길이)   [ DEFAULT 데이터 ]
                    CONSTRAINT 제약조건이름   CHECK (컬럼이름5  IN (데이터1, 데이터2, ... ))
            );
            
        참고 ]
            제약조건 이름 만드는 방법
                
                테이블이름_컬럼이름_제약조건
                
            의 형식을 사용하는 것이 좋다.
            <== 제약조건의 이름은 시스템에 등록되서 시스템이 관리를 하기 때문에
                유일해야 한다.
                만약 겹치면 테이블 생성 또는 제약조건 추가가 
                되지 않는다.
                
                이름에 사용되는 제약조건 약자
                    PK  - PRIMARY KEY
                    FK  - FOREIGN KEY
                    UK  - UNIQUE
                    CK  - CHECK
                    NN  - NOT NULL
*/


-- test01 테이블 삭제
drop table test01;

CREATE TABLE test01(
    no NUMBER(4)
        CONSTRAINT TEST01_NO_PK PRIMARY KEY,
    id  VARCHAR2(10 CHAR)
        CONSTRAINT TEST01_ID_UK UNIQUE
        CONSTRAINT TEST01_ID_NN NOT NULL,
    name VARCHAR2(15 CHAR)
        CONSTRAINT TEST01_NAME_NN NOT NULL,
    pw VARCHAR2(8 CHAR) DEFAULT '12345'
        CONSTRAINT TEST01_PW_NN NOT NULL,
    gen CHAR(1)
        CONSTRAINT TEST01_GEN_CK CHECK (gen IN ('M', 'F'))
        CONSTRAINT TEST01_GEN_NN NOT NULL,
    dno NUMBER(2)
        CONSTRAINT TEST01_DNO_FK REFERENCES dept(deptno)
        CONSTRAINT TEST01_DNO_NN NOT NULL
);


INSERT INTO
    test01
VALUES(
    1001, 'chopa', 'CHOPA', '12345', 'M', 40
);

INSERT INTO
    test01
VALUES(
    1002, 'luffy', 'LUFFY', '12345', 'M', 40
);

INSERT INTO
    test01
VALUES(
    1003, 'sanji', 'SANJI', '12345', 'M', 40
);

INSERT INTO
    test01
VALUES(
    1004, 'zoro', 'ZORO', '12345', 'M', 40
);

commit;

/*
    chopa 계정에서 
    사원들의 정보를 기억할 emp 테이블을 생성하세요.
    참조하는 테이블이 있으면 그 테이블도 만드세요.
    
    dept
    emp
    salgrade
    bonus
*/

