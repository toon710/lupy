/*

ANSI Join
==> 질의명령은 데이터베이스(DBMS)에 마다 약간씩 문법이 달라진다.

    ANSI 형이란?
    북미표준화협회(ANSI 협회)에서 공통의 질의명령을 만들고자해서
    통일된 방식의 명령을 만들어 놓은 것.
    
1. Cross Join
==> 오라클의 Cartesion Product 방식으로 처리되는 조인
    ==> 걸러지지 않은 조인
    
    형식 ]
        SELECT
            필드이름1, 필드이름2 ....
        FROM
            테이블1
        CROSS JOIN
            테이블2
        ;
        
    예 ]
        -- Oracle Join
        SELECT * FROM emp, dept;
        ==> 
        -- ANSI JOIN
        SELECT
            *
        FROM
            emp
        CROSS JOIN
            dept
        ;
        
2. Inner Join
==> CROSS JOIN 의 결과내에서 데이터를 걸러내는 조인
    
    형식 ]
        SELECT
            컬럼이름1, 컬럼이름2, ...
        FROM
            테이블1
        INNER JOIN
            테이블2
        ON
            조인조건
        ;
    
    예 ]
        사원들의 사원이름, 부서번호, 부서이름, 부서위치 을 조회하세요.
        
        SELECT
            ename 사원이름, e.deptno 부서번호, dname 부서이름, loc 부서위치
        FROM
            emp e
        INNER JOIN
            dept d
        ON
            e.deptno = d.deptno -- EQUI JOIN
        ;
        
    참고 ]
        만약 다른 일반 조건이 필요한 경우는
        WHERE 절에 기술해야 한다.
        즉, ON 절에는 오직 조인 조건만 기술 해야 한다.
        
    참고 ]
        INNER JOIN은 가장 일반적인 조인이기 때문에
        INNER JOIN 대신 JOIN이라고만 사용해도 된다.
        
    예 ]
        20번 부서에 소속된 사원들의
            사원이름, 직급, 급여, 급여등급을 조회하세요.
            
        SELECT
            ename 사원이름, job 직급, sal 급여, grade 급여등급
        FROM
            emp
        JOIN
            salgrade
        ON
            sal BETWEEN losal AND hisal -- NON EQUI JOIN
        WHERE
            deptno = 20
        ;
3. Outer Join
==> Outer Join 을 처리하는 ANSI OUTER JOIN

    형식 ]
        SELECT
            컬럼이름1, 컬럼이름2, ...
        FROM    테이블이름1  LEFT | RIGHT | FULL     OUTER JOIN  테이블이름2
        ON
            조인조건식
        
        참고 ]
            LEFT | RIGHT | FULL : 데이터가 있는 테이블쪽을 가리킨다.
            
        참고 ]
            오라클 조인에서는 (+) 기호를 양쪽에 모두 기술 하는 경우는 없다.
            오직 한쪽에만 기술해야 한다.
            
        예 ]
            사원들의 사원이름, 직급, 상사번호, 상사이름 을 조회하세요.
            
            SELECT
                e.ename 사원이름, e.job 직급, e.mgr 상사번호, s.ename 상사이름
            FROM
                emp e
            FULL OUTER JOIN
                emp s
            ON
                e.mgr = s.empno
            ;
4. Natural Join
    ==> 자동 조인으로
        반드시 조인 조건식에 사용되는 필드의 이름이 동일하고
        반드시 이름이 동일한 필드가 한개인 경우 사용할 수 있는 조인
        
    형식 ]
        SELECT
            컬럼이름1, 컬럼이름2, ...
        FROM
            테이블1
        NATURAL JOIN
            테이블2
        ;
        
    참고 ]
        ON 절이 없는 이유
        ==>
            NATURAL JOIN의 전제조건이
            두개의 테이블이 반드시 한개의 컬럼이 이름이 같고
            그 컬럼이 조인조건으로 사용되어야 하는 컬럼이기 때문이다.
            따라서 자동적으로 그 컬럼을 이용해서 조인을 하게 된다.
        
        예 ]
            사원들의 사원이름, 직급, 부서번호, 부서위치를 조회하세요.
            
            SELECT
                ename, job, deptno, loc
            FROM
                emp
            NATURAL JOIN
                dept
            ;
5. Using Join
==> 
    반드시 조인조건식에 사용되는 컬럼의 이름이 동일한 경우이고
    동일한 이름의 컬럼이 여러개 존재하는 경우 사용하는 조인
    
    형식 ]
        SELECT
            컬럼이름1, 컬럼이름2, ....
        FROM
            테이블1
        JOIN
            테이블2
        USING
            (조인조건컬럼이름)
        ;
    
    예 ] 사원들의 사원이름, 직급, 부서이름을 조회하세요.
        
        SELECT
            ename 사원이름, job 직급, dname 부서이름
        FROM
            emp
        JOIN
            dept
        USING
            (deptno)
        ;
*/

/*
    사원들의 
        사원이름, 직급, 부서번호, 상사번호, 상사이름 을 조회하세요.
*/

SELECT
    e.ename 사원이름, e.job 직급, e.deptno 부서번호, e.mgr 상사번호, s.ename 상사이름
FROM
    emp e   -- 사원 정보 테이블
JOIN
    emp s   -- 상사 정보 테이블
ON
    e.mgr = s.empno
;

/*
    사원들의 사원이름, 직급, 급여, 급여등급, 부서번호, 부서이름 을 조회하세요.
*/

SELECT
    ename 사원이름, job 직급, sal 급여, grade 급여등급, e.deptno 부서번호, dname 부서이름
FROM
    emp e
JOIN
    dept d
ON
    e.deptno = d.deptno
JOIN
    salgrade
ON
    sal BETWEEN losal AND hisal
;

-- 오라클 풀아우터 조인
SELECT
    e.ename 사원이름, e.job 직급, e.mgr 상사번호, s.ename 상사이름
FROM
    emp e, emp s
WHERE
    e.mgr = s.empno(+)
UNION
SELECT
    e.ename 사원이름, e.job 직급, e.mgr 상사번호, s.ename 상사이름
FROM
    emp e, emp s
WHERE
    e.mgr(+) = s.empno
;

--------------------------------------------------------------------------------
/*

DDL 
    CREATE
    ALTER
    DROP
    TRUNCATE
    
DML
    SELECT
    INSERT
    UPDATE
    DELETE
    
DCL
    GRANT
    REVOKE
    
    COMMIT
    ROLLBACK
    SAVEPOINT
    ..

DML(Data Manipulation Language) : 데이터 조작 언어
==> 데이터를 처리하는 명령
    이 명령안에는 INSERT, UPDATE, DELETE 명령이 포함된다.
    
    1. INSERT 명령
    ==> 새로운 데이터를 추가하는 명령. 테이블에 한개의 행을 추가하는 명령
    
        형식 ]
             INSERT INTO
                테이블이름(컬럼이름1, 컬럼이름2, ...)
             VALUES(
                데이터1, 데이터2, ...
             );
             
        의미 ]
            지정한 테이블의 지정한 필드에 데이터를 입력해주세요.
            
        주의 ]
            컬럼이름 갯수만큼 데이터의 갯수가 준비되서 입력되어야 한다.
            단, 데이터가 준비가 안된 경우 
                NULL
            을 입력해주면 된다.
            
            데이터의 형태와 컬럼의 형태는 반드시 일치해야 한다.
            
        참고 ]
            테이블이 가지고 있는 모든 컬럼에 데이터를 입력해야 되는 경우
            컬럼이름 나열은 생략해도 된다.
            
                INSERT INTO
                    테이블이름
                VALUES(
                    데이터1, 데이터2, 데이터3, ....
                );
        예 ]
            temp2에 8000번 이름은 chopa 부서는 40번 데이터를 추가하세요.
            
            INSERT INTO
                temp2
            VALUES(
                8000, 'chopa', 40
            );
            
            8001번 luffy 사원의 정보를 temp2에 입력하세요.
            
            INSERT INTO
                temp2(eno, name)
            VALUES(
                8001, 'luffy'
            );
            
    --------------------------------------------------------------------------==
    
    2. UPDATE
    ==> 입력되어있는 데이터의 내용을 수정하는 명령
        
        형식 ]
            UPDATE
                테이블이름
            SET
                컬럼이름 = 데이터
            [WHERE
                조건식
            ]
            
        주의 ]
            UPDATE 명령에서 조건절을 기술하지 않으면
            테이블의 모든 데이터가 수정된다.
            
        commit;
        
        예 ] temp2 에 입력된 사원들의 부서번호를 40번으로 수정하세요.
            
            UPDATE
                temp2
            SET
                dno = 40
            ;
            
        rollback;
        
        -- luffy 사원의 부서번호를 30번으로 수정하세요.
        
        UPDATE
            temp2
        SET
            dno = 30
        WHERE
            name = 'luffy'
            
    참고 ]
        변경할 데이터는 수식을 사용해도 무방하다.
        
    예 ]
        chopa 사원의 급여를 기존급여에 1000을 더한 값으로 수정하세요.
        
        UPDATE
            temp2
        SET
            sal = sal + 1000
        WHERE
            name = 'chopa'
        ;
        
    참고 ]
        두개 이상의 컬럼을 동시에 수정할 수 있다.
        
        luffy 사원의 급여를 300을 삭감하고 부서는 20번으로 이동시키세요.
        
        UPDATE
            temp2
        SET
            dno = 20, 
            sal = sal - 300
        WHERE
            name = 'luffy'
        ;
        
    참고 ]
        나열된 컬럼이름중 수정을 원하지 않는 컬럼의 데이터도
        set 절에 기존데이터로 입력해줘야 한다.
        
    참고 ]
        서브질의를 사용해서 여러개의 컬럼을 동시에 수정할 수 있다.
        
        예 ]
            temp2 테이블에서 부서번호가 10번인 사원들의
            부서번호, 급여를
            emp 테이블의 데이터로 수정하세요.
            
            UPDATE
                temp2
            SET
                (dno, sal) = (
                                SELECT
                                    deptno, sal
                                FROM
                                    emp
                                WHERE
                                    empno = eno
                            )
            WHERE
                dno = 10
            ;
--------------------------------------------------------------------------------
    3. DELETE
        ==> 테이블에 입력된 데이터중에서 필요하지 않은 데이터를 삭제하는 명령
        
        형식 ]
            DELETE
            FROM
                테이블이름
            [WHERE
                조건식
            ]
            ;
            
        참고 ]
            WHERE 조건절을 기술하지 않으면
            해당 테이블의 모든 데이터가 삭제 된다.
            
            
        commit;    
        예 ]
            temp2 테이블의 사원중 10번 부서 소속이 아닌 사원들의 데이터를 삭제하세요.
            
            
            
            DELETE FROM
                temp2
            ;
            
            rollback;
            
            DELETE FROM
                temp2
            WHERE
            --    NOT dno = 10
            --    dno <> 10
            --    dno != 10
                dno ^= 10
            ;
*/

ALTER TABLE temp2
ADD sal NUMBER(8) DEFAULT 800
    CONSTRAINT TMP2_SAL_NN NOT NULL;
    
/*
    DDL(Data Definition Language) : 데이터 정의 언어
    ==> 데이터가 기억될 공간(테이블) 에 관련된 명령들...
    
    1. 테이블 만들기
        
        형식 1 ]
            CREATE TABLE 테이블이름(
                컬럼이름1   데이터타입(길이),
                컬럼이름2   테이터타입(길이),
                ...
            );
            
        형식 2 ] - 제한사항을 기록하면서 테이블을 생성하는 방법
            CREATE TABLE  테이블이름(
                컬럼이름1   데이터타입(길이) [DEFAULT  데이터]
                    CONSTRAINT  제약조건이름1  제약조건1
                    CONSTRAINT  제약조건이름2  제약조건1,
                컬럼이름2   데이터타입(길이) [DEFAULT  데이터]
                    CONSTRIANT  제약조건이름3     제약조건
                    CONSTRAINT  제약조건이름4     제약조건
                    ...                                     ,
                ......
            );
            
    2. ALTER : 개체(테이블 등)를 수정하는 명령
        
        테이블
            1) 새로운 컬럼 추가하는 명령
                
                형식 ]
                    ALTER TABLE 테이블이름
                    ADD (
                        컬럼이름    데이터타입(길이) [DEFAULT 데이터]
                            CONSTRAINT 제약조건이름   제약조건
                            CONSTRAINT 제약조건이름   제약조건
                            ...
                    );
                    
            2) 컬럼이름 변경하기
                
                형식 ]
                    ALTER TABLE 테이블이름
                    RENAME COLUMN 컬럼이름 TO 새컬럼이름;
                    
            3) 컬럼의 데이터 길이를 수정하기
                
                형식 ]
                    ALTER TABLE 테이블이름
                    MODIFY 컬럼이름(새로운길이);
                    
            4) 테이블 이름 변경
                
                형식 ]
                    ALTER TABLE 테이블이름   RENAME TO   새로운테이블이름;
                    
     3. 개체(테이블) 삭제
          형식 1 ]
                 DROP 개체유형  개체이름;
                 
            예 ] TMP 테이블을 삭제하세요.
                DROP TABLE TMP;
                
                LUFFY  계정을 삭제하세요.
                DROP USER LUFFY;
                
            형식 2 ]
                DROP 개체유형 개체이름  PURGE;
                
            
            참고 ]
                DML 명령은 복구가 가능하지만(ROLLBACK 명령, 커밋되지 않은 경우에 한해서...)
                DDL 명령은 원칙적으로 복구가 불가능하다.
                
                오라클 10g 부터는 휴지통 개념을 이용해서
                삭제된 테이블을 휴지통에 보관하도록 해 놓았다.
                
                휴지통 관리 ]
                    1. 휴지통에 있는 모든 테이블을 완전 삭제하는 명령
                        
                        PURGE RECYCLEBIN;
                        
                    2. 휴지통에 있는 특정 테이블만 완전 삭제 하는 명령
                        
                        PURGE TABLE 테이블이름;
                        
                    3. 휴지통 확인하는 명령
                        
                        SHOW RECYCLEBIN;
                        
                    4. 휴지통에 삭제한 테이블을 복원하는 명령
                        
                        FLASHBACK TABLE 테이블이름   TO  BEFORE DROP;
                        
    4. TRUNCATE
    ==> DELETE 명령과 같이 테이블안의 모든 데이터를 삭제하는 명령
    
        형식 ]
            TRUNCATE TABLE 테이블이름;
            
        참고 ]
            DELETE 명령과의 차이점
                DELETE  명령은 DML 소속 명령으로 실행후 트랜잭션이 발생하기 이전에는
                데이터베이스에 적용되지 않는다.
                
                TRUNCATE  명령은 DDL 소속 명령으로 실행하는 순간 트랜잭션이 발생해서
                데이터베이스에 적용시킨다.
                
-------------------------------------------------------------------------------------------

참고 ]
    DDL 명령은 실행되는 순간 트랜잭션이 발생한다.
    따라서 이제까지의 모든 작업내용이 데이터베이스에 적용이 된다.
    
    DML - INSERT
    DML - UPDATE
    DML - INSERT
    DML - INSERT
    DML - INSERT
    DML - DELETE    ---> 데이터베이스에 적용되지 않은 상태
    
    DDL - CREATE TABLE ...  ---> 위의 모든 작업내용이 데이터베이스에 적용된다.
                    
                    
*/
ROLLBACK;








