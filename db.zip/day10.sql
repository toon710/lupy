/*
    무결성 제약 조건
        
        1. 컬럼 레벨에서 추가하는 방법
            1) 무명 제약조건을 추가하는 방법 
                - 오라클이 자동으로 제약조건의 이름을 만들어서 붙여준다.
                형식 ]
                    컬럼이름    데이터타입(길이) [DEFAULT 데이터] PRIMARY KEY,
                    컬럼이름    데이터타입(길이) [DEFAULT 데이터] REFERENCES 테이블이름(컬럼이름),
                    컬럼이름    데이터타입(길이) [DEFAULT 데이터] UNIQUE,
                    컬럼이름    데이터타입(길이) [DEFAULT 데이터] NOT NULL,
                    컬럼이름    데이터타입(길이) [DEFAULT 데이터] CHECK(컬럼이름 IN( 데이터1, 데이터2, ... ))
                    
            2) 제약조건의 이름을 만들어서 추가하는 방법
                ***
                형식 ]
                    컬럼이름    데이터타입(길이) [DEFAULT 데이터]
                        CONSTRAINT 제약조건이름   PRIMARY KEY,
                    컬럼이름    데이터타입(길이) [DEFAULT 데이터]
                        CONSTRAINT 제약조건이름   REFERENCES 테이블이름(컬럼이름),
                    컬럼이름    데이터타입(길이) [DEFAULT 데이터]
                        CONSTRAINT 제약조건이름   UNIQUE,
                    컬럼이름    데이터타입(길이) [DEFAULT 데이터]
                        CONSTRAINT 제약조건이름   NOT NULL,
                    컬럼이름    데이터타입(길이) [DEFAULT 데이터]
                        CONSTRAINT 제약조건이름   CHECK (컬럼이름 IN(데이터1, 데이터2, ...))
                    
                
        2. 테이블 레벨에서 추가하는 방법
            ==> 컬럼을 미리 정의 하고 나중에 제약조건을 추가하는 방법
            
            형식 ]
                CREATE TABLE 테이블이름(
                    컬럼이름1 데이터타입(길이) [DEFAULT 데이터],
                    컬럼이름2 데이터타입(길이) [DEFAULT 데이터],
                    컬럼이름3 데이터타입(길이) [DEFAULT 데이터],
                    컬럼이름4 데이터타입(길이) [DEFAULT 데이터],
                    컬럼이름5 데이터타입(길이) [DEFAULT 데이터]
                        CONSTRAINT 제약조건이름 NOT NULL,
                        ==> NOT NULL 의 경우 아무 조치없이 컬럼을 생성하게 되면
                            기본적으로 NULL 데이터의 입력을 허용하는 상태로 만들어진다.
                            따라서 이 특성을 변경하는 형태로 제약조건이 등록이 되어야 한다.
                    CONSTRAINT 제약조건이름   PRIMARY KEY(컬럼이름1),
                    CONSTRAINT 제약조건이름   FOREIGN KEY(컬럼이름2) REFERENCES 테이블이름(컬럼이름),
                    CONSTRAINT 제약조건이름   UNIQUE(컬럼이름3),
                    CONSTRAINT 제약조건이름   CHECK(컬럼이름4 IN(데이터1, 데이터2, ...))
                )
----------------------------------------------------------------------------------------------------------------
데이터 타입
    1. 숫자형
        NUMBER  - 32자리 까지 기억할 수 있다.
        
    2. 문자형
        CHAR        - 고정길이 문자 타입    - 최대 2000 바이트
        VARCHAR2    - 가변길이 문자 타입    - 최대 4000 바이트
        
        LONG        - 가변길이 문자 타입    - 최대 2GB
        CLOB        - 가변길이 문자 타입    - 최대 4GB
        
        일반적으로 사용되는 문자 타입은 CHAR, VARCHAR2를 많이 사용하는데
        데이터 저장 효율성 면에서는 VARCHAR2가 유리하지만
        처리 속도면에서는  CHAR이 빠르다.
        
        CHAR 타입은
        문자 데이터의 길이가 고정된 경우에 한해서 흔히 사용되는 타입이다.
        예 ]
            전화번호, 우편번호, 생년월일
            
    3. 날짜 타입
        DATE
        
    4. 바이너리 타입
        BLOB - 바이너리 코드를 기억할 수 있는 타입 - 최대 4GB
        
참고 ]
    데이터베이스에 따라서 데이터의 형태도 약간씩 달라진다.
    따라서 ANSI 데이터 형태라고 해서
    모든 데이터베이스에 적용 가능한 공통 형태를 ANSI 협회에서 제시하고 있다.
        
----------------------------------------------------------------------------------------------------------------
2. 이미 만들어진 테이블에 제약조건을 등록하는 방법
    ***
    형식 1 ] - 명시적 제약조건 등록
        ALTER TABLE 테이블이름
        ADD CONSTRAINT 제약조건이름   제약조건유형(컬럼이름);
        
    형식 2 ]  - 무명 제약조건 등록
        ALTER TABLE 테이블이름
        ADD 제약조건(컬럼이름);
        
    참고 ]
        NOT NULL 제약조건 만큼은 제약조건을 추가하는 형식으로 등록할 수 없다.
        왜냐하면 이미 NULL 데이터 입력에 대한 특성이 테이블 생성시 등록이 되어있기 때문이다.
        따라서 NOT NULL 제약조건은 컬럼을 수정하는 형식으로 등록해야 한다.
        
        *****
        형식 ]
            ALTER TABLE 테이블이름
            MODIFY 컬럼이름 [DEFAULT 데이터]
                CONSTRAINT 제약조건이름 NOT NULL;
                
--------------------------------------------------------------------------------
제약조건 삭제하기
    형식 ]
        ALTER TABLE 테이블이름
        DROP CONSTRAINT 제약조건이름;
        
    참고 ]
        PRIMARY KEY 는 제약조건의 이름을 기술하지 않아도 삭제할 수 있다.
        하나의 테이블에 등록된 PRIMARY KEY는 한개만 등록이 되기때문에...
        
        형식 ]
            ALTER TABLE  테이블이름
            DROP PRIMARY KEY;
            
참고 ]
    등록된 제약조건 확인하는 방법
    ==> 등록된 제약조건은 오라클이 테이블을 이용해서 관리하고 있다.
        이 테이블이름이
            USER_CONSTRAINTS
        이다.
        
        이 테이블의 내용을 확인하면 등록된 제약조건을 확인할 수 있다.
        
*****
참고 ]
    참조키(FOREIGN KEY, 외래키) 제약 조건의 경우
    참조할 수 있는 컬럼은 기본키이거나 유일키 여야 한다.
        
*/

-- 사원 정보 테이블의 DDL 명령을 작성하는데 제약조건은 테이블 레벨로 등록하는 것으로 한다.
CREATE TABLE emp2(
    empno NUMBER(4),
    ename VARCHAR2(10)
        CONSTRAINT EMP2_NAME_NN NOT NULL,
    job VARCHAR2(9)
        CONSTRAINT EMP2_JOB_NN NOT NULL,
    mgr NUMBER(4),
    hiredate DATE
        CONSTRAINT EMP2_HDATE_NN NOT NULL,
    sal NUMBER(7,2)
        CONSTRAINT EMP2_SAL_NN NOT NULL,
    comm NUMBER(7,2),
    deptno NUMBER(2),
    CONSTRAINT EMP2_NO_PK PRIMARY KEY(empno),
    CONSTRAINT EMP2_DNO_FK FOREIGN KEY(deptno) REFERENCES dept(deptno)--,
--    CONSTRAINT EMP2_JOB_NN NOT NULL(job)
);


-- EMP3 테이블 생성
CREATE TABLE emp3(
    empno NUMBER(4),
    ename VARCHAR2(10),
    job VARCHAR2(9),
    mgr NUMBER(4),
    hiredate DATE,
    sal NUMBER(7,2),
    comm NUMBER(7,2),
    deptno NUMBER(2)
);

-- EMP3에 제약조건 등록
-- 기본키
ALTER TABLE emp3
ADD CONSTRAINT EMP3_NO_PK PRIMARY KEY(empno);
-- 참조키
ALTER TABLE emp3
ADD CONSTRAINT EMP3_DNO_FK FOREIGN KEY(deptno) REFERENCES dept(deptno);

-- NOT NULL
ALTER TABLE emp3
MODIFY ename
    CONSTRAINT EMP3_NAME_NN NOT NULL;

-- JOB
ALTER TABLE emp3
MODIFY job
    CONSTRAINT EMP3_JOB_NN NOT NULL;

-- HIREDATE
ALTER TABLE emp3
MODIFY hiredate
    CONSTRAINT EMP3_HDATE_NN NOT NULL;
    
-- SAL
ALTER TABLE emp3
MODIFY sal
    CONSTRAINT EMP3_SAL_NN NOT NULL;
    
-- deptno
ALTER TABLE emp3
MODIFY deptno
    CONSTRAINT EMP3_DNO_NN NOT NULL;

-- hiredate 에 기본값 sysdate 추가하기
ALTER TABLE emp3
MODIFY hiredate DEFAULT sysdate;

ALTER TABLE emp3
MODIFY hiredate DEFAULT (null);


-- EMP3에 등록된 제약조건 확인
SELECT
    *
FROM
    USER_CONSTRAINTS
WHERE
    TABLE_NAME = 'EMP3'
;

--------------------------------------------------------------------------------
/*
    뷰(View)
    ==> 조회 질의명령의 결과를 기억하는 가상의 테이블
        쉽게 말해서 질의명령의 결과를 볼 수 있는 "창" 이라고 생각하면 된다.
        물리적으로 테이블이 만들어져 있지는 않고
        물리적으로 생성되어있는 테이블의 일부분만 볼 수 있다.
        
    ==> 자주 사용되는 복잡한 질의 명령을 별도로 저장해 놓고
        이 질의 명령의 결과를 손쉽게 처리할 수 있도록 하는 것.
        
        예 ]
            부서별 집계를 해놓은 테이블은 만드는 것이 무의미하고
            만들어도 부서원의 정보가 수정이 되면 같이 수정되어야하는 번거로움이 있다.
            
            만약 부서원의 정보가 수정되면 집계내용도 반영해주는 테이블이 있다면 편할 것이다.
            
            이 기능을 할 수 있는 것이 View 다.
            
    뷰의 종류 ]
        1. 단순뷰
            ==> 하나의 테이블만 이용해서 만들어진 뷰
                DML 명령이 모두 사용가능하다.
                (INSERT, UPDATE, DELETE)
                
                단, 연산식이 조회되거나 그룹함수를 이용한 경우는 단순뷰가 아니다.
                
        2. 복합뷰
            ==> 두 개 이상의 테이블을 이용해서(조인해서) 만들어진 뷰
                DML 명령이 불가능하다.
                ==> 그냥 보기한 해라.
                    따라서 조회 질의명령만 사용가능하다.
                    
    뷰(VIEW) 만드는 방법
        참고 ]
            뷰를 만드는 명령은 뷰를 만들수 있는 권한이 부여되어있어야 가능하다.
            기본적으로 계정을 만들면 이 권한은 부여되어있지 않다.
            따라서 뷰를 만들어서 사용하려면 
            뷰를 만들 수 있는 권한을 부여 받아야 한다.
            
            권한 이름 ]
                CREATE VIEW
                
            따라서 관리자 계정에서 이 권한을 부여해줘야 뷰를 만들 수 있게 된다.
            
            --------------------------------------------------------------------
            -- SYSTEM 계정에서 작업
            
            GRANT create view TO scott;
            --------------------------------------------------------------------
        
        
        형식 1 ] - 일반적인 뷰 만드는 방법
            CREATE VIEW  뷰이름
            AS
                조회 질의 명령
            ;
            
        형식 2 ]
            CREATE VIEW 뷰이름
            AS
                조회 질의명령
            WITH CHECK OPTION
            ;
            
            ==> 단순 뷰의 경우 DML 명령 사용가능하다.
                이때 변경된 데이터는 결과적으로 
                뷰에서 조회하는 테이블의 데이터를 수정하게 된다.
                이때 경우에 따라서 그 데이터를 사용할 수 없게 될 수 있다.
                뷰의 존재의 의미가 사라질 수 있다.
                
                예 ]
                    -- 20 번 부서원의 사원번호, 사원이름, 급여, 커미션, 부서번호를 조회하는 뷰
                    CREATE VIEW sel20
                    AS
                        SELECT
                            empno, ename, sal, comm, deptno
                        FROM
                            emp
                        WHERE
                            deptno = 20
                    ;
            
            
            
            
        형식 3 ]
            CREATE VIEW 뷰이름
            AS
                조회 질의명령
            WITH READ ONLY
            ;
        
--------------------------------------------------------------------------------
참고 ]
    뷰는 이미 만들어져 있는 경우
    다시 같은 이름으로 수정해서 만들 수 있다.
    
    형식 ]
        CREATE OR REPLACE VIEW 뷰이름 
        --  뷰를 만드는데 이미 있는 뷰라면 다시 대체하세요..
        AS
             질의명령
        [WITH CHECK OPTION | WITH READ ONLY]
        ;
        
참고 ]
    뷰는 뷰를 만들 테이블이 존재해야 뷰를 만들 수 있다.
    테이블이 존재하지 않아도 (아직 만들어 지지 않았어도) 
    만들 수 있다.
    
    형식 ]
        CREATE OR REPLACE FORCE VIEW 뷰이름
        AS
            질의명령
        [ WITH CHECK OPTION | WITH READ ONLY ]
        ;
        
--------------------------------------------------------------------------------
복합뷰
==> 복합뷰는 단순뷰와 동일한 방식으로 만들면 된다.
    단, 두개 이상의 테이블을 이용한 조인을 사용해서 만들어야 한다.


--------------------------------------------------------------------------------
View 삭제
    형식 ]
        DROP VIEW  뷰이름;


--------------------------------------------------------------------------------
뷰 조회 방법
    형식 ]
        SELECT
            *
        FROM
            user_views
        ;
        

--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
시퀀스(SEQUENCE)
==> 테이블을 생성할 때 각 행들을 구분해 줄 수 있는 기본키(PK)는 거의 
    필수적으로 존재해야 한다.
    
    예를 들면
        사원을 관리하는 테이블을 만들면
        각각의 사원을 구분할 수 있는 무엇인가가 있어야하고
        따라서 우리가 가지고 있는 EMP 테이블에는
        사원번호가 그 기능을 담당하고 있다./
        
    몇몇 테이블은 이것을 명확하게 구분하여 처리할 수 있지만
    그렇지 못한 테이블도 존재한다.
    
    예를 들면
        게시글을 관리하는 테이블을 만들면
        제목, 내용, 작성자, 작성일, ... 이 있는데
        이중에 명확하게 각 데이터를 구분할 수 있는 역할을 하는 컬럼이
        보이지 않는다.
    이런 경우는 대부분 일련번호를 이용해서 이 역할을 하도록 하고 있다.
    
    따라서 일련번호는 절대로 중복되어서는 안되고
    절대로 생략 되어서도 안된다.
    
    시퀀스는 이런 문제점을 해결하기 위해 생겨난 기능으로
    자동적으로 일련번호를 발생시켜 주기 위한 도구이다.
    
    방법 ]
        1. 시퀀스를 만든다.
        2. 데이터베이스에 일련번호의 입력이 필요하면 만들어 놓은
            시퀀스에게 일련번호를 만들어달라고 요청한다.
            ==> 즉, 데이터를 INSERT 시킬때 일련번호 부분은
                입력자가 입력하는 것이 아니고
                시퀀스에게 일임한다.
                
    시퀀스 생성방법 ]
        CREATE SEQUENCE 시퀀스이름
            START WITH  번호
            ==> 발생시킬 일련번호의 시작번호를 지정
                생략하게 되면 1부터 시작
                
            INCREMENT BY 숫자
            ==> 발생시킬 일련번호의 증가값을 지정
                생략하면 1씩 증가
            
            MAXVALUE    숫자 [ 또는 NOMAXVALUE ]
            MINVALUE    숫자 [ 또는 NOMINVALUE ]
            ==> 발생시킬 일련번호의 최대값, 최소값을 지정
                생략하면 NO를 사용하게 된다.
            
            CYCLE   [ 또는 NOCYCLE ]
            ==> 발생시킬 일련번호가 최대값에 도달하면 
                다시 처음부터 시작할 지 여부를 지정
                생략하면 NOCYCLE 을 사용한다.
                
            CACHE   [ 또는 NOCACHE ]
            ==> 일련번호 발생시 임시 메모리를 사용할 지 여부를 지정
                사용하면 속도는 빨라지지만 메모리 사용이 늘고
                사용하지 않으면 느려지지만 메모리가 줄지 않는다.
                
                기본값은 10개를 사용하게 된다.
        ;

--------------------------------------------------------------------------------
시퀀스 사용 방법
==> 데이터를 입력할 때 자동으로 일련번호를 발생시키기 위해서 만든것이 시퀀스
    
    따라서 주로  INSERT 명령에서 사용하며
        시퀀스이름.NEXTVAL
    로 사용하게 된다.
    
    이제 NEXTVAL을 호출하면 무조건 다음 번호를 만들게 된다.
    
    참고 ]
        currval : 세션이 열린후(데이터베이스에 접속한 후) nextval이 생성한 마지막 번호를 
                    기억하는 변수(???)
    참고 ]
        시퀀스의 문제점
            ==> 시퀀스는 테이블에 독립적이다.
                즉, 한번 만든 시퀀스는 여러 테이블에서 사용할 수 있다.
                이때 어떤 테이블에서 시퀀스를 사용하던지
                항상 다음 번호를 만들게 된다.
                따라서 일련번호에 누락된 번호가 발생하게 된다.
                
                그리고
                INSERT 명령에서 사용할 때
                해당 명령이 오류가 발생하면
                발생한 시점에 만들어진 번호는 다시는 사용할 수 없게된다.
        
        
    참고 ]
        시퀀스 수정하는 방법
            형식 ]
                ALTER SEQUENCE 시퀀스이름
                    INCREMENT BY 숫자
                    MAXVALUE    숫자 [ 또는 NOMAXVALUE ]
                    MINVALUE    숫자 [ 또는 NOMINVALUE ]
                    CYCLE   [ 또는 NOCYCLE ]
                    CACHE 숫자 [ 또는 NOCACHE ]
                ;
                
                참고 ]
                    시퀀스를 수정할 때 
                    시작 번호는 수정할 수 없다.
                    이미 발생한 번호가 있기 때문이다.
                    시작번호는 전에 만들어 놓은 번호가 자동 시작번호가 된다.
                    
        참고 ]
            시퀀스 삭제
                형식 ]
                    DROP SEQUENCE 시퀀스이름;
            
*/

-- 20번 부서원들의 사원번호, 사원이름, 급여, 커미션, 부서번호를 조회하는 뷰를 작성하세요.
CREATE VIEW sel20
AS
    SELECT
        empno, ename, sal, comm, deptno
    FROM
        temp1
    WHERE
        deptno = 20
;

-- 뷰를 이용해서 조회
SELECT
    empno, ename, deptno
FROM
    sel20
;

-- SMITH 사원의 부서번호를 10번으로 변경하세요
UPDATE
    sel20
SET
    deptno = 10
WHERE
    ename = 'SMITH'
;

-- view 조회
SELECT
    *
FROM
    sel20
;

SELECT
    ename, deptno
FROM
    temp1
WHERE
    ename = 'SMITH'
;


-- sel20 의 모든 사원의 부서번호를 10번으로 수정
UPDATE
    sel20
SET
    deptno = 10
;

SELECT
    *
FROM
    sel20
;

rollback;

-- 부서번호가 20번인 사원들의 사원번호, 사원이름, 급여, 부서번호를 조회하는 뷰를
-- 제작하는데 부서번호는 수정할 수 없도록 하세요.
CREATE VIEW sel20ck
AS
    SELECT
        empno eno, ename name, sal, deptno dno 
        -- 별칭으로 뷰를 만들면 별칭만 사용해야 한다.
    FROM
        temp1
    WHERE
        deptno = 20
WITH CHECK OPTION;

-- sel20ck view 조회
SELECT
    *
FROM
    sel20ck
;

-- SMITH 사원의 부서번호를 10번으로 수정
UPDATE
    sel20ck
SET
    dno = 10
WHERE
    name = 'SMITH'
;

UPDATE
    sel20ck
SET
    name = 'smith'
WHERE
    name = 'SMITH'
;

-- 되돌리기
rollback;

-- 읽기 전용 뷰 만들기
CREATE VIEW sel20ro
AS
    SELECT
        empno eno, ename name, sal, deptno dno
    FROM
        temp1
    WHERE
       deptno = 20 
WITH READ ONLY;

-- 데이터 조회
SELECT
    *
FROM
    sel20ro
;

-- 사원들의 급여를 500 더해서 수정하세요.
UPDATE
    sel20ro
SET
    sal = sal + 500
;

-- temp4 테이블을 이용해서 부서번호가 10인 사원들의
--      사원번호, 사원이름, 급여, 부서번호를 조회하는 뷰를 제작하세요.

CREATE OR REPLACE FORCE VIEW sel10ck
AS
    SELECT
        empno eno, ename name, sal, deptno dno
    FROM
        temp4
    WHERE
        deptno = 10
WITH CHECK OPTION
;

-- 복합뷰
-- 사원들의 사원번호, 사원이름, 상사이름, 직급, 급여, 부서이름, 급여등급 을 조회하는 뷰를 만드세요.
CREATE OR REPLACE VIEW selEInfo
AS
    SELECT
    
    FROM
    
    WHERE
        e.deptno = 
;


/*
    문제 1 ]
        부서 정보 테이블을(DEPT1), 급여 등급테이블(SALGRADE1)을 제약조건 없이 만들고
        제약조건을 추가하세요.
*/
CREATE TABLE dept1(
    deptno NUMBER(2),
    dname VARCHAR2(14),
    loc VARCHAR2(13)
);
-- 제약 조건 추가
ALTER TABLE dept1
ADD CONSTRAINT DEPT1_NO_PK PRIMARY KEY(deptno);

-- not null 추가
ALTER TABLE dept1
MODIFY dname
    CONSTRAINT DEPT1_DNAME_NN NOT NULL;

ALTER TABLE dept1
MODIFY loc
    CONSTRAINT DEPT1_LOC_NN NOT NULL;


CREATE TABLE salgrade1(
    grade NUMBER,
    losal NUMBER,
    hisal NUMBER
);

ALTER TABLE salgrade1
ADD CONSTRAINT SGRD1_GRADE_PK PRIMARY KEY(grade);

ALTER TABLE salgrade1
ADD CONSTRAINT SGRD1_LSAL_UK UNIQUE(losal);

ALTER TABLE salgrade1
ADD CONSTRAINT SGRD1_HSAL_UK UNIQUE(hisal);

ALTER TABLE salgrade1
MODIFY losal
    CONSTRAINT SGRD1_LSAL_NN NOT NULL;

ALTER TABLE salgrade1
MODIFY hisal
    CONSTRAINT SGRD1_HSAL_NN NOT NULL;
    
-- dept 테이블의 데이터를  dept1에 복사하세요.
INSERT INTO
    dept1
    SELECT
        *
    FROM
        dept
;
-- salgrade 테이블의 데이터를 salgrade1에 복사하세요.
INSERT INTO
    salgrade1
    SELECT
        *
    FROM
        salgrade
;

commit;

/*
    문제 2 ]
        부서별 부서번호, 급여합계, 급여평균, 최소급여, 최고급여, 부서원수
        를 조회할 뷰(AGGRDNO)를 만들고
        사원들의 사원번호, 사원이름, 직급, 입사일, 
            부서급여평균, 부서최소급여, 부서최고급여, 부서급여합계, 부서원수,
            부서이름, 급여등급
        을 조회하세요.
*/

CREATE OR REPLACE VIEW aggrdno
AS
    SELECT
        deptno dno, SUM(sal) sum, AVG(sal) avg, MIN(sal) min, MAX(sal) max, COUNT(*) cnt
    FROM
        temp1
    GROUP BY
        deptno
;

SELECT
    empno 사원번호, ename 사원이름, job 직급, hiredate 입사일, 
    TRUNC(avg, 2) 부서급여평균, min 부서최소급여, max 부서최고급여, 
    sum 부서급여합계, cnt 부서원수, dname 부서이름, grade 급여등급
FROM
    emp e, dept d, salgrade, aggrdno
WHERE
    -- 조인조건
    e.deptno = d.deptno
    AND sal BETWEEN losal AND hisal
    AND e.deptno = dno
;


/*
    문제 3 ]
        문제 2 ]에서 제작한 뷰를 이용해서
        부서 최소 급여를 받는 사원들의
            사원이름, 직급, 상사이름, 입사일, 급여, 부서급여합계, 부서최소급여, 부서원수
            부서이름, 부서위치, 급여등급
        을 조회하세요.
*/

SELECT
    e.ename 사원이름, e.job 직급, s.ename 상사이름, e.hiredate 입사일, e.sal 급여, 
    sum 부서급여합계, min 부서최소급여, cnt 부서원수,
    dname 부서이름, loc 부서위치, grade 급여등급
FROM
    temp1 e, temp1 s, dept d, salgrade, aggrdno
WHERE
    e.mgr = s.empno(+)
    AND e.deptno = d.deptno
    AND e.sal BETWEEN losal AND hisal
    AND e.deptno = dno
    AND e.sal = min
;

-- sel10ck 뷰를 삭제하세요
DROP VIEW sel10ck;

select * from user_views;

--------------------------------------------------------------------------------
/*
    1부터 5까지 일련번호를 만들어주는 시퀀스(SEQ01)을 만드세요.
*/
drop sequence seq01;
CREATE SEQUENCE seq01
    MAXVALUE 5
    MINVALUE 2
    CYCLE
    NOCACHE
;

-- 번호만 기억하는 RECNO 테이블을 만드세요
CREATE TABLE recno(
    no NUMBER(1)
);

-- 데이터 추가
INSERT INTO
    recno
VALUES(
    seq01.nextval
);

drop sequence seq01;
CREATE SEQUENCE seq01
    MAXVALUE 5
    MINVALUE 2
    CYCLE
    NOCACHE
;

-- 데이터 추가
INSERT INTO
    recno
VALUES(
    seq01.nextval
);

SELECT seq01.nextval FROM dual;

SELECT seq01.currval FROM dual;












