/*
############# quiz 1
    1. system/increpas
        ALTER, ACCOUNT UNLOCK
        
    2. exit
    
    3. GRANT 
        select table, update table, delete table 
    ON scott.emp 
    TO increpas
    
    4. REVOKE select any table FROM Increpas
    
    5. role(롤)
    
    6. 
        1. CREATE ROLE myrole;
        2. GRANT SELECT TABLE, UPDATE TABLE, INSERT TABLE 
           ON scott.salgrade
           TO MYROLE
        3. GRANT myrole TO increpas
        
    7. CREATE USER increpas IDENTIFIED BY increpas;
        GRANT CREATE SESSION TO increpas
        
    8. CREATE UNIQUE INDEX idx ON shop(bdate, bpoint)
    
    9. 
        CREATE TABLE employee
        AS
            SELECT
                *
            FROM
                scott.emp
            ;
            
    10.
        SELECT tname FROM tab;
*/

-- cursor
-- 부서 번호를 알려주면 부서별로 부서이름, 평균급여, 사원수를 출력하라. 
-- 단, 질의명령을 커서를 이용해서 처리하세요.
set serveroutput on;
CREATE OR REPLACE PROCEDURE dnoAggr1
    (dno IN emp.deptno%TYPE)
IS
    CURSOR deptInfo IS
        SELECT
            d.dname, AVG(sal), COUNT(*)
        FROM
            emp e, dept d
        WHERE
            e.deptno = d.deptno
            AND e.deptno = dno
        GROUP BY
            d.dname
        ;
    
    d_dname dept.dname%TYPE;
    d_avg   NUMBER;
    d_count NUMBER;
BEGIN
    DBMS_OUTPUT.ENABLE;
    
    -- 커서오픈
    OPEN deptInfo;
    
    FETCH deptInfo INTO d_dname, d_avg, d_count;
    
    DBMS_OUTPUT.PUT_LINE('부서이름 : ' || d_dname);
    DBMS_OUTPUT.PUT_LINE('부서평균 : ' || d_avg);
    DBMS_OUTPUT.PUT_LINE('부서원수 : ' || d_count);
    
    CLOSE deptInfo;
END;
/

execute dnoAggr1(10);
execute dnoAggr1(30);

-- 부서별로 부서이름, 평균급여, 사원수를 출력하라.

CREATE OR REPLACE PROCEDURE dnoInfo2
IS
    CURSOR dept_info IS
        SELECT
            dname, AVG(sal) avg, COUNT(*) cnt
        FROM
            emp e, dept d
        WHERE
            e.deptno = d.deptno
        GROUP BY
            d.dname
    ;
    
BEGIN
    DBMS_OUTPUT.ENABLE;
    FOR dinfo IN dept_info LOOP
        DBMS_OUTPUT.PUT_LINE('부서이름 : ' || dinfo.dname);
        DBMS_OUTPUT.PUT_LINE('부서평균 : ' || dinfo.avg);
        DBMS_OUTPUT.PUT_LINE('부서원수 : ' || dinfo.cnt);
        DBMS_OUTPUT.PUT_LINE('----------------------------');
    END LOOP;
END;
/

exec dnoInfo2;


-- 사원의 이름, 직책, 급여를 출력하라.
-- 단, 최종적으로 출력된 사원의 수를 같이 출력하라.

CREATE OR REPLACE PROCEDURE empInfo1
IS
    CURSOR emp_list IS
        SELECT
            ename, job, sal
        FROM
            emp
    ;
    
    e_ename     emp.ename%TYPE;
    e_job       emp.job%TYPE;
    e_sal       emp.sal%TYPE;
BEGIN
    DBMS_OUTPUT.ENABLE;
    OPEN emp_list;
    
    LOOP
        FETCH emp_list INTO e_ename, e_job, e_sal;
        DBMS_OUTPUT.PUT_LINE('사원이름 : ' || e_ename);
        DBMS_OUTPUT.PUT_LINE('사원직급 : ' || e_job);
        DBMS_OUTPUT.PUT_LINE('사원급여 : ' || e_sal);
        DBMS_OUTPUT.PUT_LINE(RPAD('-', 30, '-'));
        
        -- 반복 탈출 명령
        EXIT WHEN emp_list%NOTFOUND;
    END LOOP;
    
    DBMS_OUTPUT.PUT_LINE('총 사원수 : ' || emp_list%ROWCOUNT);
    
    CLOSE emp_list;
END;
/

exec empInfo1;


-- 부서번호를 알려주면 해당 부서의 직원 이름을  출력하는 프로시저를 만드세요.
CREATE OR REPLACE PROCEDURE dno_name_list
IS
    CURSOR emp_list(p_dno   emp.deptno%TYPE) IS
        SELECT
            ename
        FROM
            emp
        WHERE
            deptno = p_dno
    ;
BEGIN
    DBMS_OUTPUT.ENABLE;
    
    FOR no IN 1 .. 3 LOOP
        DBMS_OUTPUT.PUT_LINE('--- ' || (no * 10) || ' 번 부서 ---');
        FOR d IN emp_list(no * 10) LOOP
            DBMS_OUTPUT.PUT_LINE(d.ename);
        END LOOP;
    END LOOP;
    /*
    DBMS_OUTPUT.PUT_LINE('--- 10 번 부서 ---');
    FOR d IN emp_list(10) LOOP
        DBMS_OUTPUT.PUT_LINE(d.ename);
    END LOOP;
    
    DBMS_OUTPUT.PUT_LINE('--- 20 번 부서 ---');
    FOR d IN emp_list(20) LOOP
        DBMS_OUTPUT.PUT_LINE(d.ename);
    END LOOP;
    
    DBMS_OUTPUT.PUT_LINE('--- 30 번 부서 ---');
    FOR d IN emp_list(30) LOOP
        DBMS_OUTPUT.PUT_LINE(d.ename);
    END LOOP;
    */
END;
/

exec dno_name_list;

-- where current of
-- 사원번호를 알려주고 직급을 알려주면
-- 해당 사원의 직급을 지정한 직급으로 변경하는 프로시저로 만드세요.

CREATE OR REPLACE PROCEDURE editJob1
    (v_eno IN emp.empno%TYPE, v_job IN emp.job%TYPE)
IS
    CURSOR emp_info IS
        SELECT
            empno
        FROM
            test00
        WHERE
            empno = v_eno
    FOR UPDATE;
    
BEGIN
    FOR ei IN emp_info LOOP
        UPDATE
            test00
        SET
            job = v_job
        WHERE CURRENT OF emp_info;
    END LOOP;
END;
/

exec editJob1(7369, 'KING');
rollback;

-- 예외의 종류 : https://goddaehee.tistory.com/265

-- 부서 번호를 알려주면 해당 부서의 직원정보를 출력하도록 한다. 
-- 단, 문제가 발생하면 예외처리를 이용해서 문제의 원인을 출력해보자

CREATE OR REPLACE PROCEDURE sawonInfo
    (v_dno IN emp.deptno%TYPE)
IS
    temp emp%ROWTYPE;
BEGIN
    DBMS_OUTPUT.ENABLE;
    -- 예외가 발생하도록 한행만 출력해보자.
    SELECT
        *
    INTO
        temp
    FROM
        emp
    WHERE
        deptno = v_dno
    ;
    
    DBMS_OUTPUT.PUT_LINE(temp.ename || ' | ' || temp.job || ' | ' || temp.sal || ' |');
EXCEPTION
    WHEN TOO_MANY_ROWS THEN
        DBMS_OUTPUT.PUT_LINE('다중행이 조회되었습니다.');
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('조회된 결과가 없습니다.');
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('원인을 알 수 없는 오류입니다.');
END;
/

EXEC sawonInfo('십번');

ALTER TABLE test00
ADD CONSTRAINT T00_NO_PK PRIMARY KEY(empno);

/*
    test00 테이블에 새로운 사원을 입력하는 프로시저를 만들어보자 
    단, 사원이름과 부서번호만 입력하도록 한다. 
    ==> 그러면 사원번호가 입력되지 않아서 에러가 발생한다. 
    이 예외는 정의 되지 않은 예외이다.
*/

CREATE OR REPLACE PROCEDURE addEmp
    (name IN test00.ename%TYPE, dno IN test00.deptno%TYPE)
IS
    -- 예외 이름
    PK_TEST EXCEPTION;
    -- 예외이름과 예외코드 연결
    PRAGMA EXCEPTION_INIT(PK_TEST, -1400); -- ora-01400
BEGIN
    DBMS_OUTPUT.ENABLE;
    
    INSERT INTO test00(ename, deptno) VALUES(name, dno);
EXCEPTION
    WHEN PK_TEST THEN
        DBMS_OUTPUT.PUT_LINE('사원번호는 필수 입니다.');
END;
/

exec addEmp('chopa', 30);

------------------------------------------------------------------------------------------------------
/*
    부서 번호를 알려주면 해당 부서에 속한 사원수를 
    알려주는 프로시저를 만드세요.
    단, 사원수가 3명 이하면 사원수가 부족하다는 메시지를 
    예외처리를 이용해서 하세요
*/

CREATE OR REPLACE PROCEDURE dnoCnt
    (dno IN test00.deptno%TYPE)
IS
    -- 예외이름을 정한다.
    cnt_error   EXCEPTION;
    
    cnt NUMBER;
BEGIN
    DBMS_OUTPUT.ENABLE;
    
    SELECT
        COUNT(empno)
    INTO
        cnt
    FROM
        test00
    WHERE
        deptno = dno
    ;
    
    IF cnt <= 3 THEN
        RAISE cnt_error;
    END IF;
    
    -- PRINT
    DBMS_OUTPUT.PUT_LINE(dno || ' 번 부서원 수 : ' || cnt);
EXCEPTION WHEN cnt_error THEN
    DBMS_OUTPUT.PUT_LINE('*** 사원수가 부족한 부서입니다. ***');
END;
/

exec dnoCnt(10);
exec dnoCnt(20);
exec dnoCnt(30);
-- select count(distinct deptno) from test00;



-------------------------------------------------------------------------------------------------------
create table chingu(
    cno number(4),
    name varchar2(10 char),
    tel varchar2(13 char),
    mail varchar2(20 char)
);

alter table chingu
drop column cno;

alter table chingu
modify name 
    CONSTRAINT CHINGU_NAME_NN NOT NULL;
    
select
    COUNT(mgr) 부하직원들
from
    test00
;

--------------------------------------------------------------------------------

CREATE TABLE member(
    no NUMBER(4)
        CONSTRAINT M_NO_PK PRIMARY KEY,
    name VARCHAR2(6 CHAR)
        CONSTRAINT M_NAME_NN NOT NULL,
    id  VARCHAR2(8 CHAR)
        CONSTRAINT M_ID_UK UNIQUE
        CONSTRAINT M_ID_NN NOT NULL,
    pw VARCHAR2(8 CHAR)
        CONSTRAINT M_PW_NN NOT NULL,
    isshow CHAR(1) DEFAULT 'Y'
        CONSTRAINT M_SHOW_CK CHECK (isshow IN ('Y', 'N'))
        CONSTRAINT M_SHOW_NN NOT NULL
);

-- 2.
ALTER TABLE board
MODIFY body
    CONSTRAINT BRD_BODY_NN NOT NULL;
    
-- 3.
SELECT
    DISTINCT deptno 부서번호
FROM
    scott.emp
;

-- 4.
SELECT
    empno 사원번호, ename 사원이름, comm 이전커미션, NVL(comm + 100, 50) 지급커미션
FROM
    emp
;

-- 5.
SELECT
    empno 사원번호, RPAD(SUBSTR(ename, 1, 2), LENGTH(ename), '*') 사원이름, job 직급, 
    FLOOR(
        MONTHS_BETWEEN(sysdate, hiredate)
    )"근무개월 수"
FROM
    emp
;

-- 6.
SELECT
    COUNT(comm) "comm 받는 사람"
FROM
    emp
;

SELECT
    COUNT(*) "comm 받는 사람"
FROM
    emp
WHERE
    comm IS NOT NULL
;

-- 7.
SELECT
    empno 사원번호, ename 사원이름, sal 급여, 
    (max - sal) "max minus sal", max 부서최대급여, TRUNC(avg, 2) 부서평균급여
FROM
    emp,
    (
        SELECT
            deptno dno, MAX(sal) max, AVG(sal) avg
        FROM
            emp
        GROUP BY
            deptno
    )
WHERE
    deptno = dno
;

SELECT
    empno 사원번호, ename 사원이름, sal 급여, 
    (max - sal) "max minus sal", max 부서최대급여, TRUNC(avg, 2) 부서평균급여
FROM
    emp e,
    (
        SELECT
            deptno dno, MAX(sal) max, AVG(sal) avg
        FROM
            emp
        GROUP BY
            deptno
        HAVING
            deptno = e.deptno --- X
    )
;

-- 8.
SELECT
    empno 사원번호, ename 사원이름, grade 급여등급, dname 부서이름, loc 부서위치
FROM
    emp e, dept d, salgrade
WHERE
    e.deptno = d.deptno
    AND sal BETWEEN losal AND hisal
;

-- 9.
CREATE OR REPLACE VIEW emp_dept
AS
    SELECT
        empno, ename, e.deptno, dname
    FROM
        emp e, dept d
    WHERE
        e.deptno = d.deptno
;


-- 10.
CREATE SEQUENCE memb_seq
    START WITH 1000
    INCREMENT BY 1
    NOCACHE
    NOCYCLE
;

--------------------------------------------------------------------------------
-- temp, temp01 테이블 생성

CREATE TABLE temp
AS
    SELECT
        *
    FROM
        emp
;

CREATE TABLE temp01
AS
    SELECT
        *
    FROM
        emp
    WHERE
        1 = 2
;

-- 테이블 준비
CREATE TABLE memb(
    id VARCHAR2(20 CHAR),
    pw VARCHAR2(10 CHAR)
);

CREATE TABLE grade(
    id  VARCHAR2(20 CHAR),
    grade VARCHAR2(20 CHAR)
);

-- 트리거 작성
CREATE OR REPLACE TRIGGER MEMB_TRIGGER
    AFTER INSERT ON MEMB
FOR EACH ROW
BEGIN
    INSERT INTO
        grade
    VALUES(
        :NEW.id, '새내기'
    );
    
END;
/

-- chopa 추가
INSERT INTO
    memb
VALUES(
    'CHOPA', '12345'
);

INSERT INTO
    memb
VALUES(
    'SANJI', '12345'
);

INSERT INTO
    memb
VALUES(
    'LUFFY', '12345'
);

INSERT INTO
    memb
VALUES(
    'ZORO', '12345'
);

INSERT INTO
    memb
VALUES(
    'HANKOK', '12345'
);

INSERT INTO
    memb
VALUES(
    'NAMI', '12345'
);

CREATE OR REPLACE TRIGGER modm
    BEFORE INSERT OR UPDATE OR DELETE ON memb
FOR EACH ROW
BEGIN
    DBMS_OUTPUT.ENABLE;
    IF INSERTING THEN
        DBMS_OUTPUT.PUT_LINE('INSERT 작업 전');
    ELSIF DELETING THEN
        DBMS_OUTPUT.PUT_LINE('DELETE 작업 전');
    ELSIF UPDATING THEN
        DBMS_OUTPUT.PUT_LINE('UPDATE 작업 전');
    END IF;
END;
/


INSERT INTO
    memb
VALUES(
    'WOOSOP', '12345'
);

rollback;

UPDATE
    memb
SET
    id = 'BOA ' || id
WHERE
    id = 'HANKOK'
;

DELETE FROM MEMB WHERE ID = 'WOOSOP';
COMMIT;

DELETE FROM MEMB;

ROLLBACK;


CREATE OR REPLACE TRIGGER modm
    BEFORE INSERT OR UPDATE OR DELETE ON memb
--FOR EACH ROW
BEGIN
    DBMS_OUTPUT.ENABLE;
    IF INSERTING THEN
        DBMS_OUTPUT.PUT_LINE('INSERT 작업 전');
    ELSIF DELETING THEN
        DBMS_OUTPUT.PUT_LINE('DELETE 작업 전');
    ELSIF UPDATING THEN
        DBMS_OUTPUT.PUT_LINE('UPDATE 작업 전');
    END IF;
END;
/

DELETE FROM MEMB;

ROLLBACK;

-- 사원이 퇴사하면 
-- 퇴사한 사원의 정보를 TEMP01에 벡업하는 트리거(BACKUP_TEMP)를 작성하고( TEMP --> TEMP01 )
-- 어떤 사원이 언제 퇴사했는지를 출력해주는 기능도 추가하세요.

CREATE OR REPLACE TRIGGER backup_temp
    BEFORE DELETE ON temp
FOR EACH ROW
BEGIN
    DBMS_OUTPUT.ENABLE;
    
    INSERT INTO
        temp01
    VALUES(
        :old.empno, :old.ename, :old.job, :old.mgr, 
        :old.hiredate, :old.sal, :old.comm, :old.deptno
    );
    
    DBMS_OUTPUT.PUT_LINE(:OLD.ename || ' 사원이 ' || TO_CHAR(sysdate, 'YYYY"년" MM"월" DD"일"') || ' 퇴사했습니다.');
END;
/

delete from temp where empno = 7839;

rollback;
