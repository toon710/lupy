/*
    SQL(STRUCTURED QUERY LANGUAGE)
    ==> 구조화된 쿼리 언어 라는 의미
        데이터베이스에 질의명령을 보낼때 사용하는 언어
        
        DDL(Data Definition Language) - 데이터베이스에 개체를 만들고 수정하는 명령
        ==> 데이터 정의 언어
            CREATE, ALTER, DROP, TRUNCATE,..
        
        DML(Data Manipulation Language)
        ==> 데이터 조작 언어
            
            CRUD - 데이터를 조작하는 방법
            
            약자      의미          명령
            C   -   CREATE      -   INSERT
            R   -   READ        -   SELECT
            U   -   UPDAE       -   UPDATE
            D   -   DELETE      -   DELETE
            
        ==> DBMS에게 할당받은 메모리(세션, SESSION)에서 작업이 이루어진다.
            따라서 데이터베이스에 적용을 시킬려면 트랜젝션 처리 명령(commit)으로 적용시켜줘야 한다.
            
        DCL(Data Control Language)
        ==> 데이터 제어 언어
            
            TCL(Transaction Control Language)
            ==> 트랜젝션 제어 언어
                commit, rollback, savepoint,..
                
            권한관련 명령
            ==>
                GRANT, REVOKE,...
        
------------------------------------------------------------------------------------------------------

    현재 계정(user)이 가지고 있는 테이블의 간략한 정보를 조회하는 방법
        
        DESCRIBE 테이블이름;
        DESC    테이블이름;
        
    현재 계정이 소유한 모든 테이블의 간략한 정보를 조회하는 방법
        
        SELECT * FROM tab;
        
        참고 ]
            tab 테이블 : 해당계정이 소유한 테이블들의 간략한 정보를 기억하는 테이블
      참고 ]
        sqlplus 명령은 세션이 종료되면 초기화 된다.
        
--------------------------------------------------------------------------------------------------------

    중복된 조회 데이터 한번만 조회되게 하는 명령
        DISTINCT
        
        참고 ]
            여러개의 컬럼을 나열해서 조회하는 경우는
            여러개의 컬럼의 데이터가 모두 동일한 행만 한번만 조회하게 된다.

*/

-- 사원들의 부서번호를 조회하세요.
SELECT
    deptno
FROM
    emp
;

-- 사원들의 부서번호를 조회하세요. 단, 중복된 부서는 한번만 조회되게 하세요.
SELECT
    DISTINCT deptno
FROM
    emp
;

-- 사원들의 사원이름, 부서번호를 조회하세요.
SELECT
    DISTINCT ename, deptno
FROM
    emp
;
-- ==> 사원이름과 부서번호가 동일한 사원은 존재하지 않으므로 모든 사원의 정보를 조회하게 된다.

/*
    데이터 조회 질의명령
        형식 1 ]
            SELECT
                [ DISTINCT ] 컬럼이름1, 컬럼이름2, ...
            FROM
                테이블이름
            ;
            
        형식 2 ]
            SELECT
                [ DISTINCT ] 컬럼이름, 컬럼이름, ...
            FROM
                테이블이름
            WHERE -- WHERE 조건절이라고 부른다.
                조건식
            ;
            
*/

-- 부서번호가 10인 사원들의 사원번호, 사원이름, 직급, 부서번호를 조회하세요.
SELECT
    empno "사원번호", ename 사원이름, job AS "직 급", deptno 부서번호
FROM
    emp
WHERE
    deptno = 10 -- = : 동등비교 연산자
;

/*
    조회결과에 연산식을 포함해서 조회할 수 있다.
    
    산술연산자
        +
        -
        *
        /
        
*/

-- 간단한 계산결과(10 / 3)를 조회해보자.
SELECT
    10 / 3
FROM
    emp
;
-- ==> 데이터가 14개 존재하므로 14개 행으로 계산결과가 조회된다.
--      이런경우를 위해서 오라클에서는 물리적으로 만들어져있지는 않지만
--      한개의 행과 한개의 컬럼으로 만들어진 가상의 테이블을 제공해주고 있다.
--          이 테이블의 이름이 DUAL 이다.
--      이런 테이블을 가리켜 '의사테이블' 이라고 부른다.
select * from dual;

SELECT
    10 / 3
FROM
    dual
;

-- 질의 명령 안에 연산식을 포함할 수 있다.
-- 10 번 부서 사원들의 사원이름, 부서번호, 원급여, 인상급여(+10%)를 조회하세요.
SELECT
    ename 사원이름, deptno 부서번호, sal 원급여, sal * 1.1 인상급여
FROM
    emp
WHERE
    deptno = 10
;

/*
    문제 1 ]
        사원들중 급여가 1500 이상인 사원들의
            사원이름, 직급, 급여
        를 조회하세요.
*/
SELECT
    ename 사원이름, job 직급, sal 급여
FROM
    emp
WHERE
    sal >= 1500
;

/*
    not 연산자 : 부정 연산자
*/
SELECT
    ename 사원이름, job 직급, sal 급여
FROM
    emp
WHERE
    not sal < 1500
;

/*
    참고 ]
        NULL 데이터
        ==> 필드(컬럼)에는 데이터가 보과되어야 하는데
            아직 데이터가 만들어지지 않은 경우도 생길 수 있다.
            이처럼 컬럼에 데이터가 없는 상태를 NULL 데이터라고 한다.
            
            ***
            NULL 데이터는 모든 연산에서 제외된다.
            
            따라서 NULL 데이터의 비교가 필요한 경우는
                
                IS NULL
                IS NOT NULL
            라는 연산자로 반드시 비교해야 한다.
            
    참고 ]
        NULL 데이터 대체 함수
        ==> NULL 데이터는 모든 연산에서 제외가 되므로
            연산이 필요한 경우에는 특정데이터로 교체해서 
            연산작업이 되어야 한다.
            
            함수 ]
                NVL(컬럼이름, 대체값)
                
                NVL2(컬럼이름, 연산식, 대체값)
*/

-- 사원들중 커미션이 없는 사원들의 
--  사원이름, 직급, 급여, 커미션을 조회하세요.
SELECT
    ename, job, sal, comm
FROM
    emp
WHERE
    comm IS NULL
;

-- 사원들의 사원이름, 급여, 지급커미션 을 조회하는데 커미션을 100 인상해서 조회하세요.
--  단, 커미션이 없는 사원은 50을 지급하세요.

-- 1.
SELECT
    ename 사원이름, sal 급여, NVL(comm, -50) + 100 지급커미션
FROM
    emp
;
SELECT
    ename 사원이름, sal 급여, NVL(comm + 100, 50) 지급커미션
FROM
    emp
;

-- 2.
SELECT
    ename 사원이름, sal 급여, 
    NVL2(comm, comm + 100, 50) 지급커미션
FROM
    emp
;

-- 참고 ] NULL 일때 대체데이터와 데이터의 타입은 같아야 한다.
SELECT
    ename 사원이름, NVL(TO_CHAR(comm), '커미션 없음') 커미션
FROM
    emp
;

/*
    WHERE 조건절에 조건을 여러개 나열할 수 있다.
    이때 각 조건을 연산하는 논리 연산자가 있는데
        AND, OR
    를 사용한다.
*/
-- 부서번호가 30번이고 직급이 'MANAGER'인 사원들의
--  사원번호, 사원이름, 직급, 급여, 부서번호를 조회하세요.
SELECT
    empno 사원번호, ename 사원이름, job 직급, 
    sal 급여, deptno 부서번호
FROM
    emp
WHERE
     deptno = 30
     AND job = 'MANAGER'
     -- 연산자, 테이블이름, 필드이름, 명령등은 
     -- 대소문자를 구분하지 않지만
     -- 데이터 자체는 반드시 대소문자를 구분해야 한다.
;

-- smith 사원의 사원이름, 직급, 부서번호를 조회하세요.
SELECT
    ename 사원이름, job 직급, deptno 부서번호
FROM
    emp
WHERE
    ename = 'SMITH'
;
-- 부서번호가 20번이고 급여가 1500 이상인 사원들의 
-- 사원이름, 직급, 부서번호, 급여를 조회하세요.
SELECT
    ename 사원이름, job 직급, deptno 부서번호, sal 급여
FROM
    emp
WHERE
    deptno = 20
    AND NOT sal < 1500
;

select MOD(10, 3) 나머지 from dual;

/*
    문자열 결합
    ==> 오라클에서도 문자열을 결합해서 조회할 수 있다.
        이때는 두개의 컬럼을 결합할 수 도 있고
        하나의 컬럼과 한개의 문자열을 결합할 수 도 있고
        두개의 문자열을 결합할 수 도 있다.
        
        연산자 ]
            데이터 || 데이터
*/
SELECT
    3.14 || 100 결과
FROM
    dual
;

--  사원들의 사원번호, 사원이름, 직급 을 조회하세요.
-- 단, 사원번호는 번호뒤에 ' 번' 을 붙이고
--  사원이름은 이름 뒤에 ' 사원' 을 붙여서 조회하세요.
SELECT
    empno || ' 번' 사원번호, ename || ' 사원' 사원이름, job 직급
FROM
    emp
;

-- 사원들의 '사원번호 - 사원이름 : 직급' 을 형식에 맞춰서 조회하세요.
SELECT
    empno || ' - ' || ename || ' : ' || job AS "사원번호 - 사원이름 : 직급"
FROM
    emp
;

/*
    참고 ]
        오라클은 데이터의 형태를 매우 중요시한다.
        원칙적으로 문자는 문자끼리 숫자는 숫자끼리 비교할 수 있다.
        단, 예외가 하나 존재하는데 날짜는 날짜형식문자와 비교될 수 있다.
*/

-- 1981년 10월 이후에 입사한 사원들의
-- 사원이름, 직급, 입사일 을 조회하세요.
SELECT
    ename 사원이름, job 직급, hiredate 입사일
FROM
    emp
WHERE
    hiredate > '1981/09/30'
;

/*
    참고 ]
        오라클은 문자데이터도 크기비교가 가능하다.
        이때는 ASCII 코드값을 이용해서 비교를 하게 된다.
        즉, 'A'는 'B'보다 작다.
*/

-- 사원의 이름이 'H' 이후의 문자로 시작하는 사원들의 
-- 사원이름, 사원직급, 입사일 을 조회하세요.
SELECT
    ename 사원이름, job 직급, hiredate 입사일
FROM
    emp
WHERE
    ename > 'Gzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz'
;

/*
    참고 ]
        오라클은 문자와 문자열을 구분하지 않는다.
        모두 하나의 형태로 관리한다.
        이때 문자데이터의 표현은 작은 따옴표('')를 사용해서 표현한다.
        
    참고 ]
        오라클은 모든 명령이 대소문자를 구분하지 않는다.
        하지만 데이터 만큼은 대소문자를 구부해야 한다.
*/

-- 직급이 'CLERK'인 사원들의 사원이름, 직급, 월 수입을 조회하세요.
-- 단, 월 수입은 급여 + 커미션으로 하고 커미션이 없는 사원은 0으로 계산한다.
SELECT
    ename 사원이름, job 직급, NVL(sal + comm, sal) "월 급여"
FROM
    emp
WHERE
    job = 'CLERK'
;
-- 사원들중 급여가 1000 ~ 3000 사이인 사원들의
-- 사원이름 직급, 급여를 조회하세요.
SELECT
    ename 사원이름, job 직급, sal 급여
FROM
    emp
WHERE
--    sal >= 1000
--    AND sal <= 3000
    sal BETWEEN 1000 AND 3000 --  BETWEEN : 범위 비교연산자, 주의 ] 작은 값이 먼저와야 한다.
;
-- 부서번호가 10번이거나 20 번인 사원들의 사원이름, 직급, 부서번호를 조회하세요.
SELECT
    ename 사원이름, job 직급, deptno 부서번호
FROM
    emp
WHERE
--    deptno = 10
--    OR deptno = 20
    deptno IN (10, 20) 
    -- IN : 다중값 비교연산자. 동등비교연산을 한다. 
    --      나열한 데이터는 OR의 의미
;

/*
    조건비교 연산자
    1. BETWEEN A AND B
        ==> 데이터가 A와 B 사이에 있는지를 확인하는 조건연산자. 범위 비교 연산자
        
    2. IN
        ==> 데이터가 주어진 여러개의 데이터중 하나라도 만족하는지를 알아보는 조건 연산자.
            다중값 비교연산자.
            
            형식 ]
                컬럼(데이터) IN (데이터1, 데이터2, 데이터3, ........)
                
    3. LIKE
        ==> 문자열 비교연산자
            문자열의 일부분을 형식을 지정해서 맞는지 검사하는 조건 연산자
            
            형식 ]
                필드이름(데이터) LIKE '와일드카드 포함 문자열'
                
            의미 ]
                필드의 데이터가 지정한 문자열과 동일한 형식인지를 비교한다.
                
            참고 ]
                와일드카드 사용방법
                    _   : 한개당 한글자만 올 수 있다.
                    %   : 글자수에 관계없이 모든 문자열을 포함하는 형식문자.
                    
                예 ]
                    'M%'    ==> M으로 시작하는 모든 문자열
                    '%M%'   ==> M이 포함된 모든 문자열
                    '_M%'   ==> 두번째 문자가 M인 모든 문자열
                    
                    '____/01/__'
                    '____'  ==> 네문자로 구성된 문자열
            
*/
-- 사원의 이름이 5글자인 사원들의 사원이름, 직급을 조회하세요.
SELECT
    ename 사원이름, job 직급
FROM
    emp
WHERE
    ename LIKE '_____'
;

-- 1월에 입사한 사원들의 사원이름, 입사일을 조회하세요.
SELECT
    ename 사원이름, hiredate 입사일
FROM
    emp
WHERE
    hiredate LIKE '__/01/__'
;

-- 날짜가 오늘날짜와 같은 날에 입사한 사원의  사원이름, 입사일을 조회하세요.
/*
    참고 ]
        질의명령이 실행되는 순간의 날짜 데이터를 알려주는 명령
            sysdate
*/

SELECT SYSDATE FROM DUAL;

SELECT
    ename 사원이름, hiredate 입사일
FROM
    emp
WHERE
    hiredate LIKE '___12/15'
;

-- 2월에 입사한 사원
SELECT
    ename 사원이름, hiredate 입사일
FROM
    emp
WHERE
    hiredate LIKE '__/02/__'
;


/*
    NULL 데이터는 모든 연산에서 제외된다.
    따라서 조건식에서도 사용할 수 없다.
    
    이럴때 사용하는 연산자
        IS NULL
        IS NOT NULL
    로 비교해야 한다.
*/
-- 사장님의 이름을 조회하세요.
SELECT
    ename 사장님이름
FROM
    emp
WHERE
    mgr IS NULL
;

/*
    데이터 조회 질의명령
        형식 3 ]
            SELECT
                컬럼이름, 컬럼이름,...
            FROM
                테이블이름
            WHERE
                조건식
            ORDER BY
                컬럼이름 ASC OR DESC, 컬럼이름 ASC OR DESC, ...
            ;
            
        참고 ]
            ASC :   오름차순 정렬
            DESC :  내림차순 정렬
            
            오름차순 정렬의 경우 ASC를 생략해도 무방하다.
            
    참고 ]
        조건절이 추가가 되는 경우는 
        조건절을 먼저 기술하고
        정렬절을 나중에 기술하게 된다.
        <== 걸러진 결과를 정렬에 사용하게 되기때문에...
*/
-- 사원들의 사원이름, 입사일, 급여를 조회하는데
-- 급여가 많은 사원부터 조회되도록하고
-- 급여가 같으면 입사일이 빠른 사원부터 조회되게 하세요.
SELECT
    ename 사원이름, hiredate 입사일, sal 급여
FROM
    emp
ORDER BY
    sal DESC, hiredate
;

-- 사원의 이름이 5글자인 사원들의 사원이름, 직급을 조회하세요.
-- 단, 이름순서대로 정렬해서 조회하세요.
SELECT
    ename 사원이름, job 직급
FROM
    emp
WHERE
    LENGTH(ename) = 5
--    ename LIKE '_____'
ORDER BY
    ename ASC
;

--------------------------------------------------------------------------------
/*
    집합연산자
    ==> 두개 이상의 조회질의 결과를 이용해서
        그 결과의 결합을 얻어내는 방법
        
        형식 ]
            SELECT ...
            집합연산자
            SELECT ...
            
        연산자 종류 ]
            UNION   : 합집합
            
            UNION ALL : 위와 동일하지만 중복데이터를 한번더 출력해준다.
            
            INTERSECT   : 교집합. 중복데이터만 출력해준다.
            
            MINUS       : 차집합
            
        참고 ]
            공통적인 특징
                1. 두 질의 명령에서 나온 결과는 같은 필드의 갯수를 가져야 한다.
                2. 두 질의 명령에서 나온 결과 필드의 타입과 순서가 같아야 한다.
                    이때 크기는 상관없다.
            
*/
-- 부서번호와 상사번호를 하나의 컬럼으로 표현해보자.
SELECT
    job 직급, mgr 상사번호
FROM
    emp
UNION
SELECT
    ename, deptno
FROM
    emp
;
SELECT
    job 직급, mgr 상사번호
FROM
    emp
UNION ALL
SELECT
    ename, deptno
FROM
    emp
;

SELECT
    job 직급, mgr 상사번호
FROM
    emp
INTERSECT
SELECT
    ename, deptno
FROM
    emp
;

SELECT
    job 직급, mgr 상사번호
FROM
    emp
MINUS
SELECT
    ename, deptno
FROM
    emp
ORDER BY
    직급
;

SELECT
    deptno
FROM
    emp
UNION
SELECT
    deptno
FROM
    emp
;

-- 이름이 4글자이상 6글자 이하인 사원들의 사원이름, 직급을 조회하세요.
SELECT
    ename 사원이름, job 직급
FROM
    emp
WHERE
    LENGTH(ename) BETWEEN 4 AND 6
;

-- 입사일이 85년에서 87년 사이인 사원들의 사원이름, 직급, 입사년도를 조회하세요.
SELECT
    ename 사원이름, job 직급, TO_CHAR(hiredate, 'YY') 입사년도
FROM
    emp
WHERE
    TO_CHAR(hiredate, 'yy') BETWEEN '85' AND '87'
;

