var colorList = [
	'w3-red',  // 첫번째 데이터- 인덱스 : 0
	'w3-pink', // 두번째 데이터 - 인덱스 : 1
	'w3-purple',
	'w3-deep-purple',
	'w3-blue',
	'w3-cyan',
	'w3-aqua',
	'w3-green',
	'w3-light-green',
	'w3-lime',
	'w3-yellow',
	'w3-amber',
	'w3-orange',
	'w3-deep-orange',
	'w3-black',
	'w3-dark-grey',
	'w3-grey',
	'w3-light-grey',
	'w3-blue-grey',
	'w3-brown',
	'w3-pale-red',
	'w3-sand',
	'w3-pale-yellow',
	'w3-khaki',
	'w3-pale-blue',
	'w3-light-blue'
];