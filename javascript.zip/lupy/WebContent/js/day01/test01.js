/*
	이 문서에서는 
	script 태그의 작성내용과 동일하게 코딩하면 된다.
*/
document.write('<h1 style="text-align: center; color: dodgerblue;">외부 스크립트에서 만든 태그</h1>');